# Формат песни (JSON)

Песня в MusicMaker — это один JSON-файл. Его можно сохранить, отредактировать руками или отдать ИИ. Кнопка «Скопировать для ИИ» кладёт в буфер обмена это описание вместе с песней.

## Пример

```json
{
  "format": "musicmaker-song",
  "version": 1,
  "title": "Ночной город",
  "bpm": 110,
  "key": "A",
  "scale": "minor",
  "beatsPerBar": 4,
  "loop": true,
  "tracks": [
    { "id": "drums", "name": "Ударные", "instrument": "drums.electro", "role": "drums", "volume": 0.85, "reverb": 0.2 },
    { "id": "bass", "name": "Бас", "instrument": "bass.synth", "role": "bass", "volume": 0.7, "reverb": 0.05, "sidechain": 0.5 },
    { "id": "lead", "name": "Лид", "instrument": "lead.saw", "role": "lead", "volume": 0.6, "reverb": 0.3, "delay": 0.25 }
  ],
  "sections": [
    {
      "id": "loop",
      "name": "Луп",
      "bars": 2,
      "chords": ["Am", "F G"],
      "parts": {
        "drums": { "kick": "x...x...x...x...", "snare": "....X.......X...", "hat": "x.x.x.x.x.x.x.x." },
        "bass": [
          { "step": 0, "note": "A1", "len": 2, "vel": 0.9 },
          { "step": 2, "note": "A2", "len": 2, "vel": 0.7 },
          { "step": 16, "note": "F1", "len": 8, "vel": 0.9 },
          { "step": 24, "note": "G1", "len": 8, "vel": 0.9 }
        ],
        "lead": [
          { "step": 0, "note": "E5", "len": 4, "vel": 0.8 },
          { "step": 4, "note": "C5", "len": 4, "vel": 0.7 },
          { "step": 8, "note": "A4", "len": 8, "vel": 0.8 }
        ]
      }
    }
  ],
  "arrangement": ["loop"]
}
```

## Поля песни

| Поле | Что это |
|---|---|
| `bpm` | темп, ударов в минуту (30–300) |
| `key` | тоника: `C`, `C#`, `D`, `Eb`, `E`, `F`, `F#`, `G`, `Ab`, `A`, `Bb`, `B` |
| `scale` | лад: `major`, `minor`, `harmonicMinor`, `dorian`, `phrygian`, `lydian`, `mixolydian`, `phrygianDominant`, `majorPentatonic`, `minorPentatonic`, `blues`, `wholeTone` |
| `beatsPerBar` | долей в такте: 4 = 4/4, 3 = 3/4 |
| `swing`, `swingGrid` | свинг 0–1; сетка свинга 16 (шестнадцатые) или 8 (восьмые, джаз) |
| `loop` | `true` — песня зацикливается (для игр) |
| `tracks` | дорожки |
| `sections` | секции (части песни) |
| `arrangement` | порядок секций по `id`; одну секцию можно повторять |

## Время

**1 шаг = 1/16 ноты.** Такт 4/4 — 16 шагов (0–15), такт 3/4 — 12 шагов. Поле `step` отсчитывается от начала секции, `len` задаётся в шагах: 4 — четверть, 8 — половинная, 16 — целая.

## Дорожки

| Поле | Что это |
|---|---|
| `id` | уникальный идентификатор (латиница) |
| `name` | название для людей |
| `instrument` | инструмент (список ниже) |
| `role` | назначение: `drums`, `bass`, `chords`, `pad`, `arp`, `lead`, `counter`, `fx`. По нему кнопка «Новая партия» решает, что генерировать |
| `part` | манера игры, например `octave8` для баса или `strum` для гитары (необязательно) |
| `volume` | громкость 0–1 |
| `pan` | панорама −1 (лево) … 1 (право) |
| `reverb`, `delay` | посыл в ревербератор и эхо, 0–1 |
| `sidechain` | «пампинг» от бочки, 0–1 |
| `mute`, `solo`, `locked` | заглушить, соло, закрепить от генератора |

## Секции

| Поле | Что это |
|---|---|
| `id`, `name` | идентификатор и название |
| `kind` | тип: `intro`, `verse`, `pre`, `chorus`, `chorus2`, `bridge`, `outro`, `loop`, `loopA`, `loopB` (необязательно) |
| `bars` | длина в тактах |
| `energy` | энергия 0–1 (для генератора) |
| `chords` | аккорд на каждый такт; `"F G"` — два аккорда в такте. Если аккордов меньше, чем тактов, они идут по кругу |
| `parts` | партии: ключ — `id` дорожки |

**Аккорды:** `C`, `Am`, `F#m7`, `Bbmaj7`, `G7`, `Dm7b5`, `Esus4`, `Cadd9`, `Am9`, `C/E` и т.п.

**Мелодическая партия** — массив нот `{ "step", "note", "len", "vel" }`. Ноты записываются в научной нотации: `C4` — до первой октавы, `A4` = 440 Гц; диезы `C#4`, бемоли `Bb3`. `vel` — громкость 0–1.

**Партия ударных** — объект строк, один символ на шаг:

| Символ | Значение |
|---|---|
| `X` | акцент |
| `x` | обычный удар |
| `o` | тихий (призрачный) удар |
| `2` `3` `4` | дробь: столько ударов внутри шага |
| `.` или `-` | пауза |
| `\|` | разделитель тактов (для удобства чтения) |

Если строка короче секции, она повторяется. Барабаны: `kick`, `snare`, `clap`, `rim`, `hat`, `openhat`, `shaker`, `ride`, `crash`, `tom1`, `tom2`, `tom3`.

## Инструменты

| id | Название |
|---|---|
| `drums.acoustic`, `drums.electro`, `drums.lofi`, `drums.chip`, `drums.epic` | наборы ударных |
| `bass.synth`, `bass.sub`, `bass.808`, `bass.acid`, `bass.guitar`, `bass.upright`, `bass.chip` | басы |
| `keys.piano`, `keys.epiano`, `keys.organ` | клавишные |
| `pad.warm`, `pad.dark`, `pad.choir`, `pad.drone` | пэды, хор, гул |
| `strings.ensemble`, `strings.staccato`, `strings.pizz`, `brass.section`, `wind.flute`, `pluck.harp` | оркестр |
| `guitar.acoustic`, `guitar.clean`, `guitar.distorted` | гитары |
| `lead.saw`, `lead.square`, `pluck.synth`, `lead.chip`, `pulse.chip` | синтезаторы |
| `mallet.marimba`, `mallet.vibes`, `mallet.bell`, `mallet.musicbox` | мелодическая перкуссия |
| `fx.riser`, `fx.impact`, `fx.vinyl` | эффекты: нарастание, удар, шум винила |

## Прощение ошибок

Импорт старается не падать. Он вырезает JSON из ответа ИИ (в том числе из блока ```json), убирает лишние запятые, понимает `"Am"` в поле `key`, скорость в стиле MIDI (0–127), синонимы барабанов (`hh`, `bd`, `sd`…). Непонятное пропускается, а в панели JSON выводится список замечаний.
