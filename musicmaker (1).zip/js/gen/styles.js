// Жанры (стили) генератора. Каждый стиль задаёт темп, лады, прогрессии, грув ударных
// и набор «ролей» — блоков, из которых собирается аранжировка.
//
// Роль: { id, role, name, instrument, part, enter, intro?, register?, volume?, reverb?, delay?, pan?, sidechain?, melody? }
//   role    — drums | bass | chords | pad | arp | lead | counter | fx
//   part    — манера игры (см. gen/parts.js и gen/melody.js)
//   enter   — с какой «энергии» секции блок вступает (0 — всегда, 0.8 — только в припеве)
//   intro   — играть и во вступлении, даже если энергия ниже порога
//
// Прогрессии записаны римскими ступенями от тоники (b — пониженная ступень): i bVI bIII bVII.

export const STYLES = {
  epic: {
    name: 'Эпик / трейлер',
    description: 'Оркестр, тайко, остинато струнных, медь и хор. Для трейлеров, битв с боссом и титров.',
    bpm: [84, 100],
    scales: { dark: [['minor', 3], ['harmonicMinor', 1]], bright: [['major', 2], ['mixolydian', 1]] },
    mood: 'dark',
    keys: ['D', 'C', 'E', 'A', 'G', 'F'],
    progressions: {
      minor: ['i bVI bIII bVII', 'i bVI bVII i', 'i bVII bVI bVII', 'bVI bVII i i', 'i iv bVI V', 'i bIII bVII iv'],
      major: ['I V vi IV', 'I bVII IV I', 'IV V vi I', 'I iii IV V', 'I bVI bVII I'],
    },
    harmonicRhythm: 1,
    groove: 'epic',
    roles: [
      { id: 'drums', role: 'drums', name: 'Ударные', instrument: 'drums.epic', enter: 0.45, reverb: 0.3, volume: 0.9 },
      { id: 'ostinato', role: 'arp', name: 'Остинато струнных', instrument: 'strings.staccato', part: 'ostinato', enter: 0.2, intro: true, register: [45, 62], volume: 0.6, reverb: 0.25 },
      { id: 'bass', role: 'bass', name: 'Бас', instrument: 'bass.sub', part: 'sustain', enter: 0.35, register: [26, 45], volume: 0.7 },
      { id: 'strings', role: 'chords', name: 'Струнные', instrument: 'strings.ensemble', part: 'sustain', enter: 0, register: [50, 74], volume: 0.55, reverb: 0.4 },
      { id: 'choir', role: 'pad', name: 'Хор', instrument: 'pad.choir', part: 'sustain', enter: 0.75, register: [55, 76], volume: 0.45, reverb: 0.5 },
      { id: 'lead', role: 'lead', name: 'Медь (тема)', instrument: 'brass.section', enter: 0.6, register: [55, 74], volume: 0.7, reverb: 0.35, melody: { density: 0.3, feel: 'long' } },
      { id: 'counter', role: 'counter', name: 'Высокие струнные', instrument: 'strings.ensemble', part: 'high', enter: 0.9, register: [72, 88], volume: 0.4, reverb: 0.45 },
      { id: 'impact', role: 'fx', name: 'Удары', instrument: 'fx.impact', part: 'impacts', enter: 0.75, volume: 0.7, reverb: 0.5 },
      { id: 'riser', role: 'fx', name: 'Нарастание', instrument: 'fx.riser', part: 'risers', enter: 0.4, volume: 0.45, reverb: 0.4 },
    ],
  },

  ambient: {
    name: 'Эмбиент / спокойный фон',
    description: 'Мягкие пэды, колокольчики, редкие ноты пианино. Для меню, медитативных уровней, фона в видео.',
    bpm: [64, 80],
    scales: { bright: [['major', 2], ['lydian', 2]], dark: [['dorian', 2], ['minor', 2]] },
    mood: 'bright',
    keys: ['C', 'D', 'F', 'G', 'A', 'E'],
    progressions: {
      major: ['Imaj7 IVmaj7 vi7 IVmaj7', 'I iii IV IV', 'vi IV I V', 'Iadd9 IVmaj7 Iadd9 V', 'IVmaj7 Imaj7 IVmaj7 V'],
      minor: ['im9 bVImaj7 bIIImaj7 bVII', 'i bVII bVI bVII', 'im7 iv7 bVImaj7 bVII'],
    },
    harmonicRhythm: 2,
    groove: 'ambient',
    roles: [
      { id: 'pad', role: 'pad', name: 'Пэд', instrument: 'pad.warm', part: 'sustain', enter: 0, register: [48, 74], volume: 0.6, reverb: 0.55 },
      { id: 'bells', role: 'arp', name: 'Колокольчики', instrument: 'mallet.bell', part: 'sparse', enter: 0.25, intro: true, register: [72, 91], volume: 0.35, reverb: 0.6, delay: 0.35 },
      { id: 'bass', role: 'bass', name: 'Саб-бас', instrument: 'bass.sub', part: 'sustain', enter: 0.4, register: [28, 45], volume: 0.55 },
      { id: 'lead', role: 'lead', name: 'Пианино (мелодия)', instrument: 'keys.piano', enter: 0.5, register: [62, 81], volume: 0.6, reverb: 0.5, delay: 0.2, melody: { density: 0.25, feel: 'long' } },
      { id: 'drums', role: 'drums', name: 'Перкуссия', instrument: 'drums.lofi', enter: 0.65, volume: 0.5, reverb: 0.3 },
      { id: 'counter', role: 'counter', name: 'Струнные', instrument: 'strings.ensemble', part: 'high', enter: 0.85, register: [67, 84], volume: 0.3, reverb: 0.6 },
    ],
  },

  synthwave: {
    name: 'Синтвейв / ретро 80-х',
    description: 'Пульсирующий бас, арпеджио, большой гулкий малый барабан, пила-лид. Ночной город, гонки, неон.',
    bpm: [96, 118],
    scales: { dark: [['minor', 3], ['dorian', 1]], bright: [['major', 1], ['mixolydian', 1]] },
    mood: 'dark',
    keys: ['A', 'E', 'D', 'F#', 'C', 'B'],
    progressions: {
      minor: ['i bVI bIII bVII', 'i bVII bVI bVII', 'bVI bVII i i', 'i iv bVI bVII', 'im7 bVImaj7 bIIImaj7 bVII'],
      major: ['I V vi IV', 'vi IV I V', 'I iii IV V', 'IVmaj7 V iii vi'],
    },
    harmonicRhythm: 1,
    groove: 'synthwave',
    roles: [
      { id: 'drums', role: 'drums', name: 'Ударные', instrument: 'drums.electro', enter: 0.4, reverb: 0.25, volume: 0.85 },
      { id: 'bass', role: 'bass', name: 'Бас', instrument: 'bass.synth', part: 'octave8', enter: 0.3, register: [28, 52], volume: 0.72, sidechain: 0.5 },
      { id: 'pad', role: 'pad', name: 'Пэд', instrument: 'pad.warm', part: 'sustain', enter: 0, register: [50, 74], volume: 0.5, reverb: 0.45, sidechain: 0.6 },
      { id: 'arp', role: 'arp', name: 'Арпеджио', instrument: 'pluck.synth', part: 'up16', enter: 0.45, intro: true, register: [57, 81], volume: 0.45, reverb: 0.3, delay: 0.3 },
      { id: 'lead', role: 'lead', name: 'Лид', instrument: 'lead.saw', enter: 0.6, register: [62, 84], volume: 0.6, reverb: 0.35, delay: 0.25, melody: { density: 0.45, feel: 'normal' } },
      { id: 'riser', role: 'fx', name: 'Нарастание', instrument: 'fx.riser', part: 'risers', enter: 0.4, volume: 0.4, reverb: 0.4 },
    ],
  },

  chiptune: {
    name: '8-бит / чиптюн',
    description: 'Звук старых приставок (NES): прямоугольные волны, быстрые арпеджио аккордов, шумовые барабаны.',
    bpm: [128, 160],
    scales: { bright: [['major', 3]], dark: [['minor', 2], ['harmonicMinor', 1]] },
    mood: 'bright',
    keys: ['C', 'G', 'D', 'F', 'A', 'E'],
    progressions: {
      major: ['I V vi IV', 'I IV V IV', 'I bVI bVII I', 'vi IV V I', 'I vi IV V', 'IV V iii vi'],
      minor: ['i bVII bVI V', 'i iv v i', 'i bVI bVII i', 'i bIII bVII iv'],
    },
    harmonicRhythm: 1,
    groove: 'chip',
    roles: [
      { id: 'drums', role: 'drums', name: 'Шумовые барабаны', instrument: 'drums.chip', enter: 0.35, reverb: 0, volume: 0.75 },
      { id: 'bass', role: 'bass', name: 'Бас (треугольник)', instrument: 'bass.chip', part: 'chip8', enter: 0.2, register: [33, 57], volume: 0.7, reverb: 0 },
      { id: 'arp', role: 'arp', name: 'Аккорды-арпеджио', instrument: 'pulse.chip', part: 'chipArp', enter: 0.3, intro: true, register: [60, 79], volume: 0.4, reverb: 0.05 },
      { id: 'lead', role: 'lead', name: 'Мелодия', instrument: 'lead.chip', enter: 0.45, register: [67, 88], volume: 0.6, reverb: 0.08, melody: { density: 0.7, feel: 'busy' } },
      { id: 'harmony', role: 'counter', name: 'Второй голос', instrument: 'pulse.chip', part: 'harmony', enter: 0.85, register: [60, 84], volume: 0.35, reverb: 0.05 },
    ],
  },

  lofi: {
    name: 'Лоу-фай хип-хоп',
    description: 'Джазовые септаккорды на электропиано, ленивый свинг, пыльные барабаны, треск винила.',
    bpm: [70, 88],
    swing: 0.55,
    scales: { bright: [['major', 3]], dark: [['dorian', 2], ['minor', 1]] },
    mood: 'bright',
    keys: ['F', 'C', 'Eb', 'D', 'Bb', 'G'],
    progressions: {
      major: ['ii7 V7 Imaj7 vi7', 'Imaj7 vi7 ii7 V7', 'IVmaj7 iii7 ii7 Imaj7', 'vi9 ii9 V7 Imaj9', 'Imaj7 IVmaj7 iii7 vi7'],
      minor: ['im7 iv7 bVImaj7 V7', 'im9 iv9 bVIImaj7 bIIImaj7', 'im7 bVImaj7 iv7 V7'],
    },
    harmonicRhythm: 1,
    groove: 'boombap',
    extended: true,
    roles: [
      { id: 'drums', role: 'drums', name: 'Ударные', instrument: 'drums.lofi', enter: 0.3, reverb: 0.12, volume: 0.8 },
      { id: 'keys', role: 'chords', name: 'Электропиано', instrument: 'keys.epiano', part: 'lofiComp', enter: 0, register: [50, 74], volume: 0.6, reverb: 0.3 },
      { id: 'bass', role: 'bass', name: 'Бас', instrument: 'bass.guitar', part: 'syncopated', enter: 0.35, register: [28, 50], volume: 0.75, reverb: 0.02 },
      { id: 'lead', role: 'lead', name: 'Мелодия', instrument: 'keys.piano', enter: 0.55, register: [64, 84], volume: 0.5, reverb: 0.4, delay: 0.15, melody: { density: 0.35, feel: 'normal' } },
      { id: 'vinyl', role: 'fx', name: 'Винил', instrument: 'fx.vinyl', part: 'vinyl', enter: 0, intro: true, volume: 0.45, reverb: 0 },
    ],
  },

  house: {
    name: 'Хаус / электроника',
    description: 'Прямая бочка 4/4, бас на офбитах, стабы аккордов, «пампинг». Энергичный фон, танцевальные уровни.',
    bpm: [120, 126],
    scales: { dark: [['minor', 2], ['dorian', 2]], bright: [['major', 2]] },
    mood: 'dark',
    keys: ['A', 'F', 'G', 'C', 'D', 'E'],
    progressions: {
      minor: ['im7 bVImaj7 bVII7 im7', 'i bVI bIII bVII', 'im7 iv7 bVII7 bIIImaj7', 'im9 bVII bVI bVII'],
      major: ['vi IV I V', 'Imaj7 vi7 IVmaj7 V7', 'IV V iii vi'],
    },
    harmonicRhythm: 1,
    groove: 'four',
    roles: [
      { id: 'drums', role: 'drums', name: 'Ударные', instrument: 'drums.electro', enter: 0.3, reverb: 0.1, volume: 0.9 },
      { id: 'bass', role: 'bass', name: 'Бас', instrument: 'bass.synth', part: 'offbeat', enter: 0.4, register: [30, 52], volume: 0.72, sidechain: 0.4 },
      { id: 'stabs', role: 'chords', name: 'Стабы', instrument: 'keys.organ', part: 'stabs', enter: 0.45, register: [55, 76], volume: 0.45, reverb: 0.3, delay: 0.2, sidechain: 0.3 },
      { id: 'pad', role: 'pad', name: 'Пэд', instrument: 'pad.warm', part: 'sustain', enter: 0, register: [50, 74], volume: 0.4, reverb: 0.45, sidechain: 0.7 },
      { id: 'lead', role: 'lead', name: 'Мелодия', instrument: 'pluck.synth', enter: 0.7, register: [64, 86], volume: 0.5, reverb: 0.3, delay: 0.3, melody: { density: 0.55, feel: 'normal' } },
      { id: 'riser', role: 'fx', name: 'Нарастание', instrument: 'fx.riser', part: 'risers', enter: 0.4, volume: 0.45, reverb: 0.4 },
    ],
  },

  action: {
    name: 'Экшен / бой',
    description: 'Быстрый брейкбит, агрессивный бас, гитарные пауэр-аккорды и остинато. Для погонь и сражений.',
    bpm: [140, 170],
    scales: { dark: [['minor', 2], ['phrygian', 1], ['harmonicMinor', 1]], bright: [['mixolydian', 1], ['dorian', 1]] },
    mood: 'dark',
    keys: ['E', 'D', 'C', 'F#', 'A', 'G'],
    progressions: {
      minor: ['i bVI bVII i', 'i bII i bVII', 'i iv bVI V', 'i i bVI bVII', 'i bIII iv bVI'],
      major: ['I bVII IV I', 'I bVI bVII I', 'I IV bVII IV'],
    },
    harmonicRhythm: 1,
    groove: 'dnb',
    roles: [
      { id: 'drums', role: 'drums', name: 'Ударные', instrument: 'drums.electro', enter: 0.3, reverb: 0.1, volume: 0.9 },
      { id: 'bass', role: 'bass', name: 'Бас', instrument: 'bass.acid', part: 'driving16', enter: 0.35, register: [28, 52], volume: 0.62 },
      { id: 'guitar', role: 'chords', name: 'Гитара', instrument: 'guitar.distorted', part: 'powerChords', enter: 0.55, register: [40, 60], volume: 0.55, reverb: 0.12 },
      { id: 'ostinato', role: 'arp', name: 'Остинато', instrument: 'strings.staccato', part: 'ostinato', enter: 0.2, intro: true, register: [50, 67], volume: 0.5, reverb: 0.25 },
      { id: 'pad', role: 'pad', name: 'Пэд', instrument: 'pad.dark', part: 'sustain', enter: 0, register: [48, 72], volume: 0.35, reverb: 0.4 },
      { id: 'lead', role: 'lead', name: 'Лид', instrument: 'lead.saw', enter: 0.75, register: [62, 84], volume: 0.55, reverb: 0.25, delay: 0.15, melody: { density: 0.55, feel: 'normal' } },
      { id: 'impact', role: 'fx', name: 'Удары', instrument: 'fx.impact', part: 'impacts', enter: 0.8, volume: 0.6, reverb: 0.4 },
    ],
  },

  rock: {
    name: 'Рок',
    description: 'Живые барабаны, бас-гитара, перегруженные пауэр-аккорды, чистая гитара во вступлении.',
    bpm: [110, 150],
    scales: { bright: [['major', 2], ['mixolydian', 2]], dark: [['minor', 3], ['dorian', 1]] },
    mood: 'bright',
    keys: ['E', 'A', 'D', 'G', 'C'],
    progressions: {
      major: ['I bVII IV I', 'I V vi IV', 'I IV V IV', 'I bIII IV I', 'vi IV I V'],
      minor: ['i bVI bVII i', 'i bVII bVI V', 'i iv bVII bIII', 'i bIII bVII IV'],
    },
    harmonicRhythm: 1,
    groove: 'rock',
    roles: [
      { id: 'drums', role: 'drums', name: 'Ударные', instrument: 'drums.acoustic', enter: 0.35, reverb: 0.15, volume: 0.9 },
      { id: 'bass', role: 'bass', name: 'Бас-гитара', instrument: 'bass.guitar', part: 'rock8', enter: 0.3, register: [28, 50], volume: 0.8 },
      { id: 'guitar', role: 'chords', name: 'Гитара (перегруз)', instrument: 'guitar.distorted', part: 'powerChords', enter: 0.45, register: [40, 60], volume: 0.6, reverb: 0.15, pan: -0.25 },
      { id: 'clean', role: 'arp', name: 'Чистая гитара', instrument: 'guitar.clean', part: 'up8', enter: 0, register: [52, 76], volume: 0.45, reverb: 0.3, delay: 0.15, pan: 0.25 },
      { id: 'lead', role: 'lead', name: 'Соло', instrument: 'lead.saw', enter: 0.7, register: [62, 84], volume: 0.55, reverb: 0.3, delay: 0.2, melody: { density: 0.5, feel: 'normal' } },
    ],
  },

  horror: {
    name: 'Хоррор / напряжение',
    description: 'Гул, диссонансы (малая секунда), шкатулка с «неправильными» нотами, сердцебиение.',
    bpm: [60, 76],
    scales: { dark: [['minor', 2], ['phrygian', 2], ['harmonicMinor', 1]], bright: [['harmonicMinor', 1]] },
    mood: 'dark',
    keys: ['C', 'D', 'E', 'F', 'B'],
    progressions: {
      minor: ['i bII i i', 'i i bII bII', 'i bVI bII i', 'imMaj7 imMaj7 i bII', 'i iv° i v', 'i bvi i bII'],
      major: ['i bII i bII'],
    },
    harmonicRhythm: 2,
    groove: 'heartbeat',
    roles: [
      { id: 'drone', role: 'bass', name: 'Гул', instrument: 'pad.drone', part: 'drone', enter: 0, intro: true, register: [26, 45], volume: 0.7, reverb: 0.4 },
      { id: 'pad', role: 'pad', name: 'Тёмный пэд', instrument: 'pad.dark', part: 'sustain', enter: 0.25, register: [48, 70], volume: 0.45, reverb: 0.55 },
      { id: 'musicbox', role: 'arp', name: 'Шкатулка', instrument: 'mallet.musicbox', part: 'creepy', enter: 0.3, intro: true, register: [72, 91], volume: 0.4, reverb: 0.6, delay: 0.3 },
      { id: 'strings', role: 'lead', name: 'Струнные', instrument: 'strings.ensemble', enter: 0.5, register: [60, 79], volume: 0.4, reverb: 0.5, melody: { density: 0.15, feel: 'long' } },
      { id: 'drums', role: 'drums', name: 'Сердцебиение', instrument: 'drums.epic', enter: 0.45, volume: 0.7, reverb: 0.4 },
      { id: 'impact', role: 'fx', name: 'Удары', instrument: 'fx.impact', part: 'impacts', enter: 0.75, volume: 0.6, reverb: 0.6 },
      { id: 'riser', role: 'fx', name: 'Нарастание', instrument: 'fx.riser', part: 'risers', enter: 0.3, volume: 0.35, reverb: 0.5 },
    ],
  },

  fantasy: {
    name: 'Фэнтези / приключение',
    description: 'Арфа, флейта, струнные, лидийский лад. Карта мира, деревня эльфов, начало путешествия.',
    bpm: [90, 118],
    scales: { bright: [['major', 2], ['lydian', 2], ['mixolydian', 1]], dark: [['dorian', 2], ['minor', 1]] },
    mood: 'bright',
    keys: ['D', 'F', 'G', 'C', 'A', 'Bb'],
    progressions: {
      major: ['I II IV I', 'I V vi IV', 'I bVII IV I', 'IV V iii vi', 'I iii IV V', 'I IV vi V'],
      minor: ['i bVII bVI bVII', 'i IV i bVII', 'i bIII bVII IV', 'vi IV I V'],
    },
    harmonicRhythm: 1,
    groove: 'folk',
    roles: [
      { id: 'harp', role: 'arp', name: 'Арфа', instrument: 'pluck.harp', part: 'harp', enter: 0, intro: true, register: [50, 79], volume: 0.55, reverb: 0.45 },
      { id: 'strings', role: 'chords', name: 'Струнные', instrument: 'strings.ensemble', part: 'sustain', enter: 0.25, register: [50, 72], volume: 0.45, reverb: 0.45 },
      { id: 'bass', role: 'bass', name: 'Пиццикато (бас)', instrument: 'strings.pizz', part: 'rootfifth', enter: 0.4, register: [33, 55], volume: 0.7, reverb: 0.3 },
      { id: 'lead', role: 'lead', name: 'Флейта', instrument: 'wind.flute', enter: 0.35, register: [67, 88], volume: 0.6, reverb: 0.4, delay: 0.1, melody: { density: 0.45, feel: 'normal' } },
      { id: 'counter', role: 'counter', name: 'Медь', instrument: 'brass.section', part: 'high', enter: 0.85, register: [58, 74], volume: 0.35, reverb: 0.45 },
      { id: 'drums', role: 'drums', name: 'Перкуссия', instrument: 'drums.epic', enter: 0.55, volume: 0.6, reverb: 0.3 },
    ],
  },

  cozy: {
    name: 'Уютное меню / казуал',
    description: 'Акустическая гитара, маримба, лёгкая перкуссия. Для казуальных игр, ферм, уютных видео.',
    bpm: [92, 116],
    scales: { bright: [['major', 3], ['majorPentatonic', 1]], dark: [['dorian', 1], ['minor', 1]] },
    mood: 'bright',
    keys: ['C', 'G', 'D', 'F', 'A'],
    progressions: {
      major: ['I V vi IV', 'I IV I V', 'IV I V vi', 'Imaj7 IVmaj7 Imaj7 V', 'I vi IV V', 'I iii vi IV'],
      minor: ['i bVII bVI bVII', 'i iv bVII bIII'],
    },
    harmonicRhythm: 1,
    groove: 'cozy',
    roles: [
      { id: 'guitar', role: 'chords', name: 'Гитара', instrument: 'guitar.acoustic', part: 'strum', enter: 0, register: [48, 69], volume: 0.55, reverb: 0.25, pan: -0.2 },
      { id: 'bass', role: 'bass', name: 'Бас', instrument: 'bass.guitar', part: 'rootfifth', enter: 0.3, register: [28, 50], volume: 0.7 },
      { id: 'drums', role: 'drums', name: 'Перкуссия', instrument: 'drums.acoustic', enter: 0.35, volume: 0.65, reverb: 0.15 },
      { id: 'lead', role: 'lead', name: 'Маримба', instrument: 'mallet.marimba', enter: 0.45, register: [64, 86], volume: 0.65, reverb: 0.3, pan: 0.15, melody: { density: 0.55, feel: 'normal' } },
      { id: 'counter', role: 'counter', name: 'Колокольчики', instrument: 'mallet.bell', part: 'high', enter: 0.85, register: [74, 91], volume: 0.3, reverb: 0.5 },
    ],
  },

  trap: {
    name: 'Трэп / хип-хоп',
    description: '808-бас, дробные хай-хэты, тёмные аккорды и колокольчики. Современный хип-хоп бит.',
    bpm: [130, 150],
    scales: { dark: [['minor', 2], ['harmonicMinor', 2], ['phrygian', 1]], bright: [['major', 1], ['dorian', 1]] },
    mood: 'dark',
    keys: ['C', 'D', 'F', 'G', 'A', 'Bb'],
    progressions: {
      minor: ['i bVI i bVI', 'i iv i iv', 'i bVI bVII i', 'i bVI iv V', 'im7 bVImaj7 im7 bVImaj7'],
      major: ['I vi I vi', 'vi IV I V'],
    },
    harmonicRhythm: 1,
    groove: 'trap',
    roles: [
      { id: 'drums', role: 'drums', name: 'Ударные', instrument: 'drums.electro', enter: 0.35, reverb: 0.08, volume: 0.9 },
      { id: 'bass', role: 'bass', name: '808', instrument: 'bass.808', part: '808', enter: 0.4, register: [24, 45], volume: 0.75 },
      { id: 'chords', role: 'chords', name: 'Пианино', instrument: 'keys.piano', part: 'sustain', enter: 0, register: [50, 74], volume: 0.5, reverb: 0.4 },
      { id: 'pad', role: 'pad', name: 'Пэд', instrument: 'pad.dark', part: 'sustain', enter: 0.6, register: [48, 70], volume: 0.35, reverb: 0.4 },
      { id: 'lead', role: 'lead', name: 'Колокольчики', instrument: 'mallet.bell', enter: 0.45, register: [67, 88], volume: 0.5, reverb: 0.4, delay: 0.2, melody: { density: 0.45, feel: 'normal' } },
      { id: 'riser', role: 'fx', name: 'Нарастание', instrument: 'fx.riser', part: 'risers', enter: 0.4, volume: 0.35, reverb: 0.4 },
    ],
  },

  jazz: {
    name: 'Джаз / лаунж',
    description: 'Свинг, райд, шагающий контрабас, джазовые аккорды на пианино, вибрафон.',
    bpm: [96, 140],
    swing: 0.85,
    swingGrid: 8,
    scales: { bright: [['major', 3]], dark: [['dorian', 1], ['minor', 1]] },
    mood: 'bright',
    keys: ['F', 'Bb', 'C', 'Eb', 'G'],
    progressions: {
      major: ['ii7 V7 Imaj7 Imaj7', 'Imaj7 vi7 ii7 V7', 'iii7 vi7 ii7 V7', 'Imaj7 IV7 iii7 VI7', 'Imaj7 bIIImaj7 bVImaj7 bIImaj7'],
      minor: ['iiø7 V7 im7 im7', 'im7 iv7 bVII7 bIIImaj7', 'im7 bVI7 iiø7 V7'],
    },
    harmonicRhythm: 1,
    groove: 'jazz',
    extended: true,
    roles: [
      { id: 'drums', role: 'drums', name: 'Ударные (щётки)', instrument: 'drums.acoustic', enter: 0.3, volume: 0.6, reverb: 0.15 },
      { id: 'bass', role: 'bass', name: 'Контрабас', instrument: 'bass.upright', part: 'walking', enter: 0.3, register: [28, 52], volume: 0.85 },
      { id: 'piano', role: 'chords', name: 'Пианино', instrument: 'keys.piano', part: 'jazzComp', enter: 0, register: [52, 72], volume: 0.55, reverb: 0.25 },
      { id: 'lead', role: 'lead', name: 'Вибрафон', instrument: 'mallet.vibes', enter: 0.45, register: [62, 84], volume: 0.6, reverb: 0.3, melody: { density: 0.5, feel: 'normal' } },
    ],
  },

  tavern: {
    name: 'Таверна / фолк',
    description: 'Вальс на 3/4 или бодрый рил: гитара, флейта, бубен. Средневековая таверна, деревня, ярмарка.',
    bpm: [100, 140],
    beatsPerBar: [3, 4],
    scales: { bright: [['mixolydian', 2], ['major', 2]], dark: [['dorian', 3], ['minor', 1]] },
    mood: 'dark',
    keys: ['D', 'E', 'A', 'G'],
    progressions: {
      minor: ['i bVII i bVII', 'i IV i bVII', 'i bIII bVII i', 'i bVII bVI bVII'],
      major: ['I IV V I', 'I bVII I V', 'I IV I V', 'I vi IV V'],
    },
    harmonicRhythm: 1,
    groove: 'folk',
    groove3: 'waltz',
    roles: [
      { id: 'guitar', role: 'chords', name: 'Гитара', instrument: 'guitar.acoustic', part: 'strum', enter: 0, register: [48, 69], volume: 0.55, reverb: 0.25 },
      { id: 'bass', role: 'bass', name: 'Контрабас', instrument: 'bass.upright', part: 'rootfifth', enter: 0.3, register: [28, 52], volume: 0.75 },
      { id: 'lead', role: 'lead', name: 'Флейта', instrument: 'wind.flute', enter: 0.35, register: [67, 88], volume: 0.6, reverb: 0.3, melody: { density: 0.65, feel: 'busy' } },
      { id: 'counter', role: 'counter', name: 'Скрипки', instrument: 'strings.ensemble', part: 'high', enter: 0.8, register: [64, 81], volume: 0.35, reverb: 0.35 },
      { id: 'drums', role: 'drums', name: 'Бубен и бочка', instrument: 'drums.acoustic', enter: 0.4, volume: 0.6, reverb: 0.2 },
    ],
  },

  oriental: {
    name: 'Восток / пустыня',
    description: 'Восточный лад (фригийский доминантовый), ритм макcум на томах, гул, флейта-най.',
    bpm: [90, 120],
    scales: { dark: [['phrygianDominant', 3]], bright: [['phrygianDominant', 2], ['harmonicMinor', 1]] },
    mood: 'dark',
    keys: ['E', 'D', 'A', 'C'],
    progressions: {
      major: ['I bII I bII', 'I bII iv I', 'I iv bII I', 'I bvii bII I'],
      minor: ['I bII I bII', 'I bII iv I'],
    },
    harmonicRhythm: 1,
    groove: 'oriental',
    roles: [
      { id: 'drone', role: 'bass', name: 'Гул', instrument: 'pad.drone', part: 'drone', enter: 0, intro: true, register: [28, 45], volume: 0.55, reverb: 0.35 },
      { id: 'drums', role: 'drums', name: 'Дарбука', instrument: 'drums.epic', enter: 0.3, volume: 0.7, reverb: 0.25 },
      { id: 'oud', role: 'arp', name: 'Уд', instrument: 'guitar.clean', part: 'pulse8', enter: 0.45, register: [50, 67], volume: 0.45, reverb: 0.3 },
      { id: 'lead', role: 'lead', name: 'Флейта', instrument: 'wind.flute', enter: 0.4, register: [64, 86], volume: 0.6, reverb: 0.45, delay: 0.15, melody: { density: 0.5, feel: 'normal' } },
      { id: 'strings', role: 'pad', name: 'Струнные', instrument: 'strings.ensemble', part: 'sustain', enter: 0.7, register: [52, 74], volume: 0.4, reverb: 0.45 },
    ],
  },

  stealth: {
    name: 'Шпионский / стелс',
    description: 'Крадущийся бас, пиццикато, приглушённые барабаны, медь. Для стелса, детективов, ограблений.',
    bpm: [92, 112],
    scales: { dark: [['minor', 2], ['harmonicMinor', 2], ['dorian', 1]], bright: [['dorian', 1]] },
    mood: 'dark',
    keys: ['E', 'D', 'A', 'C', 'G'],
    progressions: {
      minor: ['i i bVI bVI', 'i iv i V', 'im imMaj7 im7 im6', 'i bVI iv V', 'i bII i V'],
      major: ['i i bVI bVI'],
    },
    harmonicRhythm: 1,
    groove: 'stealth',
    roles: [
      { id: 'bass', role: 'bass', name: 'Бас', instrument: 'bass.upright', part: 'spy', enter: 0, intro: true, register: [28, 52], volume: 0.8 },
      { id: 'drums', role: 'drums', name: 'Ударные', instrument: 'drums.acoustic', enter: 0.3, volume: 0.55, reverb: 0.15 },
      { id: 'pizz', role: 'arp', name: 'Пиццикато', instrument: 'strings.pizz', part: 'pulse8', enter: 0.45, register: [50, 72], volume: 0.5, reverb: 0.3 },
      { id: 'pad', role: 'pad', name: 'Тёмный пэд', instrument: 'pad.dark', part: 'sustain', enter: 0.2, register: [48, 70], volume: 0.35, reverb: 0.45 },
      { id: 'lead', role: 'lead', name: 'Медь', instrument: 'brass.section', enter: 0.7, register: [55, 76], volume: 0.5, reverb: 0.3, melody: { density: 0.35, feel: 'normal' } },
    ],
  },

  pop: {
    name: 'Поп / позитив',
    description: 'Бодрая поп-сетка: пианино восьмыми, синт-бас, плак-арпеджио и звонкий лид.',
    bpm: [100, 124],
    scales: { bright: [['major', 3]], dark: [['minor', 2]] },
    mood: 'bright',
    keys: ['C', 'G', 'D', 'A', 'E', 'F'],
    progressions: {
      major: ['I V vi IV', 'vi IV I V', 'I vi IV V', 'IVmaj7 V7 iii7 vi', 'I IV vi V', 'I V IV IV'],
      minor: ['i bVI bIII bVII', 'i iv bVII bIII', 'i bVII bVI bVII'],
    },
    harmonicRhythm: 1,
    groove: 'pop',
    roles: [
      { id: 'drums', role: 'drums', name: 'Ударные', instrument: 'drums.electro', enter: 0.3, reverb: 0.12, volume: 0.85 },
      { id: 'bass', role: 'bass', name: 'Бас', instrument: 'bass.synth', part: 'eighths', enter: 0.3, register: [28, 52], volume: 0.7, sidechain: 0.25 },
      { id: 'piano', role: 'chords', name: 'Пианино', instrument: 'keys.piano', part: 'pulse8', enter: 0, register: [52, 74], volume: 0.5, reverb: 0.25 },
      { id: 'pad', role: 'pad', name: 'Пэд', instrument: 'pad.warm', part: 'sustain', enter: 0.55, register: [50, 74], volume: 0.35, reverb: 0.45, sidechain: 0.5 },
      { id: 'arp', role: 'arp', name: 'Плак', instrument: 'pluck.synth', part: 'up8', enter: 0.6, register: [60, 84], volume: 0.4, reverb: 0.3, delay: 0.25 },
      { id: 'lead', role: 'lead', name: 'Лид', instrument: 'lead.square', enter: 0.45, register: [64, 84], volume: 0.55, reverb: 0.3, delay: 0.15, melody: { density: 0.55, feel: 'normal' } },
    ],
  },

  sad: {
    name: 'Грустное пианино / драма',
    description: 'Фортепиано, струнные, медленный темп. Для драматичных сцен, концовок, воспоминаний.',
    bpm: [62, 80],
    scales: { dark: [['minor', 3]], bright: [['major', 2]] },
    mood: 'dark',
    keys: ['A', 'D', 'E', 'C', 'G', 'F'],
    progressions: {
      minor: ['i bVI bIII bVII', 'i iv bVII bIII', 'i bVI iv V', 'bVI bVII i i', 'i v bVI bIII'],
      major: ['vi IV I V', 'I V vi iii', 'IV I V vi', 'I vi IV V'],
    },
    harmonicRhythm: 1,
    groove: 'ballad',
    roles: [
      { id: 'piano', role: 'chords', name: 'Пианино (аккорды)', instrument: 'keys.piano', part: 'broken', enter: 0, register: [52, 72], volume: 0.55, reverb: 0.45 },
      { id: 'lead', role: 'lead', name: 'Пианино (мелодия)', instrument: 'keys.piano', enter: 0.3, register: [67, 86], volume: 0.6, reverb: 0.45, melody: { density: 0.35, feel: 'long' } },
      { id: 'strings', role: 'pad', name: 'Струнные', instrument: 'strings.ensemble', part: 'sustain', enter: 0.45, register: [50, 74], volume: 0.42, reverb: 0.5 },
      { id: 'cello', role: 'bass', name: 'Виолончели', instrument: 'strings.ensemble', part: 'sustain', enter: 0.55, register: [36, 55], volume: 0.45, reverb: 0.45 },
      { id: 'counter', role: 'counter', name: 'Скрипки', instrument: 'strings.ensemble', part: 'high', enter: 0.8, register: [72, 88], volume: 0.3, reverb: 0.55 },
      { id: 'drums', role: 'drums', name: 'Ударные', instrument: 'drums.acoustic', enter: 0.8, volume: 0.5, reverb: 0.25 },
    ],
  },
};

export const STYLE_ORDER = [
  'epic', 'action', 'synthwave', 'chiptune', 'fantasy', 'cozy', 'ambient', 'lofi', 'house',
  'trap', 'rock', 'pop', 'horror', 'stealth', 'jazz', 'tavern', 'oriental', 'sad',
];

/** Роли по умолчанию, если пользователь добавил блок, которого нет в стиле. */
export const GENERIC_ROLES = {
  drums: { role: 'drums', name: 'Ударные', instrument: 'drums.electro', enter: 0.35, volume: 0.8, reverb: 0.12 },
  bass: { role: 'bass', name: 'Бас', instrument: 'bass.synth', part: 'half', enter: 0.3, register: [28, 52], volume: 0.72 },
  chords: { role: 'chords', name: 'Аккорды', instrument: 'keys.piano', part: 'pulse8', enter: 0, register: [52, 74], volume: 0.5, reverb: 0.3 },
  pad: { role: 'pad', name: 'Пэд', instrument: 'pad.warm', part: 'sustain', enter: 0, register: [50, 74], volume: 0.42, reverb: 0.45 },
  arp: { role: 'arp', name: 'Арпеджио', instrument: 'pluck.synth', part: 'up8', enter: 0.45, register: [57, 81], volume: 0.42, reverb: 0.3, delay: 0.2 },
  lead: { role: 'lead', name: 'Мелодия', instrument: 'lead.square', enter: 0.45, register: [62, 84], volume: 0.55, reverb: 0.3, delay: 0.15, melody: { density: 0.5, feel: 'normal' } },
  counter: { role: 'counter', name: 'Подголосок', instrument: 'strings.ensemble', part: 'high', enter: 0.8, register: [67, 86], volume: 0.35, reverb: 0.45 },
  fx: { role: 'fx', name: 'Нарастание', instrument: 'fx.riser', part: 'risers', enter: 0.4, volume: 0.4, reverb: 0.4 },
};

/** Какую манеру игры брать по умолчанию для роли, если она не указана. */
export const DEFAULT_PART = {
  bass: 'half', chords: 'sustain', pad: 'sustain', arp: 'up8', counter: 'high', fx: 'risers',
};

/** Список манер для каждой роли — для выпадающего списка «как играть». */
export const PART_CHOICES = {
  bass: {
    whole: 'Целые ноты', half: 'Половинные', quarters: 'Четверти', rootfifth: 'Прима-квинта',
    eighths: 'Восьмые', octave8: 'Октавы восьмыми', offbeat: 'На офбитах', syncopated: 'Синкопы (фанк)',
    walking: 'Шагающий (джаз)', '808': '808 за бочкой', pulse16: 'Пульс 16-ми', driving16: 'Драйв 16-ми',
    chip8: '8-бит', spy: 'Крадущийся', sustain: 'Выдержанный', drone: 'Педаль (гул)', rock8: 'Рок восьмыми',
  },
  chords: {
    sustain: 'Выдержанные', pulse8: 'Восьмыми', pulse4: 'Четвертями', stabs: 'Стабы на офбит',
    broken: 'Ломаные (арпеджио)', ballad: 'Баллада', strum: 'Гитарный бой', powerChords: 'Пауэр-аккорды',
    lofiComp: 'Лоу-фай', jazzComp: 'Джазовый комп', waltz: 'Вальс (па-па)', swell: 'Нарастающие',
  },
  arp: {
    up16: 'Вверх 16-ми', updown16: 'Вверх-вниз 16-ми', up8: 'Вверх 8-ми', chipArp: '8-бит (быстро)',
    harp: 'Арфа (широко)', ostinato: 'Остинато (трейлер)', pulse8: 'Пульс 8-ми', sparse: 'Редкие ноты',
    creepy: 'Жуткая шкатулка',
  },
  counter: { high: 'Высокая линия', harmony: 'Второй голос к мелодии' },
  fx: { risers: 'Нарастание перед кульминацией', impacts: 'Удар в начале кульминации', vinyl: 'Шум винила' },
};
PART_CHOICES.pad = PART_CHOICES.chords;
