// Генерация мелодий по правилам композиции:
//  • мотив (1–2 такта) — основа темы; он повторяется, секвенцируется и варьируется;
//  • фраза строится как «вопрос — ответ» (A A' A C, где C — каденция);
//  • на сильных долях — звуки аккорда, на слабых — проходящие и вспомогательные звуки лада;
//  • в основном плавное движение по ступеням; после скачка — шаг в обратную сторону;
//  • конец темы — на тонике (закрытая каденция) или на неустойчивом звуке (открытая, для лупов).
import { chordAt } from '../core/song.js';
import { chordPcs, localScalePcs, mod, scaleNotesInRange, chordThirdPc, chordFifthPc } from '../core/theory.js';

// Ритмические ячейки на одну долю (4 шага): [смещение, длина]
const BEAT_CELLS = {
  q: [[0, 4]],
  ee: [[0, 2], [2, 2]],
  er: [[0, 2]],
  re: [[2, 2]],
  dot: [[0, 3], [3, 1]],
  sse: [[0, 1], [1, 1], [2, 2]],
  ess: [[0, 2], [2, 1], [3, 1]],
  ssss: [[0, 1], [1, 1], [2, 1], [3, 1]],
  syn: [[0, 1], [1, 2], [3, 1]],
  rest: [],
};

function cellWeights(density, feel) {
  const d = density;
  if (feel === 'long') {
    return [['q', 2], ['ee', 0.6 + d], ['er', 0.4], ['re', 0.3], ['dot', 0.5 * d], ['rest', 0.5 * (1 - d)]];
  }
  if (feel === 'busy') {
    return [['q', 0.8], ['ee', 2 + 2 * d], ['er', 0.5], ['re', 0.6], ['dot', 1], ['sse', 1.2 * d], ['ess', 1.2 * d], ['ssss', 1.2 * d * d], ['syn', 0.8], ['rest', 0.3]];
  }
  return [['q', 2], ['ee', 1 + 2.5 * d], ['er', 0.8], ['re', 0.8], ['dot', 1.2 * d], ['sse', 0.7 * d * d], ['ess', 0.7 * d * d], ['ssss', 0.4 * d * d * d], ['syn', 0.5 * d], ['rest', 0.9 * (1 - d)]];
}

/** Ритм мотива длиной beats долей. Возвращает [{ step, len }]. */
export function generateRhythm(rng, beats, density, feel = 'normal', beatsPerBar = 4) {
  const out = [];
  let b = 0;
  while (b < beats) {
    const left = beats - b;
    const opts = cellWeights(density, feel).map(([k, w]) => [k, w]);
    if (left >= 2 && b % 2 === 0) opts.push(['half', feel === 'long' ? 3 : 1.4 * (1 - density) + 0.2]);
    if (left >= beatsPerBar && b % beatsPerBar === 0 && feel === 'long') opts.push(['whole', 1.2]);
    const k = rng.weighted(opts);
    if (k === 'half') {
      out.push({ step: b * 4, len: 8 });
      b += 2;
    } else if (k === 'whole') {
      out.push({ step: b * 4, len: beatsPerBar * 4 });
      b += beatsPerBar;
    } else {
      for (const [o, l] of BEAT_CELLS[k]) out.push({ step: b * 4 + o, len: l });
      b += 1;
    }
  }
  if (!out.length || out[0].step !== 0) {
    if (rng.chance(0.8) || !out.length) out.unshift({ step: 0, len: out.length ? Math.min(2, out[0].step) || 2 : 4 });
  }
  // Минимум три ноты в мотиве, иначе тема не запоминается.
  while (out.length < 3 && beats >= 2) {
    const free = [];
    for (let s = 0; s < beats * 4; s += 2) if (!out.some((n) => s >= n.step && s < n.step + n.len)) free.push(s);
    if (!free.length) {
      const longest = out.reduce((a, n) => (n.len > a.len ? n : a), out[0]);
      if (longest.len < 2) break;
      const half = Math.floor(longest.len / 2);
      out.push({ step: longest.step + half, len: longest.len - half });
      longest.len = half;
    } else out.push({ step: rng.pick(free), len: 2 });
    out.sort((a, b2) => a.step - b2.step);
  }
  return out;
}

/** Изменение ритма для контрастной фразы: объединить две ноты или раздробить одну. */
export function varyRhythm(rng, rhythm) {
  const r = rhythm.map((n) => ({ ...n }));
  if (r.length > 3 && rng.chance(0.5)) {
    const i = rng.int(0, r.length - 2);
    r[i].len = r[i + 1].step + r[i + 1].len - r[i].step;
    r.splice(i + 1, 1);
  } else {
    const cands = r.filter((n) => n.len >= 2);
    if (cands.length) {
      const n = rng.pick(cands);
      const half = Math.max(1, Math.floor(n.len / 2));
      r.push({ step: n.step + half, len: n.len - half });
      n.len = half;
      r.sort((a, b) => a.step - b.step);
    }
  }
  return r;
}

// ---------------------------------------------------------------------------

function makeCtx({ timeline, keyPcs, range, spb }) {
  const lattice = scaleNotesInRange(keyPcs, 0, 127);
  const idxOf = (midi) => {
    let best = 0;
    let bd = Infinity;
    for (let i = 0; i < lattice.length; i++) {
      const d = Math.abs(lattice[i] - midi);
      if (d < bd) {
        bd = d;
        best = i;
      }
    }
    return best;
  };
  return { timeline, keyPcs, range, spb, lattice, idxOf };
}

function isStrong(step, len, spb) {
  if (step % spb === 0) return true;
  if (step % 8 === 0) return true;
  return step % 4 === 0 && len >= 3;
}

/** Ближайший звук аккорда к midi в пределах range. */
function nearestChordTone(midi, chord, range) {
  const pcs = chordPcs(chord);
  let best = midi;
  let bd = Infinity;
  for (let m = range[0]; m <= range[1]; m++) {
    if (!pcs.includes(mod(m, 12))) continue;
    const d = Math.abs(m - midi);
    if (d < bd || (d === bd && m < best)) {
      bd = d;
      best = m;
    }
  }
  return best;
}

function fitLocal(midi, chord, keyPcs) {
  if (!chord) return midi;
  const loc = localScalePcs(keyPcs, chord);
  if (loc.includes(mod(midi, 12))) return midi;
  for (let d = 1; d <= 2; d++) {
    if (loc.includes(mod(midi + d, 12))) return midi + d;
    if (loc.includes(mod(midi - d, 12))) return midi - d;
  }
  return midi;
}

/** Мелодическое движение: ступени лада относительно предыдущего звука. */
function chooseMove(rng, state, midi, center, pos) {
  if (state.lastLeap) {
    state.lastLeap = false;
    return -Math.sign(state.lastMove || 1);
  }
  const size = rng.weighted([[0, 0.14], [1, 0.5], [2, 0.22], [3, 0.09], [4, 0.05]]);
  let pUp = pos < 0.5 ? 0.6 : 0.4;
  if (midi > center + 5) pUp = 0.22;
  if (midi < center - 5) pUp = 0.78;
  const dir = rng.chance(pUp) ? 1 : -1;
  const mv = size * dir;
  state.lastLeap = size >= 3;
  state.lastMove = mv;
  return mv;
}

/** Мотив: ритм + высоты, привязанные к аккордам начиная с absStart. */
export function generateMotif(rng, mctx, rhythm, absStart, startMidi, motifLen) {
  const { timeline, keyPcs, range, lattice, idxOf, spb } = mctx;
  const center = (range[0] + range[1]) / 2;
  const state = { lastLeap: false, lastMove: 0 };
  let idx = idxOf(startMidi);
  const notes = [];
  rhythm.forEach((r, i) => {
    const abs = absStart + r.step;
    const ch = chordAt(timeline, abs)?.chord;
    if (i > 0) idx += chooseMove(rng, state, lattice[idx], center, r.step / motifLen);
    let midi = lattice[Math.max(0, Math.min(lattice.length - 1, idx))];
    if (midi > range[1]) {
      idx -= 2;
      midi = lattice[idx];
    }
    if (midi < range[0]) {
      idx += 2;
      midi = lattice[idx];
    }
    if (ch && (i === 0 || isStrong(abs, r.len, spb))) midi = nearestChordTone(midi, ch, range);
    else midi = fitLocal(midi, ch, keyPcs);
    idx = idxOf(midi);
    notes.push({ step: r.step, len: r.len, midi });
  });
  const base = idxOf(notes[0].midi);
  return { rhythm, notes, degrees: notes.map((n) => idxOf(n.midi) - base), startMidi: notes[0].midi };
}

/** Проигрывает мотив с новой стартовой высоты, подстраивая сильные доли под аккорды. */
function renderMotif(mctx, motif, absStart, startMidi, { varyEnd = 0, rng = null } = {}) {
  const { timeline, keyPcs, range, lattice, idxOf, spb } = mctx;
  const base = idxOf(startMidi);
  return motif.rhythm.map((r, i) => {
    let deg = motif.degrees[i];
    if (varyEnd && i >= motif.rhythm.length - varyEnd && rng) deg += rng.pick([-2, -1, 1, 2]);
    let midi = lattice[Math.max(0, Math.min(lattice.length - 1, base + deg))];
    while (midi > range[1]) midi -= 12;
    while (midi < range[0]) midi += 12;
    const abs = absStart + r.step;
    const ch = chordAt(timeline, abs)?.chord;
    if (ch && isStrong(abs, r.len, spb)) midi = nearestChordTone(midi, ch, range);
    else midi = fitLocal(midi, ch, keyPcs);
    return { step: r.step, len: r.len, midi };
  });
}

function cadenceTarget(mctx, abs, prevMidi, closed, tonicPc) {
  const ch = chordAt(mctx.timeline, abs)?.chord;
  const range = mctx.range;
  const pcs = ch ? chordPcs(ch) : [tonicPc];
  let targets;
  if (closed) targets = pcs.includes(tonicPc) ? [tonicPc] : [ch.root];
  else {
    targets = ch ? [chordThirdPc(ch), chordFifthPc(ch)].filter((p) => p !== tonicPc) : [];
    if (!targets.length) targets = pcs.filter((p) => p !== tonicPc);
    if (!targets.length) targets = pcs;
  }
  let best = prevMidi;
  let bd = Infinity;
  for (let m = range[0]; m <= range[1]; m++) {
    if (!targets.includes(mod(m, 12))) continue;
    const d = Math.abs(m - prevMidi);
    if (d < bd) {
      bd = d;
      best = m;
    }
  }
  return best;
}

/**
 * Мелодия секции.
 * @param {object} p
 * @param p.rng
 * @param p.timeline  аккорды секции (chordTimeline)
 * @param p.bars
 * @param p.spb       шагов в такте
 * @param p.keyPcs    звуки лада
 * @param p.tonicPc
 * @param p.range     [lo, hi]
 * @param p.density   0..1
 * @param p.feel      'long' | 'normal' | 'busy'
 * @param p.closed    закончить на тонике
 * @param p.motif     готовый мотив (для повторения темы в другой секции)
 * @returns {{notes: Array<{step,len,midi,vel}>, motif: object}}
 */
export function generateMelody(p) {
  const { rng, timeline, bars, spb, keyPcs, tonicPc, range, density = 0.5, feel = 'normal', closed = true } = p;
  const mctx = makeCtx({ timeline, keyPcs, range, spb });
  const beatsPerBar = spb / 4;
  const motifBars = p.motifBars || (bars >= 8 ? 2 : 1);
  const motifLen = motifBars * spb;
  const slots = Math.max(1, Math.floor(bars / motifBars));
  const center = Math.round((range[0] + range[1]) / 2);

  let motif = p.motif;
  if (!motif || motif.rhythm.some((r) => r.step >= motifLen)) {
    const rhythm = generateRhythm(rng, motifBars * beatsPerBar, density, feel, beatsPerBar);
    const firstChord = chordAt(timeline, 0)?.chord;
    const start = firstChord ? nearestChordTone(center + rng.int(-3, 3), firstChord, range) : center;
    motif = generateMotif(rng, mctx, rhythm, 0, start, motifLen);
  }

  // План фраз: A — тема, A1 — тема с изменённым концом, B — контраст, C1 — открытая каденция, C — финальная.
  let plan;
  if (slots === 1) plan = ['C'];
  else if (slots === 2) plan = ['A', 'C'];
  else if (slots === 3) plan = ['A', 'A1', 'C'];
  else {
    plan = [];
    for (let i = 0; i < slots; i++) {
      const pos = i % 4;
      const lastOfPhrase = pos === 3 || i === slots - 1;
      if (i === slots - 1) plan.push('C');
      else if (lastOfPhrase) plan.push('C1');
      else if (pos === 2 && rng.chance(0.4)) plan.push('B');
      else plan.push(pos === 1 ? 'A1' : 'A');
    }
  }

  const notes = [];
  let prevMidi = motif.startMidi;
  let bMotif = null;
  plan.forEach((kind, si) => {
    const slotStart = si * motifLen;
    const ch = chordAt(timeline, slotStart)?.chord;
    const start = ch ? nearestChordTone(motif.startMidi, ch, range) : motif.startMidi;
    let rendered;
    if (kind === 'A') rendered = renderMotif(mctx, motif, slotStart, start);
    else if (kind === 'A1') rendered = renderMotif(mctx, motif, slotStart, start, { varyEnd: 2, rng });
    else if (kind === 'B') {
      if (!bMotif) {
        const bStart = ch ? nearestChordTone(prevMidi + rng.pick([-3, 2, 4]), ch, range) : prevMidi;
        bMotif = generateMotif(rng, mctx, varyRhythm(rng, motif.rhythm), slotStart, bStart, motifLen);
      }
      rendered = renderMotif(mctx, bMotif, slotStart, ch ? nearestChordTone(bMotif.startMidi, ch, range) : bMotif.startMidi);
    } else {
      // Каденция: первая половина мотива, затем долгий звук.
      const half = motifLen / 2;
      const head = renderMotif(mctx, motif, slotStart, start).filter((n) => n.step < half - 1);
      const lastPrev = head.length ? head[head.length - 1].midi : prevMidi;
      const finalClosed = kind === 'C' ? closed : false;
      const tStep = head.length ? half : 0;
      const target = cadenceTarget(mctx, slotStart + tStep, lastPrev, finalClosed, tonicPc);
      const endLen = motifLen - tStep - (finalClosed ? 0 : 2);
      rendered = [...head, { step: tStep, len: Math.max(2, endLen), midi: target }];
    }
    for (const n of rendered) notes.push({ step: slotStart + n.step, len: n.len, midi: n.midi });
    if (rendered.length) prevMidi = rendered[rendered.length - 1].midi;
  });

  // Остаток тактов (если bars не делится на мотив) — выдержанный звук аккорда.
  const used = slots * motifLen;
  if (used < bars * spb) {
    const ch = chordAt(timeline, used)?.chord;
    notes.push({ step: used, len: bars * spb - used, midi: ch ? nearestChordTone(prevMidi, ch, range) : prevMidi });
  }

  // Длительности не перекрываются, громкость подчёркивает сильные доли.
  notes.sort((a, b) => a.step - b.step);
  for (let i = 0; i < notes.length; i++) {
    const n = notes[i];
    const next = notes[i + 1];
    if (next && n.step + n.len > next.step) n.len = Math.max(0.5, next.step - n.step);
    const accent = n.step % spb === 0 ? 0.12 : n.step % 4 === 0 ? 0.06 : 0;
    n.vel = Math.min(1, 0.68 + accent + rng.float(-0.04, 0.04));
  }
  return { notes, motif };
}

/** Мотив из готовых нот пользователя (для «развить идею»). */
export function motifFromNotes(notesMidi, motifLen, keyPcs) {
  const src = notesMidi.filter((n) => n.step < motifLen).sort((a, b) => a.step - b.step);
  if (src.length < 2) return null;
  const lattice = scaleNotesInRange(keyPcs, 0, 127);
  const idxOf = (m) => {
    let best = 0;
    let bd = Infinity;
    lattice.forEach((x, i) => {
      if (Math.abs(x - m) < bd) {
        bd = Math.abs(x - m);
        best = i;
      }
    });
    return best;
  };
  const base = idxOf(src[0].midi);
  return {
    rhythm: src.map((n) => ({ step: n.step, len: n.len })),
    notes: src.map((n) => ({ step: n.step, len: n.len, midi: n.midi })),
    degrees: src.map((n) => idxOf(n.midi) - base),
    startMidi: src[0].midi,
  };
}

/** Подголосок «терцией ниже» по лада (для 8-бит и дуэтов). */
export function harmonizeLine(notes, keyPcs, steps = -2, range = [48, 96]) {
  const lattice = scaleNotesInRange(keyPcs, 0, 127);
  return notes.map((n) => {
    let i = lattice.findIndex((x) => x >= n.midi);
    if (i < 0) i = lattice.length - 1;
    let m = lattice[Math.max(0, Math.min(lattice.length - 1, i + steps))];
    while (m < range[0]) m += 12;
    while (m > range[1]) m -= 12;
    return { ...n, midi: m, vel: (n.vel ?? 0.7) * 0.8 };
  });
}
