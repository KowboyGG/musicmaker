// Генераторы партий: бас, аккорды (разные фактуры), арпеджио, подголосок, эффекты.
// Все функции возвращают ноты в виде [{ step, len, midi, vel }] относительно начала секции.
import { chordAt } from '../core/song.js';
import {
  mod, voiceChord, chordPcs, localScalePcs, chordThirdPc, chordFifthPc, parseChord,
} from '../core/theory.js';
import { kickSteps } from './grooves.js';

const clampVel = (v) => Math.max(0.1, Math.min(1, v));

/** Отрезки аккордов внутри [from, to). */
function segmentsIn(timeline, from, to) {
  const out = [];
  for (const c of timeline) {
    const s = Math.max(from, c.start);
    const e = Math.min(to, c.end);
    if (e > s) out.push({ start: s, end: e, chord: c.chord, spanStart: c.start, spanEnd: c.end });
  }
  return out;
}

/** Нота с классом pc в окне [lo, hi], ближайшая к prev (или к центру окна). */
function placePc(pc, lo, hi, prev) {
  const cands = [];
  for (let m = lo; m <= hi; m++) if (mod(m, 12) === pc) cands.push(m);
  if (!cands.length) return lo + mod(pc - lo, 12);
  const ref = prev ?? (lo + hi) / 2;
  return cands.reduce((a, b) => (Math.abs(b - ref) < Math.abs(a - ref) ? b : a));
}

function nextChordAfter(timeline, step) {
  for (const c of timeline) if (c.start > step) return c.chord;
  return timeline[0]?.chord || null;
}

function intervalOf(chord, choices, fallback) {
  const iv = chord.intervals.map((i) => mod(i, 12)).find((i) => choices.includes(i));
  return iv ?? fallback;
}

// ---------------------------------------------------------------------------
// Бас

function bassTemplates(part, spb, rng, energy) {
  const beats = spb / 4;
  const T = [];
  const each = (step, fn) => {
    for (let s = 0; s < spb; s += step) T.push(fn(s));
  };
  switch (part) {
    case 'whole':
      T.push([0, spb, 'R']);
      break;
    case 'half':
      if (spb === 16) T.push([0, 8, 'R'], [8, 8, 'R']);
      else T.push([0, spb, 'R']);
      break;
    case 'rootfifth':
      if (spb === 16) T.push([0, 6, 'R'], [8, 6, '5-']);
      else T.push([0, 4, 'R']);
      break;
    case 'quarters':
      each(4, (s) => [s, 3.5, 'R']);
      break;
    case 'eighths':
    case 'rock8':
      each(2, (s) => [s, 1.7, s === spb - 2 && part === 'rock8' && rng.chance(0.35) ? 'A' : 'R']);
      break;
    case 'octave8':
      each(2, (s) => [s, 1.6, (s / 2) % 2 ? '8' : 'R']);
      break;
    case 'offbeat':
      for (let b = 0; b < beats; b++) T.push([b * 4 + 2, 1.6, 'R']);
      if (energy > 0.8) T.push([0, 1, 'R']);
      break;
    case 'syncopated': {
      if (spb !== 16) return bassTemplates('eighths', spb, rng, energy);
      const opts = [
        [[0, 3, 'R'], [3, 3, 'R'], [6, 2, '5'], [10, 4, 'R'], [14, 2, 'A']],
        [[0, 6, 'R'], [6, 2, '8'], [8, 4, '5'], [12, 2, 'R'], [14, 2, 'A']],
        [[0, 4, 'R'], [6, 2, 'R'], [8, 3, '5'], [11, 3, 'R'], [14, 2, '7']],
      ];
      return rng.pick(opts);
    }
    case 'walking':
      for (let b = 0; b < beats; b++) T.push([b * 4, 3.6, b === 0 ? 'R' : b === beats - 1 ? 'A' : 'W']);
      break;
    case 'pulse16': {
      const acc = spb === 16 ? [0, 3, 6, 8, 11, 14] : [0, 3, 6, 9];
      for (let s = 0; s < spb; s++) T.push([s, 0.8, 'R', acc.includes(s) ? 0.95 : 0.6]);
      break;
    }
    case 'driving16': {
      const pat = ['R', 'R', '8', 'R', 'R', 'R', '8', 'R', 'R', 'R', '8', 'R', 'R', '8', 'R', '8'];
      for (let s = 0; s < spb; s++) T.push([s, 0.8, pat[s % 16], s % 4 === 0 ? 0.95 : 0.65]);
      break;
    }
    case 'chip8': {
      const pat = rng.chance(0.5) ? ['R', '8', 'R', '8'] : ['R', '5', '8', '5'];
      each(2, (s) => [s, 1.8, pat[(s / 2) % 4]]);
      break;
    }
    case 'spy':
      if (spb !== 16) return bassTemplates('quarters', spb, rng, energy);
      T.push([0, 3, 'R'], [3, 1, 'R'], [4, 2, 'S1'], [6, 2, 'S2'], [8, 3, 'R'], [11, 1, 'R'], [12, 2, 'S2'], [14, 2, 'S1']);
      break;
    default:
      T.push([0, spb, 'R']);
  }
  return T;
}

function simplerBass(part) {
  return {
    eighths: 'half', rock8: 'half', octave8: 'quarters', offbeat: 'offbeat', syncopated: 'rootfifth',
    walking: 'half', pulse16: 'eighths', driving16: 'eighths', chip8: 'quarters', spy: 'spy', '808': '808',
  }[part] || part;
}

export function generateBass(p) {
  const { rng, timeline, bars, spb, keyPcs, range = [28, 52], energy = 0.6, drums = null, ending = false } = p;
  let part = p.part || 'whole';
  if (energy < 0.42) part = simplerBass(part);
  const lo = range[0] + 3;
  const hi = Math.min(range[1], lo + 14);
  const notes = [];
  let prevRoot = null;

  const resolve = (token, abs) => {
    const c = chordAt(timeline, abs)?.chord;
    if (!c) return null;
    const rootPc = c.bass ?? c.root;
    const root = placePc(rootPc, lo, hi, prevRoot);
    const fifth = intervalOf(c, [7, 6, 8], 7);
    const third = intervalOf(c, [3, 4, 2, 5], 4);
    const loc = localScalePcs(keyPcs, c);
    const scaleStep = (from, n) => {
      let m = from;
      let k = 0;
      const dir = Math.sign(n);
      while (k < Math.abs(n)) {
        m += dir;
        if (loc.includes(mod(m, 12))) k++;
      }
      return m;
    };
    switch (token) {
      case 'R': return root;
      case '8': return root + 12 <= range[1] + 2 ? root + 12 : root;
      case '5': return root + fifth;
      case '5-': return root + fifth - 12 >= range[0] ? root + fifth - 12 : root + fifth;
      case '3': return root + third;
      case '7': return root + intervalOf(c, [10, 11, 9], 10);
      case 'S1': return scaleStep(root, 1);
      case 'S2': return scaleStep(root, 2);
      case 'S-1': return scaleStep(root, -1);
      case 'A': {
        const nc = nextChordAfter(timeline, abs) || c;
        const target = placePc(nc.bass ?? nc.root, lo, hi, root);
        if (target === root) return root + fifth - (root + fifth - 12 >= range[0] ? 12 : 0);
        return target > root ? target - 1 : target + 1;
      }
      case 'W': {
        const nc = nextChordAfter(timeline, abs) || c;
        const target = placePc(nc.bass ?? nc.root, lo, hi, root);
        const opts = [root + third, root + fifth, scaleStep(root, 1), scaleStep(root, -1), root + 12]
          .filter((m) => m >= range[0] && m <= range[1] + 5);
        const mid = (root + target) / 2;
        return opts.sort((a, b) => Math.abs(a - mid) - Math.abs(b - mid))[rng.int(0, Math.min(1, opts.length - 1))];
      }
      default:
        return root;
    }
  };

  if (part === 'sustain' || part === 'drone') {
    for (const seg of timeline) {
      const c = seg.chord;
      if (!c) continue;
      const root = placePc(part === 'drone' ? p.tonicPc ?? c.root : c.bass ?? c.root, lo, hi, prevRoot);
      notes.push({ step: seg.start, len: seg.end - seg.start, midi: root, vel: 0.75 });
      prevRoot = root;
    }
  } else if (part === '808') {
    const total = bars * spb;
    let hits = kickSteps(drums, total);
    if (!hits.length) for (let b = 0; b < bars; b++) hits.push(b * spb, b * spb + (spb === 16 ? 10 : 6));
    hits.forEach((s, i) => {
      const next = hits[i + 1] ?? total;
      const len = Math.min(next - s, spb);
      let m = resolve('R', s);
      if (m == null) return;
      if (i % 4 === 3 && rng.chance(0.3)) m = resolve('8', s);
      notes.push({ step: s, len: Math.max(1, len - 0.25), midi: m, vel: 0.9 });
      prevRoot = m;
    });
  } else {
    for (let b = 0; b < bars; b++) {
      const T = bassTemplates(part, spb, rng, energy);
      for (const [off, len, token, vel] of T) {
        const abs = b * spb + off;
        const m = resolve(token, abs);
        if (m == null) continue;
        const seg = chordAt(timeline, abs);
        const maxLen = seg ? seg.end - abs : len;
        notes.push({ step: abs, len: Math.max(0.5, Math.min(len, maxLen)), midi: m, vel: vel ?? (off % 4 === 0 ? 0.88 : 0.72) });
        if (token === 'R') prevRoot = m;
      }
    }
  }

  if (ending) endOnTonic(notes, bars, spb, (lastStep) => {
    const c = chordAt(timeline, lastStep)?.chord;
    return c ? [placePc(c.bass ?? c.root, lo, hi, prevRoot)] : [];
  }, 0.85);
  return notes;
}

/** Последний такт финальной секции: один долгий аккорд/нота. */
function endOnTonic(notes, bars, spb, pitchesFn, vel) {
  const last = (bars - 1) * spb;
  for (let i = notes.length - 1; i >= 0; i--) if (notes[i].step >= last) notes.splice(i, 1);
  for (const n of notes) if (n.step + n.len > last) n.len = Math.max(0.5, last - n.step);
  for (const m of pitchesFn(last)) notes.push({ step: last, len: spb + spb / 2, midi: m, vel });
}

// ---------------------------------------------------------------------------
// Аккорды

const STRUM_PATTERNS = {
  16: {
    low: [[0, 8, 'D'], [8, 8, 'D']],
    mid: [[0, 4, 'D'], [4, 2, 'D'], [6, 4, 'U'], [10, 2, 'U'], [12, 2, 'D'], [14, 2, 'U']],
    high: [[0, 2, 'D'], [2, 2, 'U'], [4, 2, 'D'], [6, 2, 'U'], [8, 2, 'D'], [10, 2, 'U'], [12, 2, 'D'], [14, 2, 'U']],
  },
  12: {
    low: [[0, 12, 'D']],
    mid: [[0, 4, 'B'], [4, 4, 'D'], [8, 4, 'D']],
    high: [[0, 4, 'B'], [4, 2, 'D'], [6, 2, 'U'], [8, 2, 'D'], [10, 2, 'U']],
  },
};

const LOFI_COMP = [
  [[0, 7, 0.62], [10, 5, 0.5]],
  [[0, 3, 0.6], [3, 5, 0.5], [12, 4, 0.52]],
  [[0, 10, 0.6], [14, 2, 0.45]],
  [[2, 6, 0.55], [8, 2, 0.45], [11, 5, 0.5]],
];

const JAZZ_COMP = [
  [[0, 3, 0.62], [6, 2, 0.55]],
  [[2, 2, 0.55], [10, 3, 0.58]],
  [[0, 2, 0.6], [7, 3, 0.55], [14, 2, 0.5]],
  [[4, 3, 0.55], [12, 3, 0.55]],
];

function levelOf(energy) {
  return energy < 0.45 ? 'low' : energy < 0.78 ? 'mid' : 'high';
}

export function generateChords(p) {
  const { rng, timeline, bars, spb, range = [50, 74], energy = 0.6, ending = false } = p;
  const part = p.part || 'sustain';
  const level = levelOf(energy);
  const notes = [];
  let prev = p.shared?.prevVoicing || null;
  const maxNotes = p.maxNotes || (part === 'jazzComp' ? 3 : 4);

  const voicingFor = (chord) => {
    if (part === 'powerChords') {
      const root = placePc(chord.root, range[0], range[0] + 11, prev ? prev[0] : null);
      return [root, root + 7, root + 12];
    }
    if (part === 'jazzComp') {
      // «Шелл»: терция + септима (+ нона/квинта сверху)
      const third = intervalOf(chord, [3, 4, 2, 5], 4);
      const sev = intervalOf(chord, [10, 11, 9], null);
      const ext = chord.intervals.find((i) => i >= 13) ?? 7;
      const shell = parseChord(chord.symbol);
      const ivs = [third, sev ?? 7, ext];
      const tmp = { ...shell, intervals: ivs };
      return voiceChord(tmp, { low: range[0], high: range[1], prev, maxNotes: 3 });
    }
    return voiceChord(chord, { low: range[0], high: range[1], prev, maxNotes });
  };

  const push = (step, len, midis, vel) => {
    for (const m of midis) notes.push({ step, len, midi: m, vel: clampVel(vel + rng.float(-0.03, 0.03)) });
  };

  for (let b = 0; b < bars; b++) {
    const barStart = b * spb;
    const segs = segmentsIn(timeline, barStart, barStart + spb);
    for (const seg of segs) {
      if (!seg.chord) continue;
      const v = voicingFor(seg.chord);
      const segLen = seg.end - seg.start;
      const inSeg = (off, len) => {
        const s = barStart + off;
        if (s < seg.start || s >= seg.end) return null;
        return Math.max(0.5, Math.min(len, seg.end - s));
      };
      const bassNote = placePc(seg.chord.bass ?? seg.chord.root, range[0] - 12, range[0] - 1, null);
      switch (part) {
        case 'sustain':
        case 'swell': {
          // Долгий аккорд держится весь отрезок; если аккорд длиннее такта — не переигрываем.
          if (seg.start === seg.spanStart) push(seg.start, seg.spanEnd - seg.spanStart, v, part === 'swell' ? 0.5 : 0.6);
          break;
        }
        case 'pulse8':
        case 'pulse4': {
          const step = part === 'pulse4' || level === 'low' ? 4 : 2;
          for (let off = 0; off < spb; off += step) {
            const l = inSeg(off, step - 0.3);
            if (l) push(barStart + off, l, v, off % 4 === 0 ? 0.62 : 0.5);
          }
          break;
        }
        case 'stabs': {
          for (let beat = 0; beat < spb / 4; beat++) {
            const l = inSeg(beat * 4 + 2, 1.2);
            if (l) push(barStart + beat * 4 + 2, l, v, 0.6);
          }
          break;
        }
        case 'broken': {
          const order = spb === 16 ? [0, 1, 2, 1, 3, 2, 1, 2] : [0, 1, 2, 1, 2, 1];
          const rh = v.length >= 4 ? v : [...v, v[0] + 12];
          const l0 = inSeg(0, segLen);
          if (seg.start === barStart && l0) push(barStart, Math.min(spb, segLen), [bassNote], 0.62);
          order.forEach((k, i) => {
            const off = i * 2;
            const l = inSeg(off, 2.2);
            if (l) push(barStart + off, l, [rh[k % rh.length]], i === 0 ? 0.55 : 0.47);
          });
          break;
        }
        case 'ballad': {
          if (seg.start === barStart) push(barStart, Math.min(spb, segLen), [bassNote, bassNote + 12].filter((m) => m >= 28), 0.58);
          const hits = spb === 16 ? [0, 8] : [0];
          for (const off of hits) {
            const l = inSeg(off, 7.5);
            if (l) push(barStart + off, l, v, off === 0 ? 0.55 : 0.47);
          }
          if (level !== 'low' && spb === 16) {
            for (const off of [4, 12]) {
              const l = inSeg(off, 3.5);
              if (l) push(barStart + off, l, [v[v.length - 1]], 0.42);
            }
          }
          break;
        }
        case 'strum': {
          const pats = STRUM_PATTERNS[spb] || STRUM_PATTERNS[16];
          const guitarV = voiceChord(seg.chord, { low: Math.max(range[0], 52), high: Math.max(range[1], 69), prev, maxNotes: 4 });
          const low = placePc(seg.chord.bass ?? seg.chord.root, 40, 51, null);
          for (const [off, len, kind] of pats[level]) {
            const l = inSeg(off, len);
            if (!l) continue;
            if (kind === 'B') push(barStart + off, l, [low], 0.62);
            else if (kind === 'U') push(barStart + off, l, guitarV.slice(-3), 0.42);
            else push(barStart + off, l, [low, ...guitarV], off === 0 ? 0.66 : 0.55);
          }
          break;
        }
        case 'powerChords': {
          if (level === 'low') {
            if (seg.start === seg.spanStart || seg.start === barStart) push(seg.start, segLen, v, 0.65);
          } else {
            const rhythm = level === 'high' && spb === 16
              ? [[0, 3, 0.8], [3, 3, 0.7], [6, 2, 0.72], [8, 3, 0.8], [11, 3, 0.7], [14, 2, 0.72]]
              : Array.from({ length: spb / 2 }, (_, i) => [i * 2, 1.2, i % 2 ? 0.55 : 0.68]);
            for (const [off, len, vel] of rhythm) {
              const l = inSeg(off, len);
              if (l) push(barStart + off, l, v, vel);
            }
          }
          break;
        }
        case 'lofiComp': {
          if (spb !== 16) {
            const l = inSeg(0, segLen);
            if (l) push(seg.start, l, v, 0.55);
            break;
          }
          const pat = LOFI_COMP[(b + (p.variant || 0)) % LOFI_COMP.length];
          for (const [off, len, vel] of pat) {
            const l = inSeg(off, len);
            if (l) push(barStart + off, l, v, vel);
          }
          break;
        }
        case 'jazzComp': {
          const pat = spb === 16 ? rng.pick(JAZZ_COMP) : [[4, 3, 0.55], [8, 3, 0.55]];
          for (const [off, len, vel] of pat) {
            const l = inSeg(off, len);
            if (l) push(barStart + off, l, v, vel);
          }
          break;
        }
        case 'waltz': {
          const hits = spb === 12 ? [4, 8] : [4, 12];
          for (const off of hits) {
            const l = inSeg(off, 3);
            if (l) push(barStart + off, l, v, 0.5);
          }
          break;
        }
        default: {
          if (seg.start === seg.spanStart) push(seg.start, seg.spanEnd - seg.spanStart, v, 0.6);
        }
      }
      prev = v;
    }
  }
  if (p.shared) p.shared.prevVoicing = prev;

  if (ending) {
    endOnTonic(notes, bars, spb, (last) => {
      const c = chordAt(timeline, last)?.chord;
      return c ? voicingFor(c) : [];
    }, 0.6);
  }
  return notes;
}

// ---------------------------------------------------------------------------
// Арпеджио и остинато

function arpTones(chord, range, prev) {
  const v = voiceChord(chord, { low: range[0], high: Math.min(range[1], range[0] + 14), prev, maxNotes: 4 });
  const out = [...v];
  for (const m of v) if (m + 12 <= range[1]) out.push(m + 12);
  return [...new Set(out)].sort((a, b) => a - b);
}

export function generateArp(p) {
  const { rng, timeline, bars, spb, range = [55, 79], energy = 0.6, ending = false, keyPcs } = p;
  let part = p.part || 'up16';
  const level = levelOf(energy);
  if (level === 'low' && ['up16', 'updown16', 'chipArp'].includes(part)) part = 'up8';
  const notes = [];
  let prev = null;

  for (let b = 0; b < bars; b++) {
    const barStart = b * spb;
    for (const seg of segmentsIn(timeline, barStart, barStart + spb)) {
      if (!seg.chord) continue;
      const tones = arpTones(seg.chord, range, prev);
      prev = tones.slice(0, 4);
      const root = tones[0];
      const fifthPc = chordFifthPc(seg.chord);
      const fifth = tones.find((m) => mod(m, 12) === fifthPc) ?? root + 7;
      const rel = seg.start - seg.spanStart;
      switch (part) {
        case 'up16':
        case 'updown16':
        case 'up8':
        case 'chipArp': {
          const step = part === 'up8' ? 2 : 1;
          let seq;
          if (part === 'updown16') seq = [...tones.slice(0, 4), ...tones.slice(1, 3).reverse()];
          else if (part === 'chipArp') seq = tones.slice(0, 3);
          else seq = tones.slice(0, Math.min(tones.length, 4));
          for (let s = seg.start; s < seg.end; s += step) {
            const k = Math.round((s - seg.spanStart + rel * 0) / step);
            const m = seq[k % seq.length];
            notes.push({ step: s, len: step * (part === 'chipArp' ? 1 : 0.9), midi: m, vel: (s % 4 === 0 ? 0.72 : 0.58) });
          }
          break;
        }
        case 'harp': {
          const wide = [...tones, ...tones.map((m) => m + 12)].filter((m) => m <= range[1] + 7);
          let k = 0;
          for (let s = seg.start; s < seg.end; s += 2) {
            const m = wide[Math.min(k, wide.length - 1)];
            notes.push({ step: s, len: Math.min(seg.end - s, 6), midi: m, vel: 0.55 + (k === 0 ? 0.1 : 0) });
            k++;
          }
          break;
        }
        case 'ostinato': {
          const pat = ['R', 'R', '5', 'R', '8', 'R', '5', 'R'];
          const acc = spb === 16 ? [0, 3, 6, 8, 11, 14] : [0, 3, 6, 9];
          const stepLen = level === 'low' ? 2 : 1;
          for (let s = seg.start; s < seg.end; s += stepLen) {
            const tok = pat[(s - barStart) / stepLen % pat.length];
            const m = tok === 'R' ? root : tok === '5' ? fifth : root + 12;
            notes.push({ step: s, len: stepLen * 0.8, midi: m, vel: acc.includes(s - barStart) ? 0.85 : 0.6 });
          }
          break;
        }
        case 'pulse8': {
          for (let s = seg.start; s < seg.end; s += 2) notes.push({ step: s, len: 1.2, midi: ((s - barStart) / 2) % 2 ? fifth : root, vel: 0.6 });
          break;
        }
        case 'sparse': {
          const count = level === 'low' ? 1 : level === 'mid' ? 2 : 3;
          const slots = rng.shuffle([0, 4, 6, 8, 10, 12].filter((o) => o < spb)).slice(0, count).sort((a, b) => a - b);
          for (const off of slots) {
            const s = barStart + off;
            if (s < seg.start || s >= seg.end) continue;
            notes.push({ step: s, len: Math.min(8, seg.end - s), midi: rng.pick(tones.slice(-4)), vel: 0.45 + rng.float(0, 0.15) });
          }
          break;
        }
        case 'creepy': {
          if ((b % 2) !== 0 && level === 'low') break;
          const pcs = chordPcs(seg.chord);
          const hiT = tones.filter((m) => m >= range[0] + 5);
          const slots = [0, 3, 6, 8, 12].filter((o) => o < spb && rng.chance(0.55));
          for (const off of slots) {
            const s = barStart + off;
            if (s < seg.start || s >= seg.end) continue;
            let m = rng.pick(hiT.length ? hiT : tones);
            if (rng.chance(0.2)) m += 1; // полутон — «неправильная» нота шкатулки
            if (!pcs.includes(mod(m, 12)) && !localScalePcs(keyPcs, seg.chord).includes(mod(m, 12)) && rng.chance(0.5)) m -= 1;
            notes.push({ step: s, len: 3, midi: m, vel: 0.5 });
          }
          break;
        }
        default:
          break;
      }
    }
  }
  if (ending) {
    endOnTonic(notes, bars, spb, (last) => {
      const c = chordAt(timeline, last)?.chord;
      return c ? [arpTones(c, range, prev)[0]] : [];
    }, 0.55);
  }
  return notes;
}

// ---------------------------------------------------------------------------
// Подголосок: высокая выдержанная линия по звукам аккордов с плавным голосоведением.

export function generateCounter(p) {
  const { timeline, range = [67, 86], ending = false, spb, bars } = p;
  const notes = [];
  let prev = null;
  for (const seg of timeline) {
    if (!seg.chord) continue;
    const pcs = [chordThirdPc(seg.chord), chordFifthPc(seg.chord), seg.chord.root];
    let best = null;
    for (let m = range[0]; m <= range[1]; m++) {
      if (!pcs.includes(mod(m, 12))) continue;
      const score = prev == null ? Math.abs(m - (range[0] + range[1]) / 2) : Math.abs(m - prev) + (m === prev ? 0.5 : 0);
      if (best == null || score < best.score) best = { m, score };
    }
    if (!best) continue;
    const len = seg.end - seg.start;
    if (len > spb) {
      // Длинный аккорд: две ноты, вторая — соседний звук аккорда (движение).
      notes.push({ step: seg.start, len: spb, midi: best.m, vel: 0.55 });
      const other = pcs.map((pc) => placePc(pc, range[0], range[1], best.m)).filter((m) => m !== best.m)[0] ?? best.m;
      notes.push({ step: seg.start + spb, len: len - spb, midi: other, vel: 0.5 });
      prev = other;
    } else {
      notes.push({ step: seg.start, len, midi: best.m, vel: 0.55 });
      prev = best.m;
    }
  }
  if (ending) endOnTonic(notes, bars, spb, (last) => {
    const c = chordAt(timeline, last)?.chord;
    return c ? [placePc(c.root, range[0], range[1], prev)] : [];
  }, 0.5);
  return notes;
}

// ---------------------------------------------------------------------------
// Эффекты

export function generateFx(p) {
  const { part, bars, spb, nextHigher = false, energy = 0.6, kind } = p;
  const total = bars * spb;
  if (part === 'vinyl') return [{ step: 0, len: total, midi: 60, vel: 0.6 }];
  if (part === 'risers') {
    if (!nextHigher || bars < 2) return [];
    const len = Math.min(total, spb * 2);
    return [{ step: total - len, len, midi: 48, vel: 0.75 }];
  }
  if (part === 'impacts') {
    if (energy >= 0.8 || kind === 'chorus' || kind === 'loopB') return [{ step: 0, len: 8, midi: 31, vel: 0.9 }];
    return [];
  }
  return [];
}
