// Сборка песни целиком: структура, энергия секций, гармония, партии всех блоков.
import { createRng, randomSeed } from '../core/rng.js';
import {
  parsePitchClass, scalePcs, isMinorScale, prefersFlats, progressionToSymbols, pcName,
  midiToNote, noteToMidi, detectKey, harmonizeBars, chordSymbol, mod, KEY_NAMES, parseChord,
} from '../core/theory.js';
import {
  FORMAT_ID, FORMAT_VERSION, createTrack, chordTimeline, stepsPerBar, uniqueId, parseDrumPattern,
  drumPatternToString, ROLE_NAMES,
} from '../core/song.js';
import { INSTRUMENT_MAP, isDrumInstrument } from '../core/instruments-meta.js';
import { STYLES, GENERIC_ROLES, DEFAULT_PART } from './styles.js';
import { GROOVES, generateDrumPart } from './grooves.js';
import { generateBass, generateChords, generateArp, generateCounter, generateFx } from './parts.js';
import { generateMelody, motifFromNotes, harmonizeLine } from './melody.js';

export const LENGTHS = {
  loop8: { name: 'Луп 8 тактов', loop: true },
  loop16: { name: 'Луп 16 тактов (A + B)', loop: true },
  short: { name: 'Короткая (~30 сек)', target: 35 },
  medium: { name: 'Средняя (~1–1,5 мин)', target: 85 },
  long: { name: 'Длинная (~2–3 мин)', target: 150 },
};

export const SECTION_KINDS = {
  intro: { name: 'Вступление', energy: 0.28 },
  verse: { name: 'Куплет', energy: 0.52 },
  pre: { name: 'Подводка', energy: 0.66 },
  chorus: { name: 'Припев', energy: 0.86 },
  chorus2: { name: 'Финальный припев', energy: 1.0 },
  bridge: { name: 'Бридж', energy: 0.42 },
  outro: { name: 'Концовка', energy: 0.32 },
  loop: { name: 'Луп', energy: 0.75 },
  loopA: { name: 'Часть A', energy: 0.62 },
  loopB: { name: 'Часть B', energy: 0.86 },
};

const ROLE_ORDER = ['drums', 'bass', 'chords', 'pad', 'arp', 'lead', 'counter', 'fx'];

const TITLE_WORDS = {
  a: ['Последний', 'Тихий', 'Неоновый', 'Далёкий', 'Забытый', 'Ночной', 'Золотой', 'Холодный', 'Железный', 'Солнечный', 'Туманный', 'Старый'],
  n: ['рубеж', 'город', 'рассвет', 'берег', 'путь', 'огонь', 'замок', 'ветер', 'горизонт', 'лес', 'сигнал', 'сон'],
};

// ---------------------------------------------------------------------------

function buildStructure(length, barDur) {
  let plan;
  let order;
  switch (length) {
    case 'loop8':
      plan = [['loop', 8]];
      order = ['loop'];
      break;
    case 'loop16':
      plan = [['loopA', 8], ['loopB', 8]];
      order = ['loopA', 'loopB'];
      break;
    case 'short':
      plan = [['intro', 4], ['chorus', 8], ['outro', 4]];
      order = ['intro', 'chorus', 'outro'];
      break;
    case 'long':
      plan = [['intro', 8], ['verse', 8], ['pre', 4], ['chorus', 8], ['bridge', 8], ['chorus2', 8], ['outro', 4]];
      order = ['intro', 'verse', 'pre', 'chorus', 'verse', 'pre', 'chorus', 'bridge', 'chorus2', 'outro'];
      break;
    case 'medium':
    default:
      plan = [['intro', 4], ['verse', 8], ['chorus', 8], ['outro', 4]];
      order = ['intro', 'verse', 'chorus', 'verse', 'chorus', 'outro'];
  }
  // Медленный темп → слишком долго: укорачиваем секции вдвое.
  const target = LENGTHS[length]?.target;
  if (target) {
    const bars = order.reduce((a, k) => a + plan.find((p) => p[0] === k)[1], 0);
    if (bars * barDur > target * 1.5) plan = plan.map(([k, b]) => [k, Math.max(2, b / 2)]);
  }
  return { plan, order };
}

function pickScale(rng, style, mood) {
  let m = mood;
  if (!m || m === 'auto') m = rng.chance(0.75) ? style.mood : style.mood === 'dark' ? 'bright' : 'dark';
  const list = style.scales[m] || style.scales[style.mood];
  return rng.weighted(list);
}

function progressionsFor(style, scale) {
  const minor = isMinorScale(scale);
  const pool = style.progressions[minor ? 'minor' : 'major'] || style.progressions.minor || style.progressions.major;
  return pool;
}

/** Аккорды по тактам для секции. */
function sectionChords(progSymbols, bars, hr, { ending = false, tonicSymbol = null } = {}) {
  const out = [];
  for (let b = 0; b < bars; b++) out.push(progSymbols[Math.floor(b / hr) % progSymbols.length]);
  if (ending && tonicSymbol) out[bars - 1] = tonicSymbol;
  return out;
}

function roleFromInstrument(id) {
  if (!id) return 'chords';
  if (id.startsWith('drums.')) return 'drums';
  if (id.startsWith('bass.')) return 'bass';
  if (id.startsWith('pad.')) return 'pad';
  if (id.startsWith('fx.')) return 'fx';
  if (id.startsWith('lead.') || id.startsWith('wind.') || id.startsWith('mallet.')) return 'lead';
  if (id.startsWith('pluck.') || id === 'pulse.chip') return 'arp';
  return 'chords';
}
export { roleFromInstrument };

function levelFor(energy) {
  return energy < 0.55 ? 'low' : energy < 0.8 ? 'mid' : 'high';
}

function toJsonNotes(notes, flats) {
  return notes
    .filter((n) => n.midi >= 0 && n.midi <= 127 && n.len > 0)
    .map((n) => ({
      step: Math.round(n.step * 100) / 100,
      note: midiToNote(Math.round(n.midi), flats),
      len: Math.round(n.len * 100) / 100,
      vel: Math.round((n.vel ?? 0.75) * 100) / 100,
    }))
    .sort((a, b) => a.step - b.step || noteToMidi(a.note) - noteToMidi(b.note));
}

function fromJsonNotes(notes) {
  return (notes || []).map((n) => ({ step: n.step, len: n.len, midi: noteToMidi(n.note), vel: n.vel }));
}

/** Роли для генерации: роли стиля, перекрытые выбором пользователя. */
export function resolveRoles(style, userRoles) {
  if (!userRoles) return style.roles.map((r) => ({ ...r }));
  const out = [];
  for (const u of userRoles) {
    if (u.enabled === false) continue;
    const base = style.roles.find((r) => r.id === u.id) || GENERIC_ROLES[u.role] || GENERIC_ROLES.chords;
    out.push({ ...base, ...u, id: u.id, role: u.role || base.role });
  }
  return out;
}

// ---------------------------------------------------------------------------
// Генерация партии одной роли в одной секции.

function generateRolePart(role, sec, ctx) {
  const { rng, spb, keyPcs, tonicPc, flats, song, shared, style } = ctx;
  const timeline = chordTimeline(song, sec);
  const energy = sec.energy;
  const bars = sec.bars;
  const ending = ctx.isFinal;
  const common = { rng, timeline, bars, spb, keyPcs, tonicPc, energy, ending, register: role.register };
  const sharedFor = (shared[role.id] ||= {});
  const inst = INSTRUMENT_MAP[role.instrument];
  const range = role.register || inst?.range || [48, 72];

  switch (role.role) {
    case 'drums': {
      const groove = ctx.customGroove || (song.beatsPerBar === 3 ? style.groove3 || 'waltz' : style.groove || 'pop');
      return generateDrumPart({
        groove,
        level: levelFor(energy),
        bars,
        spb,
        rng,
        fill: ctx.fill,
        crash: ctx.crash,
        ending,
      });
    }
    case 'bass':
      return toJsonNotes(generateBass({ ...common, range, part: role.part || DEFAULT_PART.bass, drums: ctx.drumPart }), flats);
    case 'chords':
    case 'pad':
      return toJsonNotes(generateChords({ ...common, range, part: role.part || DEFAULT_PART.chords, shared: sharedFor, variant: rng.int(0, 3) }), flats);
    case 'arp':
      return toJsonNotes(generateArp({ ...common, range, part: role.part || DEFAULT_PART.arp }), flats);
    case 'lead': {
      const m = role.melody || { density: 0.5, feel: 'normal' };
      const group = ['chorus', 'chorus2', 'loopB', 'loop', 'outro'].includes(sec.kind) ? 'chorus' : sec.kind === 'bridge' ? 'bridge' : 'verse';
      const isChorus = group === 'chorus';
      let lo = range[0];
      let hi = range[1];
      if (isChorus) lo = Math.min(hi - 10, lo + 3);
      else hi = Math.max(lo + 10, hi - 3);
      const motifs = (shared.__motifs ||= {});
      const key = `${role.id}:${group}:${spb}`;
      let density = m.density + (isChorus ? 0.08 : group === 'verse' ? -0.08 : -0.12);
      if (sec.kind === 'outro') density -= 0.1;
      const closed = ending || ['chorus', 'chorus2', 'outro'].includes(sec.kind);
      const res = generateMelody({
        rng, timeline, bars, spb, keyPcs, tonicPc, range: [lo, hi],
        density: Math.max(0.1, Math.min(0.95, density)), feel: m.feel || 'normal',
        closed, motif: motifs[key] || ctx.ideaMotif || null,
      });
      if (!motifs[key]) motifs[key] = res.motif;
      ctx.leadNotes = res.notes;
      return toJsonNotes(res.notes, flats);
    }
    case 'counter': {
      if (role.part === 'harmony' && ctx.leadNotes) return toJsonNotes(harmonizeLine(ctx.leadNotes, keyPcs, -2, range), flats);
      return toJsonNotes(generateCounter({ ...common, range }), flats);
    }
    case 'fx':
      return toJsonNotes(generateFx({ part: role.part || 'risers', bars, spb, nextHigher: ctx.nextHigher, energy, kind: sec.kind }), flats);
    default:
      return [];
  }
}

function roleActive(role, sec) {
  if (sec.energy >= role.enter) return true;
  if (role.intro && (sec.kind === 'intro' || sec.kind === 'outro' || sec.kind === 'bridge')) return true;
  if (role.role === 'lead' && sec.kind === 'outro' && role.enter <= 0.65) return true;
  return false;
}

// ---------------------------------------------------------------------------

/**
 * Генерирует новую песню.
 * @param {object} opts
 * @param {string} opts.style        id стиля
 * @param {string} [opts.mood]       'auto' | 'bright' | 'dark'
 * @param {string} [opts.length]     ключ LENGTHS
 * @param {number} [opts.bpm]
 * @param {string} [opts.key]        тоника ("A", "F#")
 * @param {number} [opts.energy]     0..1
 * @param {Array}  [opts.roles]      [{ id, role, instrument, enabled, part }]
 * @param {number} [opts.seed]
 * @param {object} [opts.idea]       для «развить идею» (см. developSong)
 */
export function generateSong(opts = {}) {
  const seed = opts.seed ?? randomSeed();
  const rng = createRng(seed);
  const styleId = STYLES[opts.style] ? opts.style : 'synthwave';
  const style = STYLES[styleId];
  const length = LENGTHS[opts.length] ? opts.length : 'medium';
  const idea = opts.idea || null;

  const bpm = Math.round(idea?.bpm ?? opts.bpm ?? rng.int(style.bpm));
  const bpbChoices = Array.isArray(style.beatsPerBar) ? style.beatsPerBar : [style.beatsPerBar || 4];
  const beatsPerBar = idea?.beatsPerBar ?? rng.pick(bpbChoices);
  const scale = idea?.scale ?? pickScale(rng.fork('scale'), style, opts.mood);
  const tonicName = idea?.key ?? (opts.key && opts.key !== 'auto' ? opts.key : rng.pick(style.keys));
  const tonicPc = parsePitchClass(tonicName) ?? 9;
  const flats = prefersFlats(tonicPc, scale);
  const keyPcs = scalePcs(tonicPc, scale);
  const spb = beatsPerBar * 4;
  const barDur = (60 / bpm) * beatsPerBar;
  const energyShift = ((opts.energy ?? 0.5) - 0.5) * 0.5;

  const song = {
    format: FORMAT_ID,
    version: FORMAT_VERSION,
    title: opts.title || `${rng.pick(TITLE_WORDS.a)} ${rng.pick(TITLE_WORDS.n)}`,
    style: styleId,
    seed,
    bpm,
    key: pcName(tonicPc, flats),
    scale,
    beatsPerBar,
    swing: style.swing || 0,
    swingGrid: style.swingGrid || 16,
    loop: !!LENGTHS[length].loop,
    tracks: [],
    sections: [],
    arrangement: [],
  };

  // Блоки (роли) и дорожки
  let roles = resolveRoles(style, opts.roles);
  if (idea) {
    // Дорожки идеи заменяют роли того же типа.
    const ideaRoles = idea.tracks.map((t) => {
      const type = t.role || roleFromInstrument(t.instrument);
      const base = style.roles.find((r) => r.role === type) || GENERIC_ROLES[type] || GENERIC_ROLES.chords;
      return { ...base, id: t.id, name: t.name, instrument: t.instrument, role: type, fromIdea: true, track: t };
    });
    const covered = new Set(ideaRoles.map((r) => r.role));
    roles = [...ideaRoles, ...roles.filter((r) => !covered.has(r.role) || ['counter', 'fx', 'pad'].includes(r.role))];
  }
  const taken = new Set();
  for (const r of roles) {
    r.id = uniqueId(r.id || r.role, taken);
    taken.add(r.id);
  }
  roles.sort((a, b) => ROLE_ORDER.indexOf(a.role) - ROLE_ORDER.indexOf(b.role));
  song.tracks = roles.map((r) => {
    if (r.track) return { ...r.track, id: r.id, role: r.role, locked: r.track.locked };
    return createTrack({
      id: r.id,
      name: r.name || ROLE_NAMES[r.role] || r.id,
      instrument: r.instrument,
      role: r.role,
      volume: r.volume ?? 0.7,
      pan: r.pan ?? 0,
      reverb: r.reverb ?? 0.15,
      delay: r.delay ?? 0,
      sidechain: r.sidechain ?? 0,
    });
  });

  // Структура
  const { plan, order } = buildStructure(length, barDur);
  const coreKind = length === 'loop8' ? 'loop' : length === 'loop16' ? 'loopB' : 'chorus';

  // Гармония
  const pool = rng.fork('harmony').shuffle(progressionsFor(style, scale));
  const minor = isMinorScale(scale);
  const hr = style.harmonicRhythm || 1;
  const toSyms = (prog) => progressionToSymbols(prog, tonicPc, flats);
  const progs = {
    verse: toSyms(pool[0]),
    chorus: toSyms(pool[1 % pool.length]),
    bridge: toSyms(pool[2 % pool.length]),
  };
  if (idea?.chords?.length) progs.chorus = idea.chords;
  const tonicSym = chordSymbol(tonicPc, minor ? 'm' : '', flats);
  const preProg = toSyms(minor ? 'bVI bVI bVII bVII' : 'IV IV V V');

  const kindProg = (kind) => {
    switch (kind) {
      case 'intro':
      case 'verse':
      case 'loopA':
        return progs.verse;
      case 'pre':
        return preProg;
      case 'bridge':
        return progs.bridge;
      default:
        return progs.chorus;
    }
  };

  // Секции
  const lastKind = order[order.length - 1];
  const sections = plan.map(([kind, bars]) => {
    let b = bars;
    if (idea && kind === coreKind) b = Math.min(32, idea.bars * Math.max(1, Math.ceil(bars / idea.bars)));
    const energy = Math.max(0.05, Math.min(1, SECTION_KINDS[kind].energy + energyShift));
    const isFinal = !song.loop && kind === lastKind;
    const chords = idea && kind === coreKind
      ? sectionChords(idea.chords, b, 1)
      : sectionChords(kindProg(kind), b, kind === 'pre' ? 1 : hr, { ending: isFinal, tonicSymbol: tonicSym });
    return { id: kind, name: SECTION_KINDS[kind].name, kind, bars: b, energy: Math.round(energy * 100) / 100, chords, parts: {} };
  });
  song.sections = sections;
  song.arrangement = order.slice();

  // Материал идеи: мотив мелодии и грув ударных
  let ideaMotif = null;
  if (idea?.leadNotes?.length) ideaMotif = motifFromNotes(idea.leadNotes, Math.min(idea.bars, 2) * spb, keyPcs);
  let ideaGroove = null;
  const ideaDrums = idea?.tracks.find((t) => isDrumInstrument(t.instrument) && idea.parts[t.id] && Object.keys(idea.parts[t.id]).length);
  if (ideaDrums) ideaGroove = registerIdeaGroove(idea.parts[ideaDrums.id], idea.bars, spb);

  const shared = {};
  sections.forEach((sec, si) => {
    const pos = order.indexOf(sec.kind);
    const next = sections.find((s) => s.kind === order[pos + 1]) || (song.loop ? sections[0] : null);
    const nextHigher = !!next && next.energy > sec.energy + 0.05;
    const isFinal = !song.loop && sec.kind === lastKind;
    const ctx = {
      rng: null, spb, keyPcs, tonicPc, flats, song, shared, style, isFinal, nextHigher,
      fill: nextHigher || song.loop || sec.bars >= 8,
      crash: ['chorus', 'chorus2', 'loopB', 'loop', 'verse'].includes(sec.kind) && sec.energy >= 0.5,
      drumPart: null, leadNotes: null, ideaMotif: null, customGroove: null,
    };
    for (const role of roles) {
      ctx.rng = rng.fork(`${role.id}:${sec.kind}:${si}`);
      const ideaPart = role.fromIdea ? idea.parts[role.track.id] : null;
      const hasIdea = ideaPart && (Array.isArray(ideaPart) ? ideaPart.length : Object.keys(ideaPart).length);
      if (hasIdea && sec.kind === coreKind) {
        // Сам набросок остаётся нетронутым (повторяется, если секция длиннее).
        sec.parts[role.id] = repeatPart(ideaPart, idea.bars, sec.bars, spb, isDrumInstrument(role.instrument));
        if (role.role === 'drums') ctx.drumPart = sec.parts[role.id];
        if (role.role === 'lead') ctx.leadNotes = fromJsonNotes(sec.parts[role.id]);
        continue;
      }
      if (!roleActive(role, sec)) continue;
      if (hasIdea) {
        if (role.role === 'drums') ctx.customGroove = ideaGroove;
        else if (role.role === 'bass') {
          sec.parts[role.id] = adaptPatternToChords(fromJsonNotes(ideaPart), idea.chords, sec, song, flats, spb);
          continue;
        } else if (role.role === 'lead') ctx.ideaMotif = ideaMotif;
      }

      const part = generateRolePart(role, sec, ctx);
      ctx.customGroove = null;
      ctx.ideaMotif = null;
      if (Array.isArray(part) ? part.length : Object.keys(part).length) {
        sec.parts[role.id] = part;
        if (role.role === 'drums') ctx.drumPart = part;
      }
    }
  });

  if (ideaGroove) delete GROOVES[ideaGroove];
  // Удаляем пустые дорожки (роль ни разу не прозвучала).
  song.tracks = song.tracks.filter((t) => song.sections.some((s) => s.parts[t.id]));
  for (const t of song.tracks) {
    const r = roles.find((x) => x.id === t.id);
    if (r?.part && !t.part) t.part = r.part;
  }
  return song;
}

// ---------------------------------------------------------------------------
// «Развить идею»: секция-набросок становится припевом (или лупом), остальное достраивается.

function repeatPart(part, srcBars, dstBars, spb, drums) {
  if (drums) {
    const out = {};
    for (const [v, pat] of Object.entries(part)) {
      const cells = parseDrumPattern(pat, srcBars * spb);
      const full = [];
      for (let i = 0; i < dstBars * spb; i++) full.push(cells[i % cells.length]);
      out[v] = drumPatternToString(full, spb);
    }
    return out;
  }
  const out = [];
  const period = srcBars * spb;
  for (let off = 0; off < dstBars * spb; off += period) {
    for (const n of part) if (n.step + off < dstBars * spb) out.push({ ...n, step: n.step + off });
  }
  return out;
}

let ideaGrooveCounter = 0;
function registerIdeaGroove(drumPart, bars, spb) {
  const id = `__idea${++ideaGrooveCounter}`;
  const barPattern = (voices) => {
    const o = {};
    for (const v of voices) {
      if (!drumPart[v]) continue;
      o[v] = drumPatternToString(parseDrumPattern(drumPart[v], Math.min(bars, 2) * spb), spb);
    }
    return o;
  };
  const all = Object.keys(drumPart);
  GROOVES[id] = {
    low: barPattern(all.filter((v) => ['kick', 'rim', 'shaker', 'tom3'].includes(v))),
    mid: barPattern(all),
    high: barPattern(all),
    fill: 'snare',
  };
  if (!Object.keys(GROOVES[id].low).length) GROOVES[id].low = GROOVES[id].mid;
  return id;
}

/** Переносит басовый рисунок из идеи на аккорды другой секции (интервалы от баса аккорда сохраняются). */
function adaptPatternToChords(notes, ideaChords, sec, song, flats, spb) {
  const barNotes = notes.filter((n) => n.step < spb);
  const srcChord = parseChord(String(ideaChords[0] ?? '').split(/\s+/)[0]);
  const srcRoot = srcChord ? srcChord.bass ?? srcChord.root : mod(barNotes[0]?.midi ?? 0, 12);
  const tl = chordTimeline(song, sec);
  const out = [];
  for (let b = 0; b < sec.bars; b++) {
    for (const n of barNotes) {
      const abs = b * spb + n.step;
      const seg = tl.find((c) => abs >= c.start && abs < c.end);
      if (!seg?.chord) continue;
      const root = seg.chord.bass ?? seg.chord.root;
      let shift = mod(root - srcRoot, 12);
      if (shift > 6) shift -= 12;
      out.push({ step: abs, len: n.len, midi: n.midi + shift, vel: n.vel });
    }
  }
  return toJsonNotes(out, flats);
}

/**
 * Развивает набросок пользователя в полноценную песню.
 * @param song      текущая песня
 * @param opts      настройки генератора (стиль, длина, блоки...) + sourceSectionId
 */
export function developSong(song, opts = {}) {
  const src = song.sections.find((s) => s.id === opts.sourceSectionId) || song.sections[0];
  const spb = stepsPerBar(song);
  const ideaTracks = song.tracks.filter((t) => {
    const p = src.parts[t.id];
    return t.locked || (p && (Array.isArray(p) ? p.length : Object.keys(p).length));
  });
  if (!ideaTracks.length) throw new Error('В выбранной секции нет нот. Нарисуйте хотя бы пару нот или ритм — и нажмите ещё раз.');

  // Мелодические ноты идеи (для тональности и гармонии)
  const melodic = [];
  for (const t of ideaTracks) {
    if (isDrumInstrument(t.instrument)) continue;
    for (const n of src.parts[t.id] || []) melodic.push({ ...n, midi: noteToMidi(n.note), trackId: t.id });
  }

  let key = song.key;
  let scale = song.scale;
  if (melodic.length >= 3) {
    const tonic = parsePitchClass(song.key) ?? 0;
    const pcs = scalePcs(tonic, song.scale);
    const total = melodic.reduce((a, n) => a + n.len, 0);
    const inside = melodic.reduce((a, n) => a + (pcs.includes(mod(n.midi, 12)) ? n.len : 0), 0);
    if (inside / total < 0.85) {
      const det = detectKey(melodic.map((n) => ({ midi: n.midi, len: n.len })));
      if (det) {
        key = KEY_NAMES[det.tonic];
        scale = det.scale;
      }
    }
  }
  const tonicPc = parsePitchClass(key) ?? 0;
  const flats = prefersFlats(tonicPc, scale);

  // Аккорды идеи: заданные вручную или подобранные под мелодию.
  let chords = (src.chords || []).filter((c) => c && c.trim() && c.trim() !== '-');
  if (chords.length && chords.length < src.bars) chords = sectionChords(chords, src.bars, 1);
  if (!chords.length) {
    if (melodic.length) {
      const bassIds = new Set(ideaTracks.filter((t) => (t.role || roleFromInstrument(t.instrument)) === 'bass').map((t) => t.id));
      const upper = melodic.filter((n) => !bassIds.has(n.trackId));
      const lead = upper.length ? upper : melodic;
      const barNotes = [];
      for (let b = 0; b < src.bars; b++) {
        barNotes.push(lead.filter((n) => n.step >= b * spb && n.step < (b + 1) * spb).map((n) => ({ midi: n.midi, len: n.len, strong: n.step % 8 === 0 })));
      }
      chords = harmonizeBars(barNotes, tonicPc, scale, flats);
    } else {
      const style = STYLES[opts.style] || STYLES.synthwave;
      const prog = progressionToSymbols(progressionsFor(style, scale)[0], tonicPc, flats);
      chords = sectionChords(prog, src.bars, 1);
    }
  }

  const leadTrack = pickLeadTrack(ideaTracks, src);
  const leadNotes = leadTrack ? fromJsonNotes(src.parts[leadTrack.id]) : [];

  const idea = {
    bpm: song.bpm,
    beatsPerBar: song.beatsPerBar,
    key,
    scale,
    bars: src.bars,
    chords,
    tracks: ideaTracks.map((t) => ({ ...t, role: t.role || roleFromInstrument(t.instrument) })),
    parts: src.parts,
    leadNotes,
  };
  const out = generateSong({ ...opts, idea, title: song.title });
  out.swing = song.swing;
  out.swingGrid = song.swingGrid;
  return out;
}

function pickLeadTrack(tracks, src) {
  let best = null;
  let bestAvg = -Infinity;
  for (const t of tracks) {
    if (isDrumInstrument(t.instrument)) continue;
    const notes = src.parts[t.id] || [];
    if (!notes.length) continue;
    const role = t.role || roleFromInstrument(t.instrument);
    if (role === 'bass') continue;
    const avg = notes.reduce((a, n) => a + noteToMidi(n.note), 0) / notes.length + (role === 'lead' ? 12 : 0);
    if (avg > bestAvg) {
      bestAvg = avg;
      best = t;
    }
  }
  return best;
}

// ---------------------------------------------------------------------------
// Перегенерация частей существующей песни (кнопки 🎲 в редакторе).

function styleRoleFor(song, track) {
  const style = STYLES[song.style] || null;
  const type = track.role || roleFromInstrument(track.instrument);
  const fromStyle = style?.roles.find((r) => r.id === track.id) || style?.roles.find((r) => r.role === type);
  const base = fromStyle ? { ...fromStyle } : { ...(GENERIC_ROLES[type] || GENERIC_ROLES.chords) };
  if (fromStyle && fromStyle.instrument !== track.instrument) delete base.register;
  return { ...base, id: track.id, role: type, instrument: track.instrument, part: track.part || base.part };
}

function sectionContext(song, sec, rng) {
  const style = STYLES[song.style] || STYLES.pop;
  const tonicPc = parsePitchClass(song.key) ?? 0;
  const order = song.arrangement.length ? song.arrangement : song.sections.map((s) => s.id);
  const pos = order.indexOf(sec.id);
  const nextId = order[pos + 1] ?? (song.loop ? order[0] : null);
  const next = song.sections.find((s) => s.id === nextId);
  const energy = sec.energy ?? SECTION_KINDS[sec.kind]?.energy ?? 0.6;
  const isFinal = !song.loop && pos === order.length - 1 && order.indexOf(sec.id) === order.lastIndexOf(sec.id);
  return {
    rng, spb: stepsPerBar(song), keyPcs: scalePcs(tonicPc, song.scale), tonicPc,
    flats: prefersFlats(tonicPc, song.scale), song, shared: {}, style,
    isFinal, nextHigher: !!next && (next.energy ?? 0.6) > energy + 0.05,
    fill: true, crash: energy >= 0.6, drumPart: null, leadNotes: null, ideaMotif: null, customGroove: null,
    energy,
  };
}

/** Новая партия дорожки в секции. Возвращает партию (массив нот или объект паттернов). */
export function regeneratePart(song, sectionId, trackId, seed = randomSeed()) {
  const sec = song.sections.find((s) => s.id === sectionId);
  const track = song.tracks.find((t) => t.id === trackId);
  if (!sec || !track) return null;
  const rng = createRng(seed);
  const ctx = sectionContext(song, sec, rng);
  const role = styleRoleFor(song, track);
  const secView = { ...sec, energy: ctx.energy, kind: sec.kind || 'verse' };
  if (!sec.chords?.length) {
    secView.chords = [chordSymbol(ctx.tonicPc, isMinorScale(song.scale) ? 'm' : '', ctx.flats)];
  }
  const drumTrack = song.tracks.find((t) => isDrumInstrument(t.instrument));
  if (drumTrack) ctx.drumPart = sec.parts[drumTrack.id] || null;
  const leadTrack = song.tracks.find((t) => (t.role || roleFromInstrument(t.instrument)) === 'lead' && t.id !== trackId);
  if (leadTrack && sec.parts[leadTrack.id]) ctx.leadNotes = fromJsonNotes(sec.parts[leadTrack.id]);
  if (role.role === 'lead') ctx.shared.__motifs = {};
  return generateRolePart(role, secView, ctx);
}

/** Новая последовательность аккордов для секции (из прогрессий стиля). */
export function regenerateChords(song, sectionId, seed = randomSeed()) {
  const sec = song.sections.find((s) => s.id === sectionId);
  if (!sec) return null;
  const style = STYLES[song.style] || STYLES.pop;
  const rng = createRng(seed);
  const tonicPc = parsePitchClass(song.key) ?? 0;
  const flats = prefersFlats(tonicPc, song.scale);
  const prog = progressionToSymbols(rng.pick(progressionsFor(style, song.scale)), tonicPc, flats);
  return sectionChords(prog, sec.bars, style.harmonicRhythm || 1);
}

/** Перегенерирует все незаблокированные дорожки секции под её аккорды. */
export function regenerateSection(song, sectionId, seed = randomSeed()) {
  const sec = song.sections.find((s) => s.id === sectionId);
  if (!sec) return null;
  const rng = createRng(seed);
  const parts = { ...sec.parts };
  const sorted = [...song.tracks].sort((a, b) => ROLE_ORDER.indexOf(a.role || roleFromInstrument(a.instrument)) - ROLE_ORDER.indexOf(b.role || roleFromInstrument(b.instrument)));
  const view = { ...song, sections: song.sections.map((s) => (s.id === sectionId ? { ...s, parts } : s)) };
  for (const t of sorted) {
    if (t.locked) continue;
    const had = sec.parts[t.id];
    const hadContent = had && (Array.isArray(had) ? had.length : Object.keys(had).length);
    if (!hadContent) continue;
    const p = regeneratePart(view, sectionId, t.id, rng.int(1, 1e9));
    if (p) parts[t.id] = p;
  }
  return parts;
}
