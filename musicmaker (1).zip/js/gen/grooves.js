// Библиотека грувов (паттернов ударных) по жанрам.
// Каждый грув: три уровня энергии (low/mid/high), паттерн — 1 или 2 такта ("|" разделяет такты).
// Символы: X — акцент, x — удар, o — тихий удар, 2/3/4 — дробь внутри шага, . — пауза.
import { parseDrumPattern, drumPatternToString } from '../core/song.js';

export const GROOVES = {
  pop: {
    low: { kick: 'x.......x.......', rim: '....x.......x...', hat: 'x.o.x.o.x.o.x.o.' },
    mid: { kick: 'x.......x.x.....|x.......x...x...', snare: '....x.......x...', hat: 'x.x.x.x.x.x.x.x.' },
    high: { kick: 'x.......x.x.....|x.....x.x...x...', snare: '....X.......X...', clap: '....x.......x...', hat: 'xoxoxoxoxoxoxoxo', openhat: '..............x.' },
    fill: 'snare',
  },
  rock: {
    low: { kick: 'x.......x.......', hat: 'x.x.x.x.x.x.x.x.', rim: '....x.......x...' },
    mid: { kick: 'x.....x.x.......|x.....x.x.x.....', snare: '....X.......X...', hat: 'x.x.x.x.x.x.x.x.' },
    high: { kick: 'x.....x.x.x.....|x.....x.x.....x.', snare: '....X.......X...', ride: 'X.x.X.x.X.x.X.x.' },
    fill: 'toms',
  },
  four: {
    low: { kick: 'x...x...x...x...', hat: '..x...x...x...x.' },
    mid: { kick: 'X...X...X...X...', clap: '....x.......x...', hat: '..x...x...x...x.', shaker: 'o.o.o.o.o.o.o.o.' },
    high: { kick: 'X...X...X...X...', clap: '....x.......x...', openhat: '..x...x...x...x.', hat: 'xo.oxo.oxo.oxo.o' },
    fill: 'build',
  },
  synthwave: {
    low: { kick: 'x.......x.......', hat: 'x.x.x.x.x.x.x.x.' },
    mid: { kick: 'x.......x.......|x.......x..x....', snare: '....X.......X...', hat: 'x.x.x.x.x.x.x.x.' },
    high: { kick: 'x...x...x...x...', snare: '....X.......X...', clap: '....x.......x...', hat: 'xoxoxoxoxoxoxoxo' },
    fill: 'toms',
  },
  halftime: {
    low: { kick: 'x...............', hat: 'x.x.x.x.x.x.x.x.' },
    mid: { kick: 'x.........x.....', snare: '........X.......', hat: 'x.x.x.x.x.x.x.x.' },
    high: { kick: 'x.....x...x.....|x.........x..x..', snare: '........X.......', clap: '........x.......', hat: 'xoxoxoxoxoxoxoxo' },
    fill: 'snare',
  },
  trap: {
    low: { kick: 'x.........x.....', hat: 'x.x.x.x.x.x.x.x.' },
    mid: { kick: 'x......x..x.....|x.........x..x..', snare: '........X.......', hat: 'x.x.x.x.x.x.x3x.|x.x.x.x.x.x.4.x.' },
    high: { kick: 'x......x..x...x.|x.x.......x..x..', snare: '........X.......', clap: '........x.......', hat: 'xxx.x.xxx3x.x.x.|x.xxx.x.x.x.4.3.', openhat: '......x.........' },
    fill: 'roll',
    noCrash: true,
  },
  boombap: {
    low: { kick: 'x.........x.....', hat: 'x.x.x.x.x.x.x.x.' },
    mid: { kick: 'x.........x.x...|x......x..x.....', snare: '....x.......x...', hat: 'x.o.x.o.x.o.x.oo' },
    high: { kick: 'x.........x.x...|x......x..x...x.', snare: '....x..o....x...|....x.......x.o.', hat: 'x.x.x.x.x.x.x.x.', openhat: '..............x.' },
    fill: 'ghost',
    noCrash: true,
  },
  dnb: {
    low: { kick: 'x.........x.....', hat: 'x.x.x.x.x.x.x.x.' },
    mid: { kick: 'x.........x.....|x.........x..x..', snare: '....x.......x...', hat: 'x.x.x.x.x.x.x.x.' },
    high: { kick: 'x.........x.....|x.x.......x.....', snare: '....X.......X..o|....X..o....X...', hat: 'xoxoxoxoxoxoxoxo', ride: 'x.x.x.x.x.x.x.x.' },
    fill: 'snare',
  },
  breakbeat: {
    low: { kick: 'x.x.......x.....', hat: 'x.x.x.x.x.x.x.x.' },
    mid: { kick: 'x.x.......x.....', snare: '....x..o.o..x..o', hat: 'x.x.x.x.x.x.x.x.' },
    high: { kick: 'x.x.......xx....|x.x.......x...x.', snare: '....X..o.o..X..o|.o..X..o.o..X...', hat: 'xoxoxoxoxoxoxoxo', openhat: '..............x.' },
    fill: 'snare',
  },
  chip: {
    low: { kick: 'x.......x.......', hat: 'x.x.x.x.x.x.x.x.' },
    mid: { kick: 'x.......x.x.....', snare: '....x.......x...', hat: 'x.x.x.x.x.x.x.x.' },
    high: { kick: 'x...x...x.x.x...', snare: '....x.......x.x.', hat: 'xxxxxxxxxxxxxxxx' },
    fill: 'chip',
  },
  epic: {
    low: { kick: 'X...............|X.......x.......', tom3: '........x.......|..............x.' },
    mid: { kick: 'X.....x.X.......', tom2: '....x.......x.x.', tom3: '..........x.....' },
    high: { kick: 'X..x..x.X..x..x.', tom1: '....x.......x...', tom2: '..x.......x.....', snare: 'x.o.x.o.x.o.xoxo' },
    fill: 'epic',
  },
  waltz: {
    low: { kick: 'x...........', shaker: 'o.o.o.o.o.o.' },
    mid: { kick: 'x...........', rim: '....x...x...', hat: 'x.o.x.o.x.o.' },
    high: { kick: 'x.......x...|x...........', snare: '....x...x...', hat: 'x.x.x.x.x.x.', tom3: '..........x.' },
    fill: 'toms',
  },
  folk: {
    low: { tom3: 'x.......x.......', shaker: 'o.o.o.o.o.o.o.o.' },
    mid: { kick: 'x.......x.......', tom3: 'x..x..x.x..x..x.', rim: '....x.......x...', shaker: 'x.o.x.o.x.o.x.o.' },
    high: { kick: 'x...x...x...x...', snare: '....x.......x...', tom3: 'x.xxx.xxx.xxx.xx', shaker: 'xoxoxoxoxoxoxoxo' },
    fill: 'toms',
  },
  ambient: {
    low: { shaker: '..o...o...o...o.' },
    mid: { kick: 'x.........x.....', rim: '........x.......', shaker: 'o.o.o.o.o.o.o.o.' },
    high: { kick: 'x.......x.......', snare: '....o.......x...', hat: 'o.o.o.o.o.o.o.o.' },
    fill: 'none',
    noCrash: true,
  },
  jazz: {
    low: { ride: 'x...x.x.x...x.x.', hat: '....x.......x...' },
    mid: { ride: 'x...x.x.x...x.x.', hat: '....x.......x...', kick: 'o...o...o...o...', snare: '..........o.....|......o......o..' },
    high: { ride: 'X...x.x.X...x.x.', hat: '....x.......x...', kick: 'o...o...o..xo...', snare: '......o...o..o..|..o.......o...x.' },
    fill: 'jazz',
    noCrash: true,
  },
  stealth: {
    low: { rim: '....x.......x...', shaker: 'o.o.o.o.o.o.o.o.' },
    mid: { kick: 'x.....x...x.....', rim: '....x.......x...', hat: 'o.xoo.xoo.xoo.xo' },
    high: { kick: 'x.....x...x.....|x.....x...x...x.', snare: '....x.......x...', hat: 'xoxoxoxoxoxoxoxo', tom3: '..............x.' },
    fill: 'toms',
    noCrash: true,
  },
  heartbeat: {
    low: { kick: 'X..x............' },
    mid: { kick: 'X..x............', tom3: '........o.......' },
    high: { kick: 'X..x....X..x....', tom3: 'x.......x.......' },
    fill: 'none',
    noCrash: true,
  },
  oriental: {
    low: { tom3: 'x.......x.......', rim: '..x...x.....x...' },
    mid: { tom3: 'x.......x.......', rim: '..x...x.....x...', shaker: 'o.o.o.o.o.o.o.o.', kick: 'x.......x.......' },
    high: { tom3: 'x.......x.......', rim: '..x...x.....x.x.', tom2: '...x.......x....', shaker: 'xoxoxoxoxoxoxoxo', kick: 'x.......x.......' },
    fill: 'toms',
  },
  cozy: {
    low: { shaker: 'o.o.o.o.o.o.o.o.', rim: '....x.......x...' },
    mid: { kick: 'x.......x.......', rim: '....x.......x...', shaker: 'x.o.x.o.x.o.x.o.' },
    high: { kick: 'x.......x.x.....', clap: '....x.......x...', hat: 'x.x.x.x.x.x.x.x.', shaker: 'o.o.o.o.o.o.o.o.' },
    fill: 'snare',
  },
  ballad: {
    low: { kick: 'x...............', rim: '........x.......' },
    mid: { kick: 'x.......x.......', snare: '....o.......x...', hat: 'o.o.o.o.o.o.o.o.' },
    high: { kick: 'x.......x.x.....', snare: '....x.......x...', hat: 'x.o.x.o.x.o.x.o.' },
    fill: 'toms',
  },
};

// ---------------------------------------------------------------------------

function put(cells, i, vel, n = 1) {
  if (i >= 0 && i < cells.length) cells[i] = { vel, n };
}

function applyFill(type, voices, barStart, spb, strong) {
  const end = barStart + spb;
  const clear = (from, names) => {
    for (const nm of names) if (voices[nm]) for (let i = from; i < end; i++) voices[nm][i] = null;
  };
  const ensure = (nm) => (voices[nm] ||= new Array(voices._len).fill(null));
  const ramp = (k, n) => 0.45 + 0.55 * (k / Math.max(1, n - 1));
  switch (type) {
    case 'snare': {
      const n = strong ? 8 : 4;
      const from = end - n;
      clear(from, ['hat', 'openhat', 'snare', 'clap', 'ride', 'shaker']);
      ensure('snare');
      for (let k = 0; k < n; k++) if (!strong || k >= 4 || k % 2 === 0) put(voices.snare, from + k, ramp(k, n));
      break;
    }
    case 'toms': {
      const from = end - 6;
      clear(from, ['hat', 'openhat', 'snare', 'clap', 'ride', 'rim', 'shaker']);
      ['tom1', 'tom1', 'tom2', 'tom2', 'tom3', 'tom3'].forEach((t, k) => put(ensure(t), from + k, 0.6 + k * 0.07));
      break;
    }
    case 'build': {
      clear(barStart, ['hat', 'openhat', 'clap', 'snare', 'shaker']);
      ensure('snare');
      for (let i = barStart; i < end; i++) {
        const k = i - barStart;
        if (k < spb / 2 ? k % 2 === 0 : true) put(voices.snare, i, 0.35 + 0.65 * (k / spb));
      }
      if (voices.kick) for (let i = end - 4; i < end; i++) voices.kick[i] = null;
      break;
    }
    case 'roll': {
      ensure('hat');
      put(voices.hat, end - 4, 0.7, 3);
      put(voices.hat, end - 3, 0.7, 4);
      put(voices.hat, end - 2, 0.75, 4);
      put(voices.hat, end - 1, 0.8, 3);
      put(ensure('snare'), end - 1, 0.7);
      break;
    }
    case 'chip': {
      clear(end - 4, ['hat', 'snare']);
      for (let k = 0; k < 4; k++) put(ensure('snare'), end - 4 + k, 0.55 + k * 0.12);
      break;
    }
    case 'epic': {
      const from = end - 8;
      clear(from, ['snare', 'tom1', 'tom2', 'tom3']);
      for (let k = 0; k < 8; k++) {
        const t = ['tom3', 'tom3', 'tom2', 'tom2', 'tom1', 'tom2', 'tom1', 'tom1'][k];
        put(ensure(t), from + k, 0.55 + k * 0.06);
        put(ensure('snare'), from + k, 0.35 + k * 0.08);
      }
      break;
    }
    case 'jazz': {
      put(ensure('snare'), end - 3, 0.6);
      put(ensure('tom1'), end - 2, 0.6);
      put(ensure('tom2'), end - 1, 0.7);
      break;
    }
    case 'ghost': {
      put(ensure('snare'), end - 3, 0.42);
      put(ensure('snare'), end - 1, 0.5);
      break;
    }
    default:
      break;
  }
}

/**
 * Генерирует партию ударных для секции.
 * @returns {Object<string,string>} voice → строка-паттерн
 */
export function generateDrumPart({ groove, level, bars, spb, rng, fill = true, crash = false, ending = false, fillType = null }) {
  const g = GROOVES[groove] || GROOVES.pop;
  const layer = g[level] || g.mid;
  const total = bars * spb;
  const voices = { _len: total };
  for (const [voice, pat] of Object.entries(layer)) voices[voice] = parseDrumPattern(pat, total);

  // Небольшие вариации: каждый 4-й такт — лишний удар бочки или открытый хэт в конце такта.
  for (let b = 3; b < bars; b += 4) {
    if (!rng.chance(0.5)) continue;
    const i = b * spb + spb - 2;
    if (voices.kick && !voices.kick[i] && rng.chance(0.5)) put(voices.kick, i, 0.7);
    else if (voices.hat && level !== 'low') put(voices.openhat ||= new Array(total).fill(null), i, 0.6);
  }

  if (crash && !g.noCrash && level !== 'low') put(voices.crash ||= new Array(total).fill(null), 0, 0.9);

  if (fill && bars >= 1) {
    const type = fillType || g.fill || 'snare';
    applyFill(type, voices, (bars - 1) * spb, spb, level === 'high');
    // Лёгкая сбивка в середине длинной секции
    if (bars >= 8 && type !== 'none' && rng.chance(0.6)) applyFill(type === 'build' ? 'snare' : type, voices, (bars / 2 - 1) * spb + spb / 2, spb / 2, false);
  }

  if (ending) {
    const last = (bars - 1) * spb;
    for (const k of Object.keys(voices)) {
      if (k === '_len') continue;
      for (let i = last; i < total; i++) voices[k][i] = null;
    }
    put(voices.kick ||= new Array(total).fill(null), last, 1);
    if (!g.noCrash || groove === 'ambient') put(voices.crash ||= new Array(total).fill(null), last, 0.9);
  }

  const out = {};
  for (const [k, cells] of Object.entries(voices)) {
    if (k === '_len') continue;
    if (cells.some(Boolean)) out[k] = drumPatternToString(cells, spb);
  }
  return out;
}

/** Шаги (в секции), на которых звучит бочка — для баса 808, который играет вместе с бочкой. */
export function kickSteps(drumPart, total) {
  if (!drumPart?.kick) return [];
  return parseDrumPattern(drumPart.kick, total)
    .map((c, i) => (c ? i : -1))
    .filter((i) => i >= 0);
}
