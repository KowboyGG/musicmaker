// Офлайн-рендер песни в аудиобуфер (для WAV). Тот же микшер и те же инструменты, что и в плеере.
import { Mixer } from './mixer.js';
import { compileSong } from '../core/timeline.js';

/**
 * @param song
 * @param {{sampleRate?:number, seamlessLoop?:boolean, onlyTrackId?:string|null, tail?:number, normalize?:boolean}} opts
 * @returns {Promise<{channels: Float32Array[], sampleRate:number, duration:number}>}
 */
export async function renderSong(song, { sampleRate = 44100, seamlessLoop = false, onlyTrackId = null, tail = 4, normalize = true, onProgress = null } = {}) {
  const compiled = compileSong(song, { onlyTrackId });
  const L = compiled.duration;
  const total = Math.ceil((L + tail) * sampleRate);
  const ctx = new OfflineAudioContext(2, total, sampleRate);
  const mixer = new Mixer(ctx);
  const renderSongObj = onlyTrackId
    ? { ...song, tracks: song.tracks.map((t) => ({ ...t, mute: t.id !== onlyTrackId, solo: false })) }
    : song;
  mixer.update(renderSongObj);
  await mixer.prepare(song, compiled);
  mixer.gate.gain.value = 1;
  const bd = compiled.beatDur;
  for (let b = 0; b * bd < L - 1e-9; b++) mixer.duck(b * bd, bd);

  // Ноты планируются кусками: если создать все узлы сразу, браузер обрабатывает
  // весь огромный граф на каждом шаге и рендер становится в разы медленнее.
  const evs = compiled.events;
  let idx = 0;
  const scheduleUntil = (tEnd) => {
    while (idx < evs.length && evs[idx].time < tEnd) {
      mixer.playEvent(evs[idx], evs[idx].time);
      idx++;
    }
  };
  const CHUNK = 1;
  const AHEAD = 0.2;
  scheduleUntil(CHUNK + AHEAD);
  const quantum = 128 / sampleRate;
  for (let t = CHUNK; t < L; t += CHUNK) {
    const at = Math.floor(t / quantum) * quantum;
    ctx.suspend(at).then(() => {
      scheduleUntil(at + CHUNK + AHEAD);
      if (onProgress) onProgress(at / (L + tail));
      ctx.resume();
    });
  }
  const buf = await ctx.startRendering();

  let channels = [buf.getChannelData(0), buf.getChannelData(1)];
  const loopLen = Math.round(L * sampleRate);
  if (seamlessLoop) {
    // Хвост (реверберация, отзвучивающие ноты) переносится в начало — луп склеивается без щелчка.
    channels = channels.map((ch) => {
      const out = new Float32Array(loopLen);
      out.set(ch.subarray(0, loopLen));
      for (let i = loopLen; i < ch.length; i++) {
        const j = (i - loopLen) % loopLen;
        out[j] += ch[i];
      }
      return out;
    });
  } else {
    let last = loopLen;
    for (let i = channels[0].length - 1; i > loopLen; i--) {
      if (Math.abs(channels[0][i]) > 1e-4 || Math.abs(channels[1][i]) > 1e-4) {
        last = i;
        break;
      }
    }
    const end = Math.min(channels[0].length, last + Math.floor(sampleRate * 0.05));
    channels = channels.map((ch) => {
      const out = ch.slice(0, end);
      const fade = Math.min(out.length, Math.floor(sampleRate * 0.05));
      for (let i = 0; i < fade; i++) out[out.length - 1 - i] *= i / fade;
      return out;
    });
  }

  if (normalize) {
    let peak = 0;
    for (const ch of channels) for (let i = 0; i < ch.length; i++) peak = Math.max(peak, Math.abs(ch[i]));
    if (peak > 0.001) {
      const k = 0.89 / peak;
      for (const ch of channels) for (let i = 0; i < ch.length; i++) ch[i] *= k;
    }
  }
  return { channels, sampleRate, duration: channels[0].length / sampleRate };
}

/** Простая статистика для проверки рендера (пик, RMS). */
export function audioStats({ channels }) {
  let peak = 0;
  let sum = 0;
  let n = 0;
  for (const ch of channels) {
    for (let i = 0; i < ch.length; i++) {
      const v = ch[i];
      peak = Math.max(peak, Math.abs(v));
      sum += v * v;
      n++;
    }
  }
  return { peak, rms: Math.sqrt(sum / Math.max(1, n)) };
}
