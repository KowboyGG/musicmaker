// Звуки, которые считаются заранее (один раз на высоту ноты) и затем проигрываются как сэмплы:
// щипковые струны по алгоритму Карплуса — Стронга и аддитивное фортепиано.
import { mtof, clamp, seededNoise } from './dsp.js';

const cache = new Map();
const GEN_SR = 44100;

function makeBuffer(data, sr) {
  const b = new AudioBuffer({ length: data.length, numberOfChannels: 1, sampleRate: sr });
  b.getChannelData(0).set(data);
  return b;
}

function normalize(data, peak = 0.9) {
  let m = 0;
  for (let i = 0; i < data.length; i++) m = Math.max(m, Math.abs(data[i]));
  if (m > 0) {
    const k = peak / m;
    for (let i = 0; i < data.length; i++) data[i] *= k;
  }
  return data;
}

// Пресеты струн: t60 — время затухания на ноте C3 (секунды), bright — яркость щипка,
// pick — место щипка (доля длины струны), S — «гладкость» петли (0.5 темнее, 0.9 ярче/дольше).
export const STRING_PRESETS = {
  steel: { t60: 3.2, bright: 0.75, pick: 0.18, S: 0.56, max: 4 },
  nylon: { t60: 2.6, bright: 0.45, pick: 0.2, S: 0.52, max: 3.5 },
  electric: { t60: 3.8, bright: 0.55, pick: 0.25, S: 0.58, max: 4.5 },
  bass: { t60: 3.0, bright: 0.28, pick: 0.2, S: 0.53, max: 3 },
  upright: { t60: 1.4, bright: 0.2, pick: 0.25, S: 0.51, max: 2 },
  harp: { t60: 3.5, bright: 0.3, pick: 0.45, S: 0.54, max: 4 },
  pizz: { t60: 0.7, bright: 0.35, pick: 0.35, S: 0.5, max: 1.2 },
};

/** Щипковая струна (Карплус — Стронг с дробной задержкой через фазовращатель). */
export function stringBuffer(midi, presetName) {
  const key = `ks:${presetName}:${midi}`;
  if (cache.has(key)) return cache.get(key);
  const p = STRING_PRESETS[presetName] || STRING_PRESETS.steel;
  const sr = GEN_SR;
  const f = mtof(midi);
  const t60 = clamp(p.t60 * Math.pow(2, -(midi - 48) / 24), 0.25, p.max);
  const total = Math.floor(sr * Math.min(p.max, t60 * 1.05 + 0.05));
  const out = new Float32Array(total);

  const S = p.S;
  const loopDelay = sr / f - (1 - S);
  let Ni = Math.floor(loopDelay);
  let frac = loopDelay - Ni;
  if (frac < 0.1 && Ni > 2) {
    Ni -= 1;
    frac += 1;
  }
  const C = (1 - frac) / (1 + frac);
  const rho = Math.pow(0.001, 1 / (f * t60));

  // Возбуждение: отфильтрованный шум + гребёнка по месту щипка.
  const noise = seededNoise(Ni, midi * 131 + presetName.length * 17);
  const exc = new Float32Array(Ni);
  let lp = 0;
  const a = clamp(p.bright, 0.05, 1);
  for (let i = 0; i < Ni; i++) {
    lp += a * (noise[i] - lp);
    exc[i] = lp;
  }
  const pickOff = Math.max(1, Math.floor(p.pick * Ni));
  const buf = new Float32Array(Ni);
  for (let i = 0; i < Ni; i++) buf[i] = exc[i] - (i >= pickOff ? exc[i - pickOff] : 0) * 0.9;

  let idx = 0;
  let prevX = 0;
  let apX1 = 0;
  let apY1 = 0;
  let dcX = 0;
  let dcY = 0;
  for (let i = 0; i < total; i++) {
    const x = buf[idx];
    // Удаление постоянной составляющей
    dcY = x - dcX + 0.995 * dcY;
    dcX = x;
    out[i] = dcY;
    const avg = rho * (S * x + (1 - S) * prevX);
    prevX = x;
    const y = C * avg + apX1 - C * apY1;
    apX1 = avg;
    apY1 = y;
    buf[idx] = y;
    idx++;
    if (idx >= Ni) idx = 0;
  }
  const fadeN = Math.min(2000, total);
  for (let i = 0; i < fadeN; i++) out[total - 1 - i] *= i / fadeN;
  const b = makeBuffer(normalize(out, 0.85), sr);
  cache.set(key, b);
  return b;
}

/** Фортепиано: сумма негармоничных обертонов с двухстадийным затуханием, биениями и призвуком молоточка. */
export function pianoBuffer(midi) {
  const key = `piano:${midi}`;
  if (cache.has(key)) return cache.get(key);
  const sr = 32000;
  const f0 = mtof(midi);
  const dur = clamp(6 * Math.pow(2, -(midi - 36) / 20), 0.9, 4.2);
  const total = Math.floor(sr * dur);
  const out = new Float32Array(total);
  const B = 0.00012 * Math.pow(2, (midi - 60) / 20);
  const tau0 = dur / 4.2;
  const nyq = Math.min(sr * 0.45, 11000);

  const partials = [];
  for (let k = 1; k <= 18; k++) {
    const fk = k * f0 * Math.sqrt(1 + B * k * k);
    if (fk >= nyq) break;
    const strike = Math.abs(Math.sin((Math.PI * k) / 7.6)) * 0.9 + 0.1;
    const amp = strike / Math.pow(k, 1.05) * (midi > 72 ? Math.pow(0.8, k - 1) : 1);
    const tau = tau0 / (1 + 0.45 * (k - 1));
    partials.push({ f: fk, amp, tauFast: tau * 0.22, tauSlow: tau });
    if (k <= 5) partials.push({ f: fk * (1 + 0.00045 * (6 - k)), amp: amp * 0.5, tauFast: tau * 0.22, tauSlow: tau * 1.1 });
  }

  for (const pt of partials) {
    const w = (2 * Math.PI * pt.f) / sr;
    const c = Math.cos(w);
    const s = Math.sin(w);
    let x = 1;
    let y = 0;
    const dFast = Math.exp(-1 / (pt.tauFast * sr));
    const dSlow = Math.exp(-1 / (pt.tauSlow * sr));
    let eFast = 0.65 * pt.amp;
    let eSlow = 0.35 * pt.amp;
    for (let i = 0; i < total; i++) {
      const nx = x * c - y * s;
      y = x * s + y * c;
      x = nx;
      if ((i & 1023) === 1023) {
        const r = Math.sqrt(x * x + y * y);
        x /= r;
        y /= r;
      }
      out[i] += y * (eFast + eSlow);
      eFast *= dFast;
      eSlow *= dSlow;
    }
  }
  // Удар молоточка
  const hn = Math.floor(sr * 0.012);
  const noise = seededNoise(hn, midi * 7 + 3);
  let lp = 0;
  for (let i = 0; i < hn; i++) {
    lp += 0.35 * (noise[i] - lp);
    out[i] += lp * 0.12 * (1 - i / hn);
  }
  for (let i = 0; i < 24; i++) out[i] *= i / 24;
  const fadeN = Math.min(3000, total);
  for (let i = 0; i < fadeN; i++) out[total - 1 - i] *= i / fadeN;
  const b = makeBuffer(normalize(out, 0.8), sr);
  cache.set(key, b);
  return b;
}

/** Треск винила: редкие щелчки + тихое шипение (зацикливается). */
export function vinylBuffer() {
  const key = 'vinyl';
  if (cache.has(key)) return cache.get(key);
  const sr = GEN_SR;
  const n = sr * 4;
  const out = new Float32Array(n);
  const noise = seededNoise(n, 4242);
  let lp = 0;
  for (let i = 0; i < n; i++) {
    lp += 0.08 * (noise[i] - lp);
    out[i] = lp * 0.25;
  }
  const rnd = seededNoise(n, 99);
  for (let i = 0; i < n - 200; i++) {
    if (rnd[i] > 0.99975) {
      const amp = 0.3 + Math.abs(rnd[i + 1]) * 0.7;
      const len = 20 + Math.floor(Math.abs(rnd[i + 2]) * 120);
      for (let k = 0; k < len; k++) out[i + k] += amp * noise[(i + k * 3) % n] * Math.exp(-k / (len / 4));
    }
  }
  const b = makeBuffer(normalize(out, 0.7), sr);
  cache.set(key, b);
  return b;
}
