// Синтезированные наборы ударных. Имена барабанов общие для всех наборов,
// поэтому паттерн можно переключить с «электро» на «акустику» без правок.
import { Voice, perc, pulseWave, createDrive, createFilter, chain } from './dsp.js';

const METAL_RATIOS = [2, 3, 4.16, 5.43, 6.79, 8.21];

function kick(ctx, dest, t, vel, p) {
  const v = new Voice(ctx, t);
  const o = v.osc(p.wave === 'pulse' ? pulseWave(ctx, 0.5) : p.wave || 'sine', p.f0);
  o.frequency.setValueAtTime(p.f0, t);
  o.frequency.exponentialRampToValueAtTime(p.f1, t + p.pitchDecay);
  const g = v.gain(0);
  let end = perc(g.gain, t, { a: 0.001, decay: p.decay, peak: vel });
  o.connect(g).connect(dest);
  if (p.click) {
    const n = v.noise();
    const f = v.filter('highpass', p.clickFreq || 1500);
    const ng = v.gain(0);
    perc(ng.gain, t, { a: 0.0005, decay: 0.015, peak: vel * p.click });
    n.connect(f).connect(ng).connect(dest);
  }
  if (p.thump) {
    const n = v.noise();
    const f = v.filter('lowpass', 500, 1);
    const ng = v.gain(0);
    end = Math.max(end, perc(ng.gain, t, { a: 0.001, decay: 0.25, peak: vel * p.thump }));
    n.connect(f).connect(ng).connect(dest);
  }
  return v.finish(end);
}

function snare(ctx, dest, t, vel, p) {
  const v = new Voice(ctx, t);
  const o = v.osc(p.bodyWave || 'triangle', p.body);
  o.frequency.setValueAtTime(p.body * 1.2, t);
  o.frequency.exponentialRampToValueAtTime(p.body * 0.85, t + 0.05);
  const og = v.gain(0);
  let end = perc(og.gain, t, { a: 0.001, decay: p.bodyDecay || 0.12, peak: vel * (p.bodyAmt ?? 0.6) });
  o.connect(og).connect(dest);
  const n = v.noise();
  const hp = v.filter('highpass', p.noiseHp || 1200, 0.7);
  const pk = v.filter('peaking', p.noisePeak || 5000, 1, 4);
  const ng = v.gain(0);
  end = Math.max(end, perc(ng.gain, t, { a: 0.001, decay: p.noiseDecay || 0.2, peak: vel * (p.noiseAmt ?? 0.75) }));
  n.connect(hp).connect(pk).connect(ng).connect(dest);
  return v.finish(end);
}

function clap(ctx, dest, t, vel, p) {
  const v = new Voice(ctx, t);
  const n = v.noise();
  const bp = v.filter('bandpass', p.freq || 1100, p.q || 1.1);
  const g = v.gain(0);
  g.gain.setValueAtTime(0, t);
  for (let i = 0; i < 3; i++) {
    const tt = t + i * 0.011;
    g.gain.setValueAtTime(vel * 0.9, tt);
    g.gain.setTargetAtTime(0.05 * vel, tt + 0.001, 0.003);
  }
  const tail = t + 0.034;
  g.gain.setValueAtTime(vel * 0.8, tail);
  g.gain.setTargetAtTime(0.0001, tail, (p.decay || 0.18) / 4);
  n.connect(bp).connect(g).connect(dest);
  return v.finish(tail + (p.decay || 0.18) * 1.3);
}

function metal(v, ctx, dest, t, vel, base, decay, { bp = 10000, hp = 7000, amt = 0.35 } = {}) {
  const mix = v.gain(1);
  for (const r of METAL_RATIOS) v.osc('square', base * r).connect(mix);
  const b = v.filter('bandpass', bp, 0.8);
  const h = v.filter('highpass', hp, 0.7);
  const g = v.gain(0);
  const end = perc(g.gain, t, { a: 0.0005, decay, peak: vel * amt });
  mix.connect(b).connect(h).connect(g).connect(dest);
  return end;
}

function noiseHit(v, dest, t, vel, { type = 'highpass', freq = 7000, q = 0.7, decay = 0.05, amt = 0.5, a = 0.0005 } = {}) {
  const n = v.noise();
  const f = v.filter(type, freq, q);
  const g = v.gain(0);
  const end = perc(g.gain, t, { a, decay, peak: vel * amt });
  n.connect(f).connect(g).connect(dest);
  return end;
}

function hat(ctx, dest, t, vel, p, open) {
  const v = new Voice(ctx, t);
  const decay = open ? p.openDecay || 0.35 : p.decay || 0.05;
  let end = t;
  if (p.metal !== false) end = metal(v, ctx, dest, t, vel, p.base || 40, decay, { bp: p.bp || 10000, hp: p.hp || 7000, amt: p.metalAmt ?? 0.3 });
  end = Math.max(end, noiseHit(v, dest, t, vel, { freq: p.noiseHp || 8000, decay: decay * 0.9, amt: p.noiseAmt ?? 0.2 }));
  return v.finish(end);
}

function cymbal(ctx, dest, t, vel, p) {
  const v = new Voice(ctx, t);
  let end = metal(v, ctx, dest, t, vel, p.base || 60, p.decay || 1.6, { bp: p.bp || 7000, hp: p.hp || 4000, amt: p.metalAmt ?? 0.18 });
  end = Math.max(end, noiseHit(v, dest, t, vel, { freq: p.noiseHp || 5000, decay: (p.decay || 1.6) * 0.9, amt: p.noiseAmt ?? 0.3 }));
  return v.finish(end);
}

function ride(ctx, dest, t, vel, p) {
  const v = new Voice(ctx, t);
  let end = metal(v, ctx, dest, t, vel, p.base || 72, p.decay || 1.1, { bp: 6000, hp: 3500, amt: 0.14 });
  const ping = v.osc('sine', p.ping || 3100);
  const pg = v.gain(0);
  end = Math.max(end, perc(pg.gain, t, { a: 0.001, decay: 0.5, peak: vel * 0.05 }));
  ping.connect(pg).connect(dest);
  return v.finish(end);
}

function tom(ctx, dest, t, vel, f, p) {
  const v = new Voice(ctx, t);
  const o = v.osc(p.wave || 'sine', f);
  o.frequency.setValueAtTime(f * 1.3, t);
  o.frequency.exponentialRampToValueAtTime(f * (p.drop || 0.75), t + (p.pitchDecay || 0.18));
  const g = v.gain(0);
  let end = perc(g.gain, t, { a: 0.001, decay: p.decay || 0.4, peak: vel * 0.9 });
  o.connect(g).connect(dest);
  if (p.noise !== 0) end = Math.max(end, noiseHit(v, dest, t, vel, { type: 'lowpass', freq: p.noiseLp || 2500, decay: 0.08, amt: p.noise ?? 0.2 }));
  return v.finish(end);
}

function rim(ctx, dest, t, vel, p) {
  const v = new Voice(ctx, t);
  const o = v.osc(p.wave || 'triangle', p.freq || 1700);
  const g = v.gain(0);
  let end = perc(g.gain, t, { a: 0.0005, decay: p.decay || 0.04, peak: vel * 0.6 });
  o.connect(g).connect(dest);
  end = Math.max(end, noiseHit(v, dest, t, vel, { type: 'bandpass', freq: p.noiseFreq || 2500, q: 2, decay: 0.02, amt: 0.4 }));
  return v.finish(end);
}

function shaker(ctx, dest, t, vel, p) {
  const v = new Voice(ctx, t);
  const end = noiseHit(v, dest, t, vel, { type: 'bandpass', freq: p.freq || 7000, q: 1, decay: p.decay || 0.07, amt: 0.45, a: 0.012 });
  return v.finish(end);
}

// Каждый барабан один раз «записывается» в буфер (офлайн), дальше играется как сэмпл —
// это в разы дешевле, чем синтезировать удар заново.
const SAMPLE_SR = 44100;
const VOICE_LEN = { crash: 3.2, ride: 2.2, openhat: 0.8, kick: 1.4, tom1: 1.2, tom2: 1.2, tom3: 1.3 };

function makeKit(params, { gain = 0.8, bus = null } = {}) {
  const P = params;
  const samples = new Map();
  let preparing = null;
  const synth = (ctx, dest, t, voice, vel) => {
    switch (voice) {
      case 'kick': return kick(ctx, dest, t, vel, P.kick);
      case 'snare': return snare(ctx, dest, t, vel, P.snare);
      case 'clap': return clap(ctx, dest, t, vel, P.clap);
      case 'hat': return hat(ctx, dest, t, vel, P.hat, false);
      case 'openhat': return hat(ctx, dest, t, vel, P.hat, true);
      case 'crash': return cymbal(ctx, dest, t, vel, P.crash);
      case 'ride': return ride(ctx, dest, t, vel, P.ride || {});
      case 'tom1': return tom(ctx, dest, t, vel, P.toms.f[0], P.toms);
      case 'tom2': return tom(ctx, dest, t, vel, P.toms.f[1], P.toms);
      case 'tom3': return tom(ctx, dest, t, vel, P.toms.f[2], P.toms);
      case 'rim': return rim(ctx, dest, t, vel, P.rim || {});
      case 'shaker': return shaker(ctx, dest, t, vel, P.shaker || {});
      default: return null;
    }
  };
  return {
    kind: 'drums',
    gain,
    bus,
    /** Предрасчёт всех барабанов набора (асинхронно, один раз). */
    prepareAsync() {
      if (preparing) return preparing;
      if (typeof OfflineAudioContext === 'undefined') return Promise.resolve();
      preparing = Promise.all(DRUM_VOICE_LIST.map(async (voice) => {
        const len = VOICE_LEN[voice] || 0.7;
        const octx = new OfflineAudioContext(1, Math.ceil(len * SAMPLE_SR), SAMPLE_SR);
        synth(octx, octx.destination, 0, voice, 1);
        const buf = await octx.startRendering();
        samples.set(voice, buf);
      })).catch(() => {});
      return preparing;
    },
    play(ctx, dest, t, voice, vel) {
      const buf = samples.get(voice);
      if (!buf) return synth(ctx, dest, t, voice, vel);
      const v = new Voice(ctx, t);
      const src = v.sample(buf);
      const g = v.gain(vel);
      src.connect(g).connect(dest);
      return v.finish(t + buf.duration);
    },
  };
}

const DRUM_VOICE_LIST = ['kick', 'snare', 'clap', 'hat', 'openhat', 'crash', 'ride', 'tom1', 'tom2', 'tom3', 'rim', 'shaker'];

export const DRUM_KITS = {
  'drums.acoustic': makeKit({
    kick: { f0: 120, f1: 52, pitchDecay: 0.035, decay: 0.38, click: 0.35, clickFreq: 2500, thump: 0.25 },
    snare: { body: 190, bodyAmt: 0.55, noiseDecay: 0.24, noiseAmt: 0.75, noiseHp: 1400 },
    clap: { freq: 1200, decay: 0.2 },
    hat: { base: 42, decay: 0.06, openDecay: 0.42, metalAmt: 0.22, noiseAmt: 0.3 },
    crash: { decay: 2.0 },
    ride: { decay: 1.3 },
    toms: { f: [210, 150, 105], decay: 0.5, noise: 0.25 },
    rim: { freq: 1800 },
    shaker: {},
  }, { gain: 0.85 }),

  'drums.electro': makeKit({
    kick: { f0: 160, f1: 46, pitchDecay: 0.075, decay: 0.6, click: 0.2, clickFreq: 3000 },
    snare: { body: 200, bodyAmt: 0.5, noiseDecay: 0.2, noiseAmt: 0.8, noiseHp: 1800, noisePeak: 6000 },
    clap: { freq: 1150, decay: 0.2 },
    hat: { base: 40, decay: 0.045, openDecay: 0.3, metalAmt: 0.35, noiseAmt: 0.15 },
    crash: { decay: 1.6 },
    ride: { decay: 1.0 },
    toms: { f: [240, 170, 115], decay: 0.35, noise: 0.05 },
    rim: { freq: 1700, decay: 0.03 },
    shaker: { freq: 8000, decay: 0.05 },
  }, { gain: 0.85 }),

  'drums.lofi': makeKit({
    kick: { f0: 110, f1: 50, pitchDecay: 0.04, decay: 0.32, click: 0.12, clickFreq: 1200, thump: 0.3 },
    snare: { body: 180, bodyAmt: 0.5, noiseDecay: 0.18, noiseAmt: 0.6, noiseHp: 900, noisePeak: 3500 },
    clap: { freq: 1000, decay: 0.16 },
    hat: { base: 38, decay: 0.05, openDecay: 0.3, metalAmt: 0.12, noiseAmt: 0.3, noiseHp: 6000, bp: 7500 },
    crash: { decay: 1.4, noiseHp: 4000 },
    ride: { decay: 1.0 },
    toms: { f: [190, 140, 100], decay: 0.4 },
    rim: { freq: 1500 },
    shaker: { freq: 5500 },
  }, {
    gain: 0.95,
    bus: (ctx, out) => chain(ctx, [
      createFilter(ctx, 'highpass', 45),
      createFilter(ctx, 'lowpass', 5200, 0.6),
      createDrive(ctx, { amount: 1.6, pre: 1.2, post: 0.8, tone: 9000 }),
    ], out),
  }),

  'drums.chip': makeKit({
    kick: { wave: 'pulse', f0: 190, f1: 42, pitchDecay: 0.07, decay: 0.14 },
    snare: { body: 230, bodyWave: 'square', bodyAmt: 0.25, bodyDecay: 0.05, noiseDecay: 0.12, noiseAmt: 0.6, noiseHp: 1500, noisePeak: 4000 },
    clap: { freq: 1500, decay: 0.1 },
    hat: { metal: false, decay: 0.03, openDecay: 0.18, noiseHp: 7500, noiseAmt: 0.4 },
    crash: { metalAmt: 0, noiseHp: 3000, decay: 0.7, noiseAmt: 0.4 },
    ride: { decay: 0.4 },
    toms: { f: [220, 160, 110], wave: 'triangle', decay: 0.2, noise: 0, drop: 0.5, pitchDecay: 0.12 },
    rim: { wave: 'square', freq: 800, decay: 0.02 },
    shaker: { freq: 9000, decay: 0.04 },
  }, { gain: 1.0 }),

  'drums.epic': makeKit({
    kick: { f0: 95, f1: 48, pitchDecay: 0.12, decay: 1.1, thump: 0.55, click: 0.08, clickFreq: 900 },
    snare: { body: 240, bodyAmt: 0.35, noiseDecay: 0.17, noiseAmt: 0.8, noiseHp: 2000, noisePeak: 5500 },
    clap: { freq: 900, q: 0.7, decay: 0.3 },
    hat: { metal: false, decay: 0.04, openDecay: 0.25, noiseHp: 4000, noiseAmt: 0.35 },
    crash: { decay: 3.0, base: 55, noiseHp: 3500 },
    ride: { decay: 1.6 },
    toms: { f: [165, 120, 82], decay: 0.9, noise: 0.35, noiseLp: 900, pitchDecay: 0.2, drop: 0.7 },
    rim: { wave: 'sine', freq: 950, decay: 0.06, noiseFreq: 1800 },
    shaker: { freq: 6000, decay: 0.08 },
  }, { gain: 0.75 }),
};
