// Микшер: дорожки (громкость, панорама, посылы), общие ревербератор и задержка, мастер-компрессор.
import { getInstrument } from './instruments.js';
import { createReverbIR, collectLfos } from './dsp.js';
import { isDrumInstrument } from '../core/instruments-meta.js';

export class Mixer {
  constructor(ctx, destination = ctx.destination) {
    this.ctx = ctx;
    this.input = ctx.createGain();

    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -16;
    comp.knee.value = 10;
    comp.ratio.value = 3;
    comp.attack.value = 0.012;
    comp.release.value = 0.25;
    const lim = ctx.createDynamicsCompressor();
    lim.threshold.value = -2.5;
    lim.knee.value = 0;
    lim.ratio.value = 20;
    lim.attack.value = 0.002;
    lim.release.value = 0.08;
    this.output = ctx.createGain();
    this.output.gain.value = 0.9;
    this.gate = ctx.createGain();
    this.gate.gain.value = 0;
    this.input.connect(comp).connect(lim).connect(this.output).connect(this.gate).connect(destination);

    // Ревербератор
    this.revIn = ctx.createGain();
    const pre = ctx.createDelay(0.1);
    pre.delayTime.value = 0.02;
    const revHp = ctx.createBiquadFilter();
    revHp.type = 'highpass';
    revHp.frequency.value = 200;
    const conv = ctx.createConvolver();
    conv.buffer = createReverbIR(ctx, 2.8, 3.0);
    const revOut = ctx.createGain();
    revOut.gain.value = 0.85;
    this.revIn.connect(pre).connect(revHp).connect(conv).connect(revOut).connect(this.input);

    // Задержка «пинг-понг» (пунктирная восьмая)
    this.dlyIn = ctx.createGain();
    this.dA = ctx.createDelay(2);
    this.dB = ctx.createDelay(2);
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 3200;
    const fbA = ctx.createGain();
    fbA.gain.value = 0.42;
    const fbB = ctx.createGain();
    fbB.gain.value = 0.42;
    const merger = ctx.createChannelMerger(2);
    const dlyOut = ctx.createGain();
    dlyOut.gain.value = 0.7;
    this.dlyIn.connect(this.dA);
    this.dA.connect(lp).connect(fbA).connect(this.dB);
    this.dB.connect(fbB).connect(this.dA);
    this.dA.connect(merger, 0, 0);
    this.dB.connect(merger, 0, 1);
    merger.connect(dlyOut).connect(this.input);

    this.tracks = new Map();
    this.bpm = 0;
  }

  setTempo(bpm) {
    if (bpm === this.bpm) return;
    this.bpm = bpm;
    const T = Math.min(1.9, (60 / bpm) * 0.75);
    this.dA.delayTime.setValueAtTime(T, this.ctx.currentTime);
    this.dB.delayTime.setValueAtTime(T, this.ctx.currentTime);
  }

  update(song) {
    const ctx = this.ctx;
    const now = ctx.currentTime;
    const anySolo = song.tracks.some((t) => t.solo);
    const seen = new Set();
    for (const track of song.tracks) {
      seen.add(track.id);
      let tr = this.tracks.get(track.id);
      if (!tr || tr.instrumentId !== track.instrument) {
        if (tr) this.disposeTrack(tr);
        tr = this.createTrack(track);
        this.tracks.set(track.id, tr);
      }
      const audible = !track.mute && (!anySolo || track.solo);
      const vol = audible ? track.volume * tr.inst.gain : 0;
      tr.vol.gain.setTargetAtTime(vol, now, 0.015);
      tr.pan.pan.setTargetAtTime(track.pan || 0, now, 0.015);
      tr.rev.gain.setTargetAtTime((track.reverb || 0) * 0.9, now, 0.02);
      tr.dly.gain.setTargetAtTime((track.delay || 0) * 0.6, now, 0.02);
      tr.sidechain = track.sidechain || 0;
    }
    for (const [id, tr] of this.tracks) {
      if (!seen.has(id)) {
        this.disposeTrack(tr);
        this.tracks.delete(id);
      }
    }
    this.setTempo(song.bpm);
  }

  createTrack(track) {
    const ctx = this.ctx;
    const inst = getInstrument(track.instrument);
    const vol = ctx.createGain();
    vol.gain.value = 0;
    const duck = ctx.createGain();
    const pan = ctx.createStereoPanner();
    const rev = ctx.createGain();
    rev.gain.value = 0;
    const dly = ctx.createGain();
    dly.gain.value = 0;
    vol.connect(duck).connect(pan).connect(this.input);
    pan.connect(rev).connect(this.revIn);
    pan.connect(dly).connect(this.dlyIn);
    const { result: input, lfos } = collectLfos(() => (inst.bus ? inst.bus(ctx, vol) : vol));
    return {
      id: track.id,
      instrumentId: track.instrument,
      drums: isDrumInstrument(track.instrument),
      inst, input, vol, duck, pan, rev, dly, lfos,
      sidechain: 0,
    };
  }

  disposeTrack(tr) {
    const when = this.ctx.currentTime + 0.05;
    tr.vol.gain.setTargetAtTime(0, this.ctx.currentTime, 0.01);
    setTimeout(() => {
      try {
        tr.pan.disconnect();
        for (const l of tr.lfos) l.stop();
      } catch {
        /* ignore */
      }
    }, (when - this.ctx.currentTime) * 1000 + 100);
  }

  /** «Пампинг» (имитация сайдчейна от бочки) на доле beat. */
  duck(t, beatDur) {
    for (const tr of this.tracks.values()) {
      if (!tr.sidechain) continue;
      const g = tr.duck.gain;
      const depth = Math.min(0.9, tr.sidechain * 0.85);
      g.setTargetAtTime(1 - depth, t, 0.004);
      g.setTargetAtTime(1, t + 0.03, beatDur * 0.18);
    }
  }

  playEvent(ev, when) {
    const tr = this.tracks.get(ev.trackId);
    if (!tr) return null;
    if (tr.drums) return ev.voice ? tr.inst.play(this.ctx, tr.input, when, ev.voice, ev.vel) : null;
    if (ev.voice) return null;
    return tr.inst.play(this.ctx, tr.input, when, ev.midi, ev.dur, ev.vel);
  }

  /** Считает заранее сэмплы для всех нот, чтобы не было подвисаний во время игры. */
  async prepare(song, compiled) {
    const kits = [];
    for (const tr of this.tracks.values()) if (tr.drums && tr.inst.prepareAsync) kits.push(tr.inst.prepareAsync());
    const byTrack = new Map();
    for (const ev of compiled.events) {
      if (ev.voice) continue;
      if (!byTrack.has(ev.trackId)) byTrack.set(ev.trackId, new Set());
      byTrack.get(ev.trackId).add(ev.midi);
    }
    for (const [id, midis] of byTrack) {
      const tr = this.tracks.get(id);
      if (tr?.inst.prepare) tr.inst.prepare([...midis]);
    }
    await Promise.all(kits);
  }

  openGate(t = this.ctx.currentTime) {
    const g = this.gate.gain;
    g.cancelScheduledValues(0);
    g.setValueAtTime(g.value, this.ctx.currentTime);
    g.setTargetAtTime(1, Math.max(t - 0.02, this.ctx.currentTime), 0.005);
  }

  closeGate() {
    const g = this.gate.gain;
    const now = this.ctx.currentTime;
    g.cancelScheduledValues(0);
    g.setValueAtTime(g.value, now);
    g.setTargetAtTime(0, now, 0.012);
  }
}
