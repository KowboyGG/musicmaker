// Общие кирпичики синтеза: голос (набор источников), огибающие, шум, волны, эффекты.

const stores = new WeakMap();
function store(ctx) {
  let s = stores.get(ctx);
  if (!s) {
    s = { pulses: new Map(), curves: new Map() };
    stores.set(ctx, s);
  }
  return s;
}

export const mtof = (m) => 440 * Math.pow(2, (m - 69) / 12);
export const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

/** Детерминированный шум, чтобы рендер был воспроизводимым. */
export function seededNoise(n, seed = 12345) {
  const out = new Float32Array(n);
  let s = seed >>> 0;
  for (let i = 0; i < n; i++) {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    out[i] = (s / 4294967296) * 2 - 1;
  }
  return out;
}

export function noiseBuffer(ctx) {
  const s = store(ctx);
  if (!s.noise) {
    const len = Math.floor(ctx.sampleRate * 2);
    const b = ctx.createBuffer(1, len, ctx.sampleRate);
    b.getChannelData(0).set(seededNoise(len, 777));
    s.noise = b;
  }
  return s.noise;
}

/** Прямоугольная волна со скважностью duty (0.125, 0.25, 0.5) — звук NES. */
export function pulseWave(ctx, duty) {
  const s = store(ctx);
  if (!s.pulses.has(duty)) {
    const n = 64;
    const real = new Float32Array(n);
    const imag = new Float32Array(n);
    for (let k = 1; k < n; k++) real[k] = (2 / (k * Math.PI)) * Math.sin(Math.PI * k * duty);
    s.pulses.set(duty, ctx.createPeriodicWave(real, imag));
  }
  return s.pulses.get(duty);
}

/** Органная волна: гармоники с заданными амплитудами. */
export function harmonicWave(ctx, key, amps) {
  const s = store(ctx);
  if (!s.pulses.has(key)) {
    const real = new Float32Array(amps.length + 1);
    const imag = new Float32Array(amps.length + 1);
    amps.forEach((a, i) => (imag[i + 1] = a));
    s.pulses.set(key, ctx.createPeriodicWave(real, imag));
  }
  return s.pulses.get(key);
}

export function driveCurve(ctx, amount) {
  const s = store(ctx);
  if (!s.curves.has(amount)) {
    const n = 2048;
    const c = new Float32Array(n);
    const k = amount;
    const norm = Math.tanh(k);
    for (let i = 0; i < n; i++) {
      const x = (i / (n - 1)) * 2 - 1;
      c[i] = Math.tanh(k * x) / norm;
    }
    s.curves.set(amount, c);
  }
  return s.curves.get(amount);
}

/**
 * Голос: собирает источники звука одной ноты, чтобы их можно было запустить и остановить разом.
 */
export class Voice {
  constructor(ctx, t) {
    this.ctx = ctx;
    this.t = t;
    this.srcs = [];
    this.end = t;
  }
  osc(type, freq, detune = 0) {
    const o = this.ctx.createOscillator();
    if (typeof type === 'string') o.type = type;
    else o.setPeriodicWave(type);
    o.frequency.setValueAtTime(freq, this.t);
    if (detune) o.detune.setValueAtTime(detune, this.t);
    this.srcs.push(o);
    return o;
  }
  noise() {
    const s = this.ctx.createBufferSource();
    s.buffer = noiseBuffer(this.ctx);
    s.loop = true;
    s._offset = (this.srcs.length * 0.37 + this.t * 1.618) % 1.5;
    this.srcs.push(s);
    return s;
  }
  sample(buffer, rate = 1) {
    const s = this.ctx.createBufferSource();
    s.buffer = buffer;
    s.playbackRate.value = rate;
    this.srcs.push(s);
    return s;
  }
  gain(v = 1) {
    const g = this.ctx.createGain();
    g.gain.value = v;
    return g;
  }
  filter(type, freq, Q = 0.707, gain = 0) {
    const f = this.ctx.createBiquadFilter();
    f.type = type;
    f.frequency.value = freq;
    f.Q.value = Q;
    if (gain) f.gain.value = gain;
    return f;
  }
  /** LFO: синус частотой rate и глубиной depth, подключённый к param, с плавным появлением через delay. */
  lfo(param, rate, depth, delay = 0, fadeIn = 0.3) {
    const o = this.osc('sine', rate);
    const g = this.gain(0);
    if (delay > 0 || fadeIn > 0) {
      g.gain.setValueAtTime(0, this.t + delay);
      g.gain.linearRampToValueAtTime(depth, this.t + delay + Math.max(0.001, fadeIn));
    } else g.gain.value = depth;
    o.connect(g).connect(param);
    return o;
  }
  finish(end) {
    this.end = end;
    for (const s of this.srcs) {
      if (s instanceof AudioBufferSourceNode) s.start(this.t, s._offset || 0);
      else s.start(this.t);
      s.stop(end);
    }
    return this;
  }
  stopNow(when) {
    for (const s of this.srcs) {
      try {
        s.stop(when);
      } catch {
        /* уже остановлен */
      }
    }
  }
}

/** ADSR-огибающая. Возвращает время, когда звук затих. */
export function adsr(param, t, dur, { a = 0.005, d = 0.1, s = 0.8, r = 0.1, peak = 1 } = {}) {
  const on = Math.max(dur, a);
  param.setValueAtTime(0.0001, t);
  param.linearRampToValueAtTime(peak, t + a);
  param.setTargetAtTime(Math.max(0.0001, peak * s), t + a, Math.max(0.002, d / 3));
  param.setTargetAtTime(0.0001, t + on, Math.max(0.002, r / 4));
  return t + on + r * 1.25;
}

/** Ударная огибающая: быстро вверх, экспоненциально вниз; note-off (dur) может оборвать раньше. */
export function perc(param, t, { a = 0.002, decay = 0.3, peak = 1 } = {}, dur = null, r = 0.08) {
  param.setValueAtTime(0.0001, t);
  param.linearRampToValueAtTime(peak, t + a);
  param.setTargetAtTime(0.0001, t + a, Math.max(0.002, decay / 4));
  let end = t + a + decay * 1.3;
  if (dur != null && t + Math.max(dur, a) + r < end) {
    param.setTargetAtTime(0.0001, t + Math.max(dur, a), Math.max(0.002, r / 4));
    end = t + Math.max(dur, a) + r * 1.25;
  }
  return end;
}

// ---------------------------------------------------------------------------
// Эффекты уровня дорожки. Каждый возвращает { input, output }.
// Постоянно работающие LFO регистрируются в коллекторе, чтобы микшер мог их остановить при удалении дорожки.

let lfoCollector = null;
export function collectLfos(fn) {
  const prev = lfoCollector;
  lfoCollector = [];
  try {
    const result = fn();
    return { result, lfos: lfoCollector };
  } finally {
    lfoCollector = prev;
  }
}
function startLfo(osc) {
  osc.start();
  if (lfoCollector) lfoCollector.push(osc);
}

export function createChorus(ctx, { mix = 0.35, depth = 0.0025, rate = 0.35 } = {}) {
  const input = ctx.createGain();
  const output = ctx.createGain();
  const dry = ctx.createGain();
  dry.gain.value = 1 - mix * 0.5;
  input.connect(dry).connect(output);
  const merger = ctx.createChannelMerger(2);
  [[0.012, rate, 0], [0.017, rate * 1.31, 1]].forEach(([base, r, ch]) => {
    const d = ctx.createDelay(0.05);
    d.delayTime.value = base;
    const lfo = ctx.createOscillator();
    lfo.frequency.value = r;
    const lg = ctx.createGain();
    lg.gain.value = depth;
    lfo.connect(lg).connect(d.delayTime);
    startLfo(lfo);
    const wg = ctx.createGain();
    wg.gain.value = mix;
    input.connect(d).connect(wg).connect(merger, 0, ch);
  });
  merger.connect(output);
  return { input, output };
}

export function createTremolo(ctx, { rate = 5, depth = 0.25 } = {}) {
  const input = ctx.createGain();
  const output = ctx.createGain();
  output.gain.value = 1 - depth / 2;
  const lfo = ctx.createOscillator();
  lfo.frequency.value = rate;
  const lg = ctx.createGain();
  lg.gain.value = depth / 2;
  lfo.connect(lg).connect(output.gain);
  startLfo(lfo);
  input.connect(output);
  return { input, output };
}

export function createDrive(ctx, { amount = 3, pre = 1, post = 0.7, tone = 6000 } = {}) {
  const input = ctx.createGain();
  input.gain.value = pre;
  const ws = ctx.createWaveShaper();
  ws.curve = driveCurve(ctx, amount);
  ws.oversample = '2x';
  const lp = ctx.createBiquadFilter();
  lp.type = 'lowpass';
  lp.frequency.value = tone;
  const output = ctx.createGain();
  output.gain.value = post;
  input.connect(ws).connect(lp).connect(output);
  return { input, output };
}

export function createFilter(ctx, type, freq, Q = 0.707, gain = 0) {
  const f = ctx.createBiquadFilter();
  f.type = type;
  f.frequency.value = freq;
  f.Q.value = Q;
  f.gain.value = gain;
  return { input: f, output: f };
}

/** Соединяет цепочку эффектов { input, output } и возвращает вход первого. */
export function chain(ctx, effects, out) {
  if (!effects.length) return out;
  for (let i = 0; i < effects.length - 1; i++) effects[i].output.connect(effects[i + 1].input);
  effects[effects.length - 1].output.connect(out);
  return effects[0].input;
}

/** Импульсная характеристика ревербератора (стерео, экспоненциальный спад, затухание верхов). */
export function createReverbIR(ctx, seconds = 2.6, decay = 3.2) {
  const sr = ctx.sampleRate;
  const len = Math.floor(sr * seconds);
  const ir = ctx.createBuffer(2, len, sr);
  for (let ch = 0; ch < 2; ch++) {
    const d = ir.getChannelData(ch);
    const noise = seededNoise(len, 1000 + ch * 7919);
    let lp = 0;
    for (let i = 0; i < len; i++) {
      const x = i / len;
      const env = Math.pow(1 - x, decay);
      const damp = 0.9 - 0.75 * x; // со временем тембр темнеет
      lp += damp * (noise[i] - lp);
      d[i] = lp * env;
    }
    // Ранние отражения
    for (const [ms, g] of [[7, 0.5], [13, 0.35], [21, 0.3], [29, 0.22], [37, 0.18]]) {
      const i = Math.floor(((ms + ch * 3) / 1000) * sr);
      if (i < len) d[i] += g * (ch ? -1 : 1);
    }
    for (let i = 0; i < Math.min(len, 64); i++) d[i] *= i / 64;
  }
  return ir;
}
