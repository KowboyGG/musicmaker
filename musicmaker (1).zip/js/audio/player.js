// Проигрыватель: планирует ноты с упреждением (lookahead), умеет зацикливать песню или секцию
// и подхватывает правки прямо во время игры.
import { Mixer } from './mixer.js';
import { compileSong, eventIndexAt } from '../core/timeline.js';

const LOOKAHEAD = 0.25;
const TICK_MS = 25;

function createTicker(fn) {
  try {
    const code = `let id=null;onmessage=(e)=>{if(e.data==='start'){clearInterval(id);id=setInterval(()=>postMessage(0),${TICK_MS});}else{clearInterval(id);id=null;}}`;
    const url = URL.createObjectURL(new Blob([code], { type: 'text/javascript' }));
    const w = new Worker(url);
    w.onmessage = fn;
    return { start: () => w.postMessage('start'), stop: () => w.postMessage('stop') };
  } catch {
    let id = null;
    return {
      start: () => {
        clearInterval(id);
        id = setInterval(fn, TICK_MS);
      },
      stop: () => clearInterval(id),
    };
  }
}

export class Player {
  constructor() {
    this.ctx = null;
    this.mixer = null;
    this.song = null;
    this.compiled = null;
    this.playing = false;
    this.voices = [];
    this.loop = false;
    this.rangeSectionIndex = null;
    this.pausedAt = 0;
    this.onEnded = null;
    this.ticker = createTicker(() => this.tick());
  }

  async init() {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AC({ latencyHint: 'interactive' });
      this.mixer = new Mixer(this.ctx);
      if (this.song) this.mixer.update(this.song);
    }
    if (this.ctx.state !== 'running') await this.ctx.resume();
  }

  setSong(song) {
    const oldBpm = this.song?.bpm;
    const oldCompiled = this.compiled;
    this.song = song;
    this.compiled = compileSong(song);
    if (this.mixer) this.mixer.update(song);
    if (!this.playing) return;
    if (oldBpm && oldBpm !== song.bpm) {
      // Сохраняем музыкальную позицию при смене темпа.
      const ratio = oldBpm / song.bpm;
      this.cursorSong *= ratio;
      this.anchors.push({ ctx: this.cursorCtx, song: this.cursorSong });
    }
    this.updateRange(oldCompiled);
    if (this.cursorSong >= this.rangeEnd) this.cursorSong = this.loop ? this.rangeStart : this.rangeEnd;
    this.eventIdx = eventIndexAt(this.compiled.events, this.cursorSong);
    this.nextBeat = Math.ceil(this.cursorSong / this.compiled.beatDur - 1e-9);
    if (this.mixer) this.mixer.prepare(song, this.compiled);
  }

  updateRange() {
    const c = this.compiled;
    if (this.rangeSectionIndex != null && c.sections[this.rangeSectionIndex]) {
      const s = c.sections[this.rangeSectionIndex];
      this.rangeStart = s.start;
      this.rangeEnd = s.end;
    } else {
      this.rangeStart = 0;
      this.rangeEnd = c.duration;
    }
  }

  /**
   * @param {{from?:number, sectionIndex?:number|null, loop?:boolean}} opts
   */
  async play({ from = null, sectionIndex = null, loop = false } = {}) {
    await this.init();
    if (this.playing) this.stop();
    if (!this.compiled) return;
    await this.mixer.prepare(this.song, this.compiled);
    this.rangeSectionIndex = sectionIndex;
    this.loop = loop;
    this.updateRange();
    let start = from ?? this.rangeStart;
    if (start < this.rangeStart || start >= this.rangeEnd) start = this.rangeStart;
    const t0 = this.ctx.currentTime + 0.06;
    this.cursorSong = start;
    this.cursorCtx = t0;
    this.anchors = [{ ctx: t0, song: start }];
    this.eventIdx = eventIndexAt(this.compiled.events, start);
    this.nextBeat = Math.ceil(start / this.compiled.beatDur - 1e-9);
    this.endAt = null;
    this.mixer.openGate(t0);
    this.playing = true;
    this.tick();
    this.ticker.start();
  }

  tick() {
    if (!this.playing) return;
    const ctx = this.ctx;
    const c = this.compiled;
    const target = ctx.currentTime + LOOKAHEAD;
    let guard = 0;
    while (this.endAt == null && this.cursorCtx < target && guard++ < 32) {
      const segEnd = Math.min(this.rangeEnd, this.cursorSong + (target - this.cursorCtx));
      const evs = c.events;
      while (this.eventIdx < evs.length && evs[this.eventIdx].time < segEnd) {
        const ev = evs[this.eventIdx++];
        if (ev.time < this.cursorSong - 1e-6) continue;
        const v = this.mixer.playEvent(ev, this.cursorCtx + (ev.time - this.cursorSong));
        if (v) this.voices.push(v);
      }
      const bd = c.beatDur;
      while (this.nextBeat * bd < segEnd - 1e-9) {
        const bt = this.nextBeat * bd;
        if (bt >= this.cursorSong - 1e-9) this.mixer.duck(this.cursorCtx + (bt - this.cursorSong), bd);
        this.nextBeat++;
      }
      this.cursorCtx += segEnd - this.cursorSong;
      this.cursorSong = segEnd;
      if (this.cursorSong >= this.rangeEnd - 1e-9) {
        if (this.loop && this.rangeEnd - this.rangeStart > 0.05) {
          this.cursorSong = this.rangeStart;
          this.eventIdx = eventIndexAt(evs, this.rangeStart);
          this.nextBeat = Math.ceil(this.rangeStart / bd - 1e-9);
          this.anchors.push({ ctx: this.cursorCtx, song: this.rangeStart });
          if (this.anchors.length > 8) this.anchors.splice(0, this.anchors.length - 8);
        } else {
          this.endAt = this.cursorCtx;
        }
      }
    }
    if (this.endAt != null && ctx.currentTime > this.endAt + 0.05) {
      this.stop();
      this.pausedAt = 0;
      if (this.onEnded) this.onEnded();
      return;
    }
    if (this.voices.length > 64) {
      const now = ctx.currentTime;
      this.voices = this.voices.filter((v) => v.end > now);
    }
  }

  /** Текущая позиция в секундах от начала песни. */
  position() {
    if (!this.playing || !this.ctx) return this.pausedAt;
    const now = this.ctx.currentTime;
    let a = this.anchors[0];
    for (const x of this.anchors) if (x.ctx <= now) a = x;
    return Math.max(0, Math.min(this.rangeEnd, a.song + Math.max(0, now - a.ctx)));
  }

  stop() {
    if (!this.ctx) return;
    if (this.playing) this.pausedAt = this.position();
    this.playing = false;
    this.ticker.stop();
    const now = this.ctx.currentTime;
    this.mixer.closeGate();
    for (const v of this.voices) v.stopNow(now + 0.06);
    this.voices = [];
  }

  /** Прослушать одну ноту (клик в редакторе). */
  async preview(trackId, midiOrVoice, dur = 0.4) {
    await this.init();
    if (!this.song) return;
    const now = this.ctx.currentTime;
    if (!this.playing) this.mixer.openGate(now);
    const isVoice = typeof midiOrVoice === 'string';
    const ev = { trackId, midi: isVoice ? 0 : midiOrVoice, voice: isVoice ? midiOrVoice : undefined, dur, vel: 0.8 };
    const tr = this.mixer.tracks.get(trackId);
    if (tr?.inst.prepare && !isVoice) tr.inst.prepare([midiOrVoice]);
    this.mixer.playEvent(ev, now + 0.01);
  }
}
