// Мелодические инструменты. У каждого:
//   gain  — выравнивание громкости между инструментами;
//   bus(ctx, out) — эффекты уровня дорожки (необязательно), возвращает вход;
//   play(ctx, dest, t, midi, dur, vel) — играет ноту, возвращает Voice;
//   prepare(midis) — заранее считает сэмплы (для струн и фортепиано).
import {
  Voice, adsr, perc, mtof, clamp, pulseWave, harmonicWave,
  createChorus, createTremolo, createDrive, createFilter, chain,
} from './dsp.js';
import { stringBuffer, pianoBuffer, vinylBuffer } from './samples.js';
import { DRUM_KITS } from './drums.js';

const velCurve = (v) => Math.pow(clamp(v, 0, 1), 1.4);

// ---------------------------------------------------------------------------
// Щипковые на основе посчитанных струн

function stringInstrument(preset, { gain = 0.7, release = 0.08, tone = 7000, bus = null } = {}) {
  return {
    gain,
    prepare(midis) {
      for (const m of midis) stringBuffer(m, preset);
    },
    bus,
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const src = v.sample(stringBuffer(midi, preset));
      const lp = v.filter('lowpass', clamp(tone * (0.35 + 0.65 * vel), 400, 16000), 0.5);
      const g = v.gain(0);
      const bufDur = src.buffer.duration;
      const off = Math.min(dur, bufDur);
      g.gain.setValueAtTime(velCurve(vel), t);
      g.gain.setTargetAtTime(0.0001, t + off, release / 4);
      src.connect(lp).connect(g).connect(dest);
      return v.finish(t + Math.min(bufDur, off + release * 1.3));
    },
  };
}

// ---------------------------------------------------------------------------

export const MELODIC = {
  'bass.synth': {
    gain: 0.5,
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const f = mtof(midi);
      const mix = v.gain(1);
      [[v.osc('sawtooth', f, -7), 0.32], [v.osc('sawtooth', f, 7), 0.32], [v.osc('sine', f), 0.55]].forEach(([o, a]) => {
        const g = v.gain(a);
        o.connect(g).connect(mix);
      });
      const base = 90 + f * 1.8;
      const peak = base + 2600 * vel * vel;
      const lp1 = v.filter('lowpass', peak, 4);
      const lp2 = v.filter('lowpass', peak, 0.7);
      for (const lp of [lp1, lp2]) {
        lp.frequency.setValueAtTime(peak, t);
        lp.frequency.setTargetAtTime(base + 250, t, 0.09);
      }
      const amp = v.gain(0);
      const end = adsr(amp.gain, t, dur, { a: 0.004, d: 0.25, s: 0.75, r: 0.06, peak: velCurve(vel) });
      mix.connect(lp1).connect(lp2).connect(amp).connect(dest);
      return v.finish(end);
    },
  },

  'bass.sub': {
    gain: 0.5,
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const f = mtof(midi);
      const amp = v.gain(0);
      const tri = v.gain(0.18);
      v.osc('sine', f).connect(amp);
      v.osc('triangle', f).connect(tri).connect(amp);
      const end = adsr(amp.gain, t, dur, { a: 0.012, d: 0.3, s: 0.9, r: 0.09, peak: velCurve(vel) });
      amp.connect(dest);
      return v.finish(end);
    },
  },

  'bass.808': {
    gain: 0.45,
    bus: (ctx, out) => chain(ctx, [createDrive(ctx, { amount: 2.2, pre: 1.3, post: 0.75, tone: 3500 })], out),
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const f = mtof(midi);
      const o = v.osc('sine', f);
      o.frequency.setValueAtTime(f * 1.6, t);
      o.frequency.exponentialRampToValueAtTime(f, t + 0.045);
      const amp = v.gain(0);
      amp.gain.setValueAtTime(0.0001, t);
      amp.gain.linearRampToValueAtTime(velCurve(vel), t + 0.003);
      amp.gain.setTargetAtTime(velCurve(vel) * 0.25, t + 0.003, 0.9);
      const off = Math.max(dur, 0.05);
      amp.gain.setTargetAtTime(0.0001, t + off, 0.03);
      o.connect(amp).connect(dest);
      return v.finish(t + off + 0.15);
    },
  },

  'bass.acid': {
    gain: 0.45,
    bus: (ctx, out) => chain(ctx, [createDrive(ctx, { amount: 1.8, pre: 1, post: 0.8, tone: 7000 })], out),
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const f = mtof(midi);
      const o = v.osc('sawtooth', f);
      const base = 140 + f;
      const peak = base + 3800 * vel * vel;
      const lp1 = v.filter('lowpass', peak, 13);
      const lp2 = v.filter('lowpass', peak * 1.2, 0.7);
      lp1.frequency.setValueAtTime(peak, t);
      lp1.frequency.setTargetAtTime(base, t, 0.08);
      lp2.frequency.setValueAtTime(peak * 1.2, t);
      lp2.frequency.setTargetAtTime(base * 2, t, 0.08);
      const amp = v.gain(0);
      const end = adsr(amp.gain, t, dur, { a: 0.003, d: 0.2, s: 0.8, r: 0.03, peak: velCurve(vel) });
      o.connect(lp1).connect(lp2).connect(amp).connect(dest);
      return v.finish(end);
    },
  },

  'bass.guitar': stringInstrument('bass', {
    gain: 1.3, release: 0.07, tone: 2600,
    bus: (ctx, out) => chain(ctx, [createFilter(ctx, 'peaking', 700, 1, -3), createFilter(ctx, 'lowshelf', 120, 0.7, 3)], out),
  }),
  'bass.upright': stringInstrument('upright', { gain: 1.35, release: 0.09, tone: 1600 }),

  'bass.chip': {
    gain: 0.42,
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const amp = v.gain(0);
      v.osc('triangle', mtof(midi)).connect(amp).connect(dest);
      const end = adsr(amp.gain, t, dur, { a: 0.001, d: 0.05, s: 1, r: 0.015, peak: 0.6 + 0.4 * vel });
      return v.finish(end);
    },
  },

  // -------------------------------------------------------------------------
  'keys.piano': {
    gain: 1.5,
    prepare(midis) {
      for (const m of midis) pianoBuffer(m);
    },
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const src = v.sample(pianoBuffer(midi));
      const lp = v.filter('lowpass', 900 + 9000 * vel * vel, 0.5);
      const g = v.gain(0);
      const bufDur = src.buffer.duration;
      const off = Math.min(Math.max(dur, 0.08), bufDur);
      g.gain.setValueAtTime(velCurve(vel), t);
      g.gain.setTargetAtTime(0.0001, t + off, 0.07);
      src.connect(lp).connect(g).connect(dest);
      return v.finish(t + Math.min(bufDur, off + 0.4));
    },
  },

  'keys.epiano': {
    gain: 0.4,
    bus: (ctx, out) => chain(ctx, [createTremolo(ctx, { rate: 4.6, depth: 0.22 }), createChorus(ctx, { mix: 0.3 })], out),
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const f = mtof(midi);
      const car = v.osc('sine', f);
      const mod = v.osc('sine', f);
      const modG = v.gain(0);
      modG.gain.setValueAtTime(f * (0.6 + 1.8 * vel), t);
      modG.gain.setTargetAtTime(f * 0.18, t, 0.3);
      mod.connect(modG).connect(car.frequency);
      const tine = v.osc('sine', f * 14);
      const tineG = v.gain(0);
      tineG.gain.setValueAtTime(f * 1.2 * vel, t);
      tineG.gain.setTargetAtTime(0, t, 0.015);
      tine.connect(tineG).connect(car.frequency);
      const amp = v.gain(0);
      const pk = velCurve(vel);
      amp.gain.setValueAtTime(0.0001, t);
      amp.gain.linearRampToValueAtTime(pk, t + 0.002);
      amp.gain.setTargetAtTime(0.0001, t + 0.002, clamp(2.2 - (midi - 48) * 0.03, 0.6, 2.4));
      const off = Math.max(dur, 0.05);
      amp.gain.setTargetAtTime(0.0001, t + off, 0.06);
      car.connect(amp).connect(dest);
      return v.finish(t + off + 0.35);
    },
  },

  'keys.organ': {
    gain: 0.3,
    bus: (ctx, out) => chain(ctx, [createChorus(ctx, { mix: 0.45, rate: 5.8, depth: 0.0012 }), createDrive(ctx, { amount: 1.3, post: 0.9 })], out),
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const wave = harmonicWave(ctx, 'organ', [0.55, 1, 0.45, 0.6, 0, 0.3, 0, 0.3]);
      const amp = v.gain(0);
      v.osc(wave, mtof(midi) / 2).connect(amp).connect(dest);
      const end = adsr(amp.gain, t, dur, { a: 0.008, d: 0.05, s: 1, r: 0.06, peak: 0.5 + 0.5 * vel });
      return v.finish(end);
    },
  },

  // -------------------------------------------------------------------------
  'pad.warm': {
    gain: 0.33,
    bus: (ctx, out) => chain(ctx, [createChorus(ctx, { mix: 0.4 })], out),
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const f = mtof(midi);
      const mix = v.gain(1);
      for (const d of [-9, 0, 9]) v.osc('sawtooth', f, d).connect(mix);
      const sub = v.gain(0.5);
      v.osc('triangle', f / 2).connect(sub).connect(mix);
      const att = 0.45;
      const lp = v.filter('lowpass', 500, 0.8);
      lp.frequency.setValueAtTime(500, t);
      lp.frequency.linearRampToValueAtTime(1100 + 1600 * vel, t + att * 1.5);
      const amp = v.gain(0);
      const end = adsr(amp.gain, t, dur, { a: att, d: 1, s: 0.85, r: 1.1, peak: velCurve(vel) * 0.45 });
      mix.connect(lp).connect(amp).connect(dest);
      return v.finish(end);
    },
  },

  'pad.dark': {
    gain: 0.4,
    bus: (ctx, out) => chain(ctx, [createChorus(ctx, { mix: 0.45, rate: 0.2 })], out),
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const f = mtof(midi);
      const mix = v.gain(1);
      for (const d of [-12, 12]) v.osc('sawtooth', f, d).connect(mix);
      const sq = v.gain(0.4);
      v.osc('square', f / 2).connect(sq).connect(mix);
      const lp = v.filter('lowpass', 650, 2);
      v.lfo(lp.frequency, 0.18, 260, 0, 1);
      const amp = v.gain(0);
      const end = adsr(amp.gain, t, dur, { a: 0.9, d: 1, s: 0.9, r: 1.6, peak: velCurve(vel) * 0.45 });
      mix.connect(lp).connect(amp).connect(dest);
      return v.finish(end);
    },
  },

  'pad.choir': {
    gain: 1.6,
    bus(ctx, out) {
      const input = ctx.createGain();
      const sum = ctx.createGain();
      for (const [fq, q, g] of [[720, 6, 1], [1150, 8, 0.55], [2700, 10, 0.25], [300, 3, 0.25]]) {
        const bp = ctx.createBiquadFilter();
        bp.type = 'bandpass';
        bp.frequency.value = fq;
        bp.Q.value = q;
        const gg = ctx.createGain();
        gg.gain.value = g;
        input.connect(bp).connect(gg).connect(sum);
      }
      const ch = createChorus(ctx, { mix: 0.5 });
      sum.connect(ch.input);
      ch.output.connect(out);
      return input;
    },
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const f = mtof(midi);
      const mix = v.gain(1);
      const oscs = [v.osc('sawtooth', f, -8), v.osc('sawtooth', f, 8), v.osc('sawtooth', f * 1.002, 0)];
      for (const o of oscs) {
        o.connect(mix);
        v.lfo(o.frequency, 5.1 + (midi % 5) * 0.07, f * 0.006, 0.2, 0.4);
      }
      const amp = v.gain(0);
      const end = adsr(amp.gain, t, dur, { a: 0.35, d: 0.5, s: 0.9, r: 0.8, peak: velCurve(vel) * 0.5 });
      mix.connect(amp).connect(dest);
      return v.finish(end);
    },
  },

  'pad.drone': {
    gain: 0.5,
    bus: (ctx, out) => chain(ctx, [createChorus(ctx, { mix: 0.5, rate: 0.1 })], out),
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const f = mtof(midi);
      const mix = v.gain(1);
      for (const d of [-6, 6]) v.osc('sawtooth', f, d).connect(mix);
      const s = v.gain(0.6);
      v.osc('sine', f / 2).connect(s).connect(mix);
      const lp = v.filter('lowpass', 380, 3);
      v.lfo(lp.frequency, 0.07, 220, 0, 2);
      const amp = v.gain(0);
      const end = adsr(amp.gain, t, dur, { a: 2.2, d: 1, s: 0.95, r: 2.5, peak: velCurve(vel) * 0.6 });
      mix.connect(lp).connect(amp).connect(dest);
      return v.finish(end);
    },
  },

  // -------------------------------------------------------------------------
  'strings.ensemble': {
    gain: 0.36,
    bus: (ctx, out) => chain(ctx, [createFilter(ctx, 'highpass', 110), createFilter(ctx, 'peaking', 2500, 0.8, 2), createChorus(ctx, { mix: 0.35 })], out),
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const f = mtof(midi);
      const mix = v.gain(1);
      for (const d of [-10, -3, 8]) {
        const o = v.osc('sawtooth', f, d);
        v.lfo(o.frequency, 5.4, f * 0.0045, 0.25, 0.4);
        o.connect(mix);
      }
      const lp = v.filter('lowpass', 1800 + 2600 * vel, 0.6);
      const amp = v.gain(0);
      const a = 0.07 + 0.35 * (1 - vel);
      const end = adsr(amp.gain, t, dur, { a, d: 0.4, s: 0.9, r: 0.45, peak: velCurve(vel) * 0.5 });
      mix.connect(lp).connect(amp).connect(dest);
      return v.finish(end);
    },
  },

  'strings.staccato': {
    gain: 0.42,
    bus: (ctx, out) => chain(ctx, [createFilter(ctx, 'highpass', 100), createChorus(ctx, { mix: 0.25 })], out),
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const f = mtof(midi);
      const mix = v.gain(1);
      for (const d of [-8, 8]) v.osc('sawtooth', f, d).connect(mix);
      const lp = v.filter('lowpass', 1600 + 2600 * vel, 0.7);
      lp.frequency.setTargetAtTime(1200 + 1000 * vel, t + 0.02, 0.08);
      const amp = v.gain(0);
      const end = adsr(amp.gain, t, Math.min(dur, 0.35), { a: 0.008, d: 0.12, s: 0.35, r: 0.1, peak: velCurve(vel) * 0.6 });
      mix.connect(lp).connect(amp).connect(dest);
      return v.finish(end);
    },
  },

  'strings.pizz': stringInstrument('pizz', { gain: 1.8, release: 0.1, tone: 3000 }),

  'brass.section': {
    gain: 0.34,
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const f = mtof(midi);
      const mix = v.gain(1);
      const oscs = [v.osc('sawtooth', f, -5), v.osc('sawtooth', f, 5)];
      const sq = v.osc('square', f);
      const sqg = v.gain(0.2);
      sq.connect(sqg).connect(mix);
      for (const o of [...oscs, sq]) {
        o.detune.setValueAtTime(-35, t);
        o.detune.linearRampToValueAtTime(0, t + 0.07);
        v.lfo(o.frequency, 5, f * 0.003, 0.35, 0.4);
      }
      for (const o of oscs) o.connect(mix);
      const lp = v.filter('lowpass', 300, 1.1);
      const peak = 900 + 2800 * vel;
      lp.frequency.setValueAtTime(300, t);
      lp.frequency.linearRampToValueAtTime(peak, t + 0.09);
      lp.frequency.setTargetAtTime(peak * 0.6, t + 0.09, 0.35);
      const amp = v.gain(0);
      const end = adsr(amp.gain, t, dur, { a: 0.05, d: 0.25, s: 0.85, r: 0.2, peak: velCurve(vel) * 0.55 });
      mix.connect(lp).connect(amp).connect(dest);
      return v.finish(end);
    },
  },

  'wind.flute': {
    gain: 0.55,
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const f = mtof(midi);
      const mix = v.gain(1);
      const oscs = [[v.osc('sine', f), 0.8], [v.osc('triangle', f), 0.15], [v.osc('sine', f * 2), 0.06]];
      for (const [o, a] of oscs) {
        const g = v.gain(a);
        v.lfo(o.frequency, 5, f * 0.005, 0.22, 0.35);
        o.connect(g).connect(mix);
      }
      const n = v.noise();
      const bp = v.filter('bandpass', f * 1.5, 1.2);
      const ng = v.gain(0);
      ng.gain.setValueAtTime(0, t);
      ng.gain.linearRampToValueAtTime(0.16 * vel, t + 0.04);
      ng.gain.setTargetAtTime(0.04 * vel, t + 0.04, 0.08);
      n.connect(bp).connect(ng).connect(mix);
      const amp = v.gain(0);
      const end = adsr(amp.gain, t, dur, { a: 0.07, d: 0.15, s: 0.88, r: 0.12, peak: velCurve(vel) * 0.6 });
      mix.connect(amp).connect(dest);
      return v.finish(end);
    },
  },

  'pluck.harp': stringInstrument('harp', { gain: 1.4, release: 0.6, tone: 5000 }),

  // -------------------------------------------------------------------------
  'guitar.acoustic': stringInstrument('steel', {
    gain: 1.1, release: 0.12, tone: 9000,
    bus: (ctx, out) => chain(ctx, [createFilter(ctx, 'highpass', 75), createFilter(ctx, 'peaking', 110, 1.2, 4), createFilter(ctx, 'peaking', 2800, 1, 2)], out),
  }),
  'guitar.clean': stringInstrument('electric', {
    gain: 1.0, release: 0.1, tone: 6000,
    bus: (ctx, out) => chain(ctx, [createFilter(ctx, 'lowpass', 5500), createChorus(ctx, { mix: 0.35 })], out),
  }),
  'guitar.distorted': stringInstrument('electric', {
    gain: 0.5, release: 0.05, tone: 8000,
    bus: (ctx, out) => chain(ctx, [
      createFilter(ctx, 'highpass', 100),
      createDrive(ctx, { amount: 7, pre: 3, post: 0.28, tone: 5200 }),
      createFilter(ctx, 'lowpass', 4600, 0.9),
      createFilter(ctx, 'peaking', 850, 1, -3),
      createFilter(ctx, 'peaking', 2400, 1.2, 2.5),
    ], out),
  }),

  // -------------------------------------------------------------------------
  'lead.saw': {
    gain: 0.7,
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const f = mtof(midi);
      const mix = v.gain(1);
      for (const d of [-7, 7]) {
        const o = v.osc('sawtooth', f, d);
        v.lfo(o.frequency, 5.6, f * 0.006, 0.3, 0.3);
        o.connect(mix);
      }
      const sub = v.gain(0.25);
      v.osc('square', f / 2).connect(sub).connect(mix);
      const peak = 2000 + 3000 * vel;
      const lp = v.filter('lowpass', peak * 1.4, 1.3);
      lp.frequency.setTargetAtTime(peak, t, 0.1);
      const amp = v.gain(0);
      const end = adsr(amp.gain, t, dur, { a: 0.008, d: 0.2, s: 0.8, r: 0.12, peak: velCurve(vel) * 0.45 });
      mix.connect(lp).connect(amp).connect(dest);
      return v.finish(end);
    },
  },

  'lead.square': {
    gain: 0.62,
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const f = mtof(midi);
      const mix = v.gain(1);
      const o = v.osc('square', f);
      v.lfo(o.frequency, 5.5, f * 0.005, 0.28, 0.3);
      o.connect(mix);
      const hi = v.gain(0.12);
      v.osc('square', f * 2).connect(hi).connect(mix);
      const lp = v.filter('lowpass', 2600 + 2000 * vel, 0.9);
      const amp = v.gain(0);
      const end = adsr(amp.gain, t, dur, { a: 0.006, d: 0.15, s: 0.8, r: 0.1, peak: velCurve(vel) * 0.45 });
      mix.connect(lp).connect(amp).connect(dest);
      return v.finish(end);
    },
  },

  'pluck.synth': {
    gain: 0.85,
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const f = mtof(midi);
      const mix = v.gain(1);
      v.osc('sawtooth', f, -6).connect(mix);
      const sq = v.gain(0.5);
      v.osc('square', f, 6).connect(sq).connect(mix);
      const lp = v.filter('lowpass', 600 + 5200 * vel, 3);
      lp.frequency.setTargetAtTime(380 + f * 0.5, t, 0.07);
      const amp = v.gain(0);
      const end = perc(amp.gain, t, { a: 0.002, decay: 0.45, peak: velCurve(vel) * 0.5 }, dur, 0.08);
      mix.connect(lp).connect(amp).connect(dest);
      return v.finish(end);
    },
  },

  'lead.chip': {
    gain: 0.38,
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const f = mtof(midi);
      const o = v.osc(pulseWave(ctx, 0.25), f);
      v.lfo(o.frequency, 6, f * 0.008, 0.22, 0.05);
      const amp = v.gain(0);
      const end = adsr(amp.gain, t, dur, { a: 0.002, d: 0.08, s: 0.8, r: 0.02, peak: 0.5 + 0.5 * vel });
      o.connect(amp).connect(dest);
      return v.finish(end);
    },
  },

  'pulse.chip': {
    gain: 0.5,
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const o = v.osc(pulseWave(ctx, 0.125), mtof(midi));
      const amp = v.gain(0);
      const end = adsr(amp.gain, t, dur, { a: 0.002, d: 0.1, s: 0.65, r: 0.02, peak: 0.5 + 0.5 * vel });
      o.connect(amp).connect(dest);
      return v.finish(end);
    },
  },

  // -------------------------------------------------------------------------
  'mallet.marimba': {
    gain: 0.95,
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const f = mtof(midi);
      const decay = clamp(0.9 - (midi - 48) * 0.014, 0.22, 0.9);
      let end = t;
      for (const [ratio, a, dk] of [[1, 1, decay], [3.93, 0.3, 0.07], [9.8, 0.07, 0.025]]) {
        if (f * ratio > 15000) continue;
        const g = v.gain(0);
        v.osc('sine', f * ratio).connect(g).connect(dest);
        end = Math.max(end, perc(g.gain, t, { a: 0.0015, decay: dk, peak: velCurve(vel) * a * 0.6 }));
      }
      return v.finish(end);
    },
  },

  'mallet.vibes': {
    gain: 0.75,
    bus: (ctx, out) => chain(ctx, [createTremolo(ctx, { rate: 5.2, depth: 0.35 })], out),
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const f = mtof(midi);
      let end = t;
      for (const [ratio, a, dk] of [[1, 1, 2.4], [4, 0.15, 0.3], [10, 0.04, 0.05]]) {
        if (f * ratio > 15000) continue;
        const g = v.gain(0);
        v.osc('sine', f * ratio).connect(g).connect(dest);
        end = Math.max(end, perc(g.gain, t, { a: 0.002, decay: dk, peak: velCurve(vel) * a * 0.55 }, Math.max(dur, 0.3), 0.3));
      }
      return v.finish(end);
    },
  },

  'mallet.bell': {
    gain: 0.85,
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const f = mtof(midi);
      const car = v.osc('sine', f);
      const mod = v.osc('sine', f * 3.5);
      const mg = v.gain(0);
      mg.gain.setValueAtTime(f * 3 * vel, t);
      mg.gain.setTargetAtTime(f * 0.3, t, 0.5);
      mod.connect(mg).connect(car.frequency);
      const amp = v.gain(0);
      const end = perc(amp.gain, t, { a: 0.002, decay: 2.8, peak: velCurve(vel) * 0.45 });
      car.connect(amp).connect(dest);
      const g2 = v.gain(0);
      v.osc('sine', f * 2).connect(g2).connect(dest);
      perc(g2.gain, t, { a: 0.002, decay: 1.2, peak: velCurve(vel) * 0.12 });
      return v.finish(end);
    },
  },

  'mallet.musicbox': {
    gain: 1.05,
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const f = mtof(midi);
      const car = v.osc('sine', f);
      const mod = v.osc('sine', f * 5);
      const mg = v.gain(0);
      mg.gain.setValueAtTime(f * 1.5 * vel, t);
      mg.gain.setTargetAtTime(0, t, 0.05);
      mod.connect(mg).connect(car.frequency);
      const amp = v.gain(0);
      const end = perc(amp.gain, t, { a: 0.001, decay: 1.7, peak: velCurve(vel) * 0.5 });
      car.connect(amp).connect(dest);
      return v.finish(end);
    },
  },

  // -------------------------------------------------------------------------
  'fx.riser': {
    gain: 0.5,
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const D = Math.max(0.3, dur);
      const n = v.noise();
      const bp = v.filter('bandpass', 250, 3);
      bp.frequency.setValueAtTime(250, t);
      bp.frequency.exponentialRampToValueAtTime(9000, t + D);
      const f = mtof(midi);
      const o = v.osc('sawtooth', f);
      o.frequency.exponentialRampToValueAtTime(f * 4, t + D);
      const og = v.gain(0.12);
      const olp = v.filter('lowpass', 3500, 0.7);
      const amp = v.gain(0);
      amp.gain.setValueAtTime(0.0001, t);
      amp.gain.exponentialRampToValueAtTime(Math.max(0.001, velCurve(vel) * 0.6), t + D);
      amp.gain.linearRampToValueAtTime(0.0001, t + D + 0.06);
      n.connect(bp).connect(amp);
      o.connect(olp).connect(og).connect(amp);
      amp.connect(dest);
      return v.finish(t + D + 0.1);
    },
  },

  'fx.impact': {
    gain: 0.8,
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const f = Math.max(40, mtof(midi) * 1.5);
      const o = v.osc('sine', f);
      o.frequency.setValueAtTime(f, t);
      o.frequency.exponentialRampToValueAtTime(f * 0.4, t + 1.6);
      const og = v.gain(0);
      let end = perc(og.gain, t, { a: 0.003, decay: 2.4, peak: velCurve(vel) });
      o.connect(og).connect(dest);
      const n = v.noise();
      const lp = v.filter('lowpass', 1400, 0.8);
      lp.frequency.setTargetAtTime(200, t, 0.15);
      const ng = v.gain(0);
      end = Math.max(end, perc(ng.gain, t, { a: 0.002, decay: 0.7, peak: velCurve(vel) * 0.7 }));
      n.connect(lp).connect(ng).connect(dest);
      const n2 = v.noise();
      const hp = v.filter('highpass', 4000, 0.7);
      const hg = v.gain(0);
      perc(hg.gain, t, { a: 0.002, decay: 1.1, peak: velCurve(vel) * 0.12 });
      n2.connect(hp).connect(hg).connect(dest);
      return v.finish(end);
    },
  },

  'fx.vinyl': {
    gain: 1.2,
    prepare() {
      vinylBuffer();
    },
    play(ctx, dest, t, midi, dur, vel) {
      const v = new Voice(ctx, t);
      const src = v.sample(vinylBuffer());
      src.loop = true;
      const hp = v.filter('highpass', 300, 0.7);
      const g = v.gain(0);
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(vel, t + 0.1);
      g.gain.setValueAtTime(vel, t + Math.max(0.1, dur));
      g.gain.linearRampToValueAtTime(0, t + Math.max(0.1, dur) + 0.2);
      src.connect(hp).connect(g).connect(dest);
      return v.finish(t + Math.max(0.1, dur) + 0.25);
    },
  },
};

const FALLBACK = 'keys.piano';

/** Возвращает инструмент по id (ударные — это набор с play по имени барабана). */
export function getInstrument(id) {
  if (DRUM_KITS[id]) return DRUM_KITS[id];
  return MELODIC[id] || MELODIC[FALLBACK];
}
