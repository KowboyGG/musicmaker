// Музыкальная теория: ноты, лады, аккорды, римские ступени, голосоведение, определение тональности.

export const SHARP_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
export const FLAT_NAMES = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'Gb', 'G', 'Ab', 'A', 'Bb', 'B'];
/** Привычные названия тоник для выпадающего списка. */
export const KEY_NAMES = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];

const LETTERS = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
const ACCIDENTALS = { '': 0, '#': 1, '♯': 1, '##': 2, x: 2, b: -1, '♭': -1, bb: -2 };

export function mod(n, m) {
  return ((n % m) + m) % m;
}

export function parsePitchClass(name) {
  const m = /^\s*([A-Ga-g])(##|#|♯|x|bb|b|♭)?\s*$/.exec(String(name ?? ''));
  if (!m) return null;
  return mod(LETTERS[m[1].toUpperCase()] + ACCIDENTALS[m[2] || ''], 12);
}

/** "A2" → 45, "C#4" → 61, "Bb3" → 58. Число возвращается как есть. */
export function noteToMidi(note) {
  if (typeof note === 'number') return Number.isFinite(note) ? Math.round(note) : null;
  const m = /^\s*([A-Ga-g])(##|#|♯|x|bb|b|♭)?\s*(-?\d{1,2})\s*$/.exec(String(note ?? ''));
  if (!m) {
    const n = Number(note);
    return Number.isFinite(n) && String(note).trim() !== '' ? Math.round(n) : null;
  }
  const pc = LETTERS[m[1].toUpperCase()] + ACCIDENTALS[m[2] || ''];
  const midi = (parseInt(m[3], 10) + 1) * 12 + pc;
  return midi >= 0 && midi <= 127 ? midi : null;
}

export function midiToNote(midi, flats = false) {
  const names = flats ? FLAT_NAMES : SHARP_NAMES;
  return names[mod(midi, 12)] + (Math.floor(midi / 12) - 1);
}

export function midiToFreq(midi) {
  return 440 * Math.pow(2, (midi - 69) / 12);
}

export function pcName(pc, flats = false) {
  return (flats ? FLAT_NAMES : SHARP_NAMES)[mod(pc, 12)];
}

// ---------------------------------------------------------------------------
// Лады

export const SCALES = {
  major: { name: 'Мажор', steps: [0, 2, 4, 5, 7, 9, 11], rel: 0 },
  minor: { name: 'Минор', steps: [0, 2, 3, 5, 7, 8, 10], rel: 3 },
  harmonicMinor: { name: 'Гармонический минор', steps: [0, 2, 3, 5, 7, 8, 11], rel: 3 },
  dorian: { name: 'Дорийский', steps: [0, 2, 3, 5, 7, 9, 10], rel: 10 },
  phrygian: { name: 'Фригийский', steps: [0, 1, 3, 5, 7, 8, 10], rel: 8 },
  lydian: { name: 'Лидийский', steps: [0, 2, 4, 6, 7, 9, 11], rel: 7 },
  mixolydian: { name: 'Миксолидийский', steps: [0, 2, 4, 5, 7, 9, 10], rel: 5 },
  phrygianDominant: { name: 'Восточный (фригийский доминантовый)', steps: [0, 1, 4, 5, 7, 8, 10], rel: 8 },
  majorPentatonic: { name: 'Мажорная пентатоника', steps: [0, 2, 4, 7, 9], rel: 0 },
  minorPentatonic: { name: 'Минорная пентатоника', steps: [0, 3, 5, 7, 10], rel: 3 },
  blues: { name: 'Блюзовый', steps: [0, 3, 5, 6, 7, 10], rel: 3 },
  wholeTone: { name: 'Целотонный', steps: [0, 2, 4, 6, 8, 10], rel: 0 },
};

const SCALE_ALIASES = {
  ionian: 'major', maj: 'major', мажор: 'major',
  aeolian: 'minor', min: 'minor', naturalminor: 'minor', 'natural minor': 'minor', минор: 'minor',
  'harmonic minor': 'harmonicMinor', harmonic: 'harmonicMinor',
  'phrygian dominant': 'phrygianDominant',
  pentatonic: 'majorPentatonic', 'major pentatonic': 'majorPentatonic', 'minor pentatonic': 'minorPentatonic',
  'whole tone': 'wholeTone',
};

export function resolveScaleName(name) {
  if (!name) return null;
  if (SCALES[name]) return name;
  const low = String(name).trim().toLowerCase();
  for (const k of Object.keys(SCALES)) if (k.toLowerCase() === low) return k;
  return SCALE_ALIASES[low] || null;
}

export function scalePcs(tonicPc, scaleName) {
  const sc = SCALES[scaleName] || SCALES.major;
  return sc.steps.map((s) => mod(tonicPc + s, 12));
}

export function isMinorScale(scaleName) {
  const sc = SCALES[scaleName] || SCALES.major;
  return sc.steps.includes(3) && !sc.steps.includes(4);
}

/** Писать ли ноты через бемоли в этой тональности. */
export function prefersFlats(tonicPc, scaleName) {
  const rel = mod(tonicPc + (SCALES[scaleName]?.rel ?? 0), 12);
  return [5, 10, 3, 8, 1].includes(rel);
}

/** Все midi-ноты лада в диапазоне [lo, hi]. */
export function scaleNotesInRange(pcs, lo, hi) {
  const set = new Set(pcs.map((p) => mod(p, 12)));
  const out = [];
  for (let m = lo; m <= hi; m++) if (set.has(mod(m, 12))) out.push(m);
  return out;
}

// ---------------------------------------------------------------------------
// Аккорды

const Q = {
  '': [0, 4, 7],
  m: [0, 3, 7],
  dim: [0, 3, 6],
  aug: [0, 4, 8],
  sus2: [0, 2, 7],
  sus4: [0, 5, 7],
  5: [0, 7],
  6: [0, 4, 7, 9],
  m6: [0, 3, 7, 9],
  7: [0, 4, 7, 10],
  maj7: [0, 4, 7, 11],
  m7: [0, 3, 7, 10],
  m7b5: [0, 3, 6, 10],
  dim7: [0, 3, 6, 9],
  mMaj7: [0, 3, 7, 11],
  aug7: [0, 4, 8, 10],
  '7sus4': [0, 5, 7, 10],
  add9: [0, 4, 7, 14],
  madd9: [0, 3, 7, 14],
  9: [0, 4, 7, 10, 14],
  maj9: [0, 4, 7, 11, 14],
  m9: [0, 3, 7, 10, 14],
  11: [0, 7, 10, 14, 17],
  m11: [0, 3, 7, 10, 14, 17],
  13: [0, 4, 7, 10, 14, 21],
  '7b9': [0, 4, 7, 10, 13],
};
export const CHORD_QUALITIES = Q;

const QUALITY_ALIASES = {
  '': '', M: '', maj: '', major: '',
  m: 'm', min: 'm', '-': 'm', minor: 'm',
  dim: 'dim', '°': 'dim', o: 'dim',
  aug: 'aug', '+': 'aug',
  sus2: 'sus2', sus4: 'sus4', sus: 'sus4',
  5: '5',
  6: '6', m6: 'm6', min6: 'm6',
  7: '7', dom7: '7',
  maj7: 'maj7', M7: 'maj7', Δ: 'maj7', Δ7: 'maj7', ma7: 'maj7',
  m7: 'm7', min7: 'm7', '-7': 'm7',
  m7b5: 'm7b5', ø: 'm7b5', ø7: 'm7b5', 'm7(b5)': 'm7b5',
  dim7: 'dim7', '°7': 'dim7', o7: 'dim7',
  mMaj7: 'mMaj7', 'm(maj7)': 'mMaj7', mmaj7: 'mMaj7', mM7: 'mMaj7',
  aug7: 'aug7', '7#5': 'aug7', '+7': 'aug7',
  '7sus4': '7sus4', '7sus': '7sus4',
  add9: 'add9', add2: 'add9',
  madd9: 'madd9', 'm(add9)': 'madd9',
  9: '9', maj9: 'maj9', M9: 'maj9', m9: 'm9', min9: 'm9',
  11: '11', m11: 'm11',
  13: '13',
  '7b9': '7b9',
};

/**
 * Разбирает символ аккорда: "Am", "F#m7", "Bbmaj7", "C/E", "Gsus4".
 * Возвращает { root, quality, intervals, bass, symbol } или null.
 */
export function parseChord(symbol) {
  if (symbol == null) return null;
  const s = String(symbol).trim();
  if (!s || s === '-' || /^n\.?c\.?$/i.test(s)) return null;
  const m = /^([A-Ga-g])(#|b|♯|♭)?([^/]*)(?:\/([A-Ga-g](?:#|b|♯|♭)?))?$/.exec(s);
  if (!m) return null;
  const root = parsePitchClass(m[1] + (m[2] || ''));
  const qRaw = m[3].trim();
  const quality = QUALITY_ALIASES[qRaw] ?? QUALITY_ALIASES[qRaw.toLowerCase()];
  if (quality === undefined) return null;
  const bass = m[4] ? parsePitchClass(m[4]) : null;
  return { root, quality, intervals: Q[quality], bass, symbol: s };
}

export function chordSymbol(rootPc, quality, flats = false, bassPc = null) {
  let s = pcName(rootPc, flats) + quality;
  if (bassPc != null && bassPc !== rootPc) s += '/' + pcName(bassPc, flats);
  return s;
}

export function chordPcs(chord) {
  if (!chord) return [];
  const pcs = chord.intervals.map((i) => mod(chord.root + i, 12));
  if (chord.bass != null && !pcs.includes(chord.bass)) pcs.push(chord.bass);
  return pcs;
}

/** Терция аккорда (или её замена в sus-аккордах). */
export function chordThirdPc(chord) {
  const iv = chord.intervals.find((i) => [2, 3, 4, 5].includes(mod(i, 12)) && i < 12) ?? 7;
  return mod(chord.root + iv, 12);
}
export function chordFifthPc(chord) {
  const iv = chord.intervals.find((i) => [6, 7, 8].includes(i)) ?? 7;
  return mod(chord.root + iv, 12);
}

// ---------------------------------------------------------------------------
// Римские ступени: "i", "bVI", "V7", "iiø7", "IVmaj7", "bVIIadd9", "ii9"

const ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII'];
const ROMAN_SEMI = [0, 2, 4, 5, 7, 9, 11];

function combineQuality(base, suf) {
  if (['sus2', 'sus4', '5', '7sus4'].includes(suf)) return suf;
  const table = {
    major: { '': '', 7: '7', maj7: 'maj7', 9: '9', maj9: 'maj9', add9: 'add9', 6: '6', 11: '11', 13: '13', '7b9': '7b9' },
    minor: { '': 'm', 7: 'm7', maj7: 'mMaj7', 9: 'm9', add9: 'madd9', 6: 'm6', 11: 'm11' },
    dim: { '': 'dim', 7: 'dim7' },
    halfdim: { '': 'm7b5', 7: 'm7b5' },
    aug: { '': 'aug', 7: 'aug7' },
  };
  const q = table[base][suf];
  return q === undefined ? null : q;
}

/** Переводит римскую ступень в символ аккорда относительно тоники. */
export function romanToChordSymbol(roman, tonicPc, flats = false) {
  const m = /^(b|#|♭|♯)?(VII|VI|V|IV|III|II|I|vii|vi|v|iv|iii|ii|i)(°|o|ø|\+)?(.*)$/.exec(String(roman).trim());
  if (!m) return null;
  const acc = m[1] === 'b' || m[1] === '♭' ? -1 : m[1] ? 1 : 0;
  const num = m[2];
  const upper = num === num.toUpperCase();
  const deg = ROMAN.indexOf(num.toUpperCase());
  const root = mod(tonicPc + ROMAN_SEMI[deg] + acc, 12);
  let base = upper ? 'major' : 'minor';
  if (m[3] === '°' || m[3] === 'o') base = 'dim';
  else if (m[3] === 'ø') base = 'halfdim';
  else if (m[3] === '+') base = 'aug';
  let suf = m[4].trim();
  if (base === 'minor' && /^m(?!aj)/.test(suf)) suf = suf.slice(1); // "im7" = "i7"
  if (suf === 'Maj7') suf = 'maj7';
  const quality = combineQuality(base, suf);
  if (quality == null) return null;
  return chordSymbol(root, quality, flats);
}

export function progressionToSymbols(prog, tonicPc, flats = false) {
  const tokens = Array.isArray(prog) ? prog : String(prog).trim().split(/\s+/);
  return tokens.map((t) => romanToChordSymbol(t, tonicPc, flats) ?? chordSymbol(tonicPc, '', flats));
}

/** Диатонические трезвучия (или септаккорды) лада из 7 ступеней. */
export function diatonicChords(tonicPc, scaleName, sevenths = false, flats = false) {
  const sc = SCALES[scaleName] || SCALES.major;
  if (sc.steps.length !== 7) return diatonicChords(tonicPc, isMinorScale(scaleName) ? 'minor' : 'major', sevenths, flats);
  const out = [];
  for (let d = 0; d < 7; d++) {
    const r = sc.steps[d];
    const third = mod(sc.steps[(d + 2) % 7] - r, 12);
    const fifth = mod(sc.steps[(d + 4) % 7] - r, 12);
    const sev = mod(sc.steps[(d + 6) % 7] - r, 12);
    let quality = '';
    if (third === 4 && fifth === 7) quality = sevenths ? (sev === 11 ? 'maj7' : '7') : '';
    else if (third === 3 && fifth === 7) quality = sevenths ? (sev === 10 ? 'm7' : 'mMaj7') : 'm';
    else if (third === 3 && fifth === 6) quality = sevenths ? (sev === 10 ? 'm7b5' : 'dim7') : 'dim';
    else if (third === 4 && fifth === 8) quality = 'aug';
    else quality = third === 3 ? 'm' : '';
    out.push({ degree: d, symbol: chordSymbol(mod(tonicPc + r, 12), quality, flats) });
  }
  return out;
}

/**
 * Локальный звукоряд под аккорд: ноты лада, но с заменой тех,
 * что стоят в полутоне от звука аккорда, на звук аккорда (для заимствованных аккордов).
 */
export function localScalePcs(keyPcs, chord) {
  if (!chord) return keyPcs.slice();
  const ct = chordPcs(chord);
  const out = new Set();
  for (const p of keyPcs) {
    if (ct.includes(p)) {
      out.add(p);
      continue;
    }
    const clash = ct.some((c) => !keyPcs.includes(c) && (mod(c - p, 12) === 1 || mod(p - c, 12) === 1));
    if (!clash) out.add(p);
  }
  for (const c of ct) out.add(c);
  return [...out].sort((a, b) => a - b);
}

// ---------------------------------------------------------------------------
// Голосоведение

/** Порядок важности интервалов аккорда: прима, терция, септима, опции, квинта. */
function importantIntervals(chord) {
  const ivs = [...new Set(chord.intervals.map((i) => mod(i, 12)))];
  const rank = (i) => {
    if (i === 0) return 0;
    if ([3, 4].includes(i)) return 1;
    if ([2, 5].includes(i) && !ivs.includes(3) && !ivs.includes(4)) return 1;
    if ([10, 11, 9].includes(i)) return 2;
    if ([7, 6, 8].includes(i)) return 4;
    return 3;
  };
  return ivs.sort((a, b) => rank(a) - rank(b));
}

/**
 * Подбирает расположение аккорда в диапазоне [low, high] с плавным переходом от prev.
 * Возвращает отсортированный массив midi.
 */
export function voiceChord(chord, { low = 48, high = 72, prev = null, maxNotes = 4, center = null } = {}) {
  if (!chord) return [];
  let ivs = importantIntervals(chord);
  if (ivs.length > maxNotes) ivs = ivs.slice(0, maxNotes);
  const pcs = ivs.map((i) => mod(chord.root + i, 12));
  const mid = center ?? (low + high) / 2;
  const candidates = [];
  for (let r = 0; r < pcs.length; r++) {
    const order = pcs.slice(r).concat(pcs.slice(0, r));
    for (let base = low - 12; base <= high; base++) {
      if (mod(base, 12) !== order[0]) continue;
      const v = [base];
      for (let k = 1; k < order.length; k++) {
        let n = v[k - 1] + 1;
        while (mod(n, 12) !== order[k]) n++;
        v.push(n);
      }
      if (v[0] >= low && v[v.length - 1] <= high) candidates.push(v);
    }
  }
  if (!candidates.length) {
    // Диапазон слишком узкий — просто плотное расположение от low.
    const v = [];
    let n = low;
    for (const pc of pcs) {
      while (mod(n, 12) !== pc) n++;
      v.push(n);
      n++;
    }
    return v.sort((a, b) => a - b);
  }
  let best = null;
  let bestScore = Infinity;
  for (const v of candidates) {
    const avg = v.reduce((a, b) => a + b, 0) / v.length;
    let score = Math.abs(avg - mid) * 0.35;
    if (prev && prev.length) {
      for (const n of v) score += Math.min(...prev.map((p) => Math.abs(p - n)));
      score += Math.abs(v[v.length - 1] - prev[prev.length - 1]) * 0.5; // верхний голос особенно плавно
    }
    if (score < bestScore) {
      bestScore = score;
      best = v;
    }
  }
  return best;
}

/** Ближайшая к target нота с классом из pcs. */
export function nearestPc(target, pcs, lo = 0, hi = 127) {
  let best = null;
  let bd = Infinity;
  for (let d = 0; d <= 12; d++) {
    for (const n of [target - d, target + d]) {
      if (n < lo || n > hi) continue;
      if (pcs.includes(mod(n, 12)) && d < bd) {
        best = n;
        bd = d;
      }
    }
    if (best != null) return best;
  }
  return Math.min(hi, Math.max(lo, target));
}

// ---------------------------------------------------------------------------
// Определение тональности (алгоритм Крумхансла — Шмуклера)

const KK_MAJOR = [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88];
const KK_MINOR = [6.33, 2.68, 3.52, 5.38, 2.6, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17];

function correlation(a, b) {
  const n = a.length;
  const ma = a.reduce((x, y) => x + y, 0) / n;
  const mb = b.reduce((x, y) => x + y, 0) / n;
  let num = 0, da = 0, db = 0;
  for (let i = 0; i < n; i++) {
    num += (a[i] - ma) * (b[i] - mb);
    da += (a[i] - ma) ** 2;
    db += (b[i] - mb) ** 2;
  }
  return da && db ? num / Math.sqrt(da * db) : 0;
}

/** notes: [{ midi, len }] → { tonic, scale: 'major'|'minor', score } */
export function detectKey(notes) {
  const hist = new Array(12).fill(0);
  for (const n of notes) hist[mod(n.midi, 12)] += Math.max(0.25, n.len || 1);
  if (hist.every((v) => v === 0)) return null;
  let best = null;
  for (let t = 0; t < 12; t++) {
    const rot = hist.map((_, i) => hist[mod(i + t, 12)]);
    for (const [scale, prof] of [['major', KK_MAJOR], ['minor', KK_MINOR]]) {
      const score = correlation(rot, prof);
      if (!best || score > best.score) best = { tonic: t, scale, score };
    }
  }
  return best;
}

/**
 * Подбирает аккорд на каждый такт под мелодию.
 * barNotes: массив тактов, в каждом [{ midi, len, strong }].
 */
export function harmonizeBars(barNotes, tonicPc, scaleName, flats = false) {
  const minor = isMinorScale(scaleName);
  const options = diatonicChords(tonicPc, minor ? 'minor' : 'major', false, flats)
    .filter((c) => !c.symbol.endsWith('dim'))
    .map((c) => ({ ...c, chord: parseChord(c.symbol) }));
  if (minor) {
    // В миноре часто нужна мажорная доминанта.
    const V = chordSymbol(mod(tonicPc + 7, 12), '', flats);
    options.push({ degree: 4, symbol: V, chord: parseChord(V) });
  }
  const keyPcs = scalePcs(tonicPc, minor ? 'minor' : 'major');
  const out = [];
  let prev = null;
  barNotes.forEach((notes, bi) => {
    let best = null;
    let bestScore = -Infinity;
    for (const opt of options) {
      const pcs = chordPcs(opt.chord);
      let score = 0;
      for (const n of notes) {
        const w = (n.len || 1) * (n.strong ? 2 : 1);
        const pc = mod(n.midi, 12);
        if (pcs.includes(pc)) score += w;
        else if (keyPcs.includes(pc)) score -= 0.25 * w;
        else score -= w;
      }
      if (opt.degree === 0) score += bi === 0 ? 1.5 : 0.3;
      if (opt.degree === 3 || opt.degree === 4) score += 0.2; // главные ступени (IV, V) при равенстве
      if (bi === barNotes.length - 1 && (opt.degree === 4 || opt.degree === 0)) score += 0.4;
      if (prev && opt.symbol === prev) score -= 0.35;
      if (!notes.length && prev) score += opt.symbol === prev ? 2 : 0;
      if (score > bestScore) {
        bestScore = score;
        best = opt;
      }
    }
    out.push(best.symbol);
    prev = best.symbol;
  });
  return out;
}
