// Список инструментов (без звукового кода): используется форматом песни, UI и экспортом MIDI.
// kind: 'drums' — партия задаётся строками-паттернами, 'melodic' — нотами, 'fx' — нотами-событиями.
// range — удобный диапазон (midi), gm — номер программы General MIDI для экспорта.

export const INSTRUMENTS = [
  // Ударные
  { id: 'drums.acoustic', name: 'Ударные: акустика', group: 'Ударные', kind: 'drums' },
  { id: 'drums.electro', name: 'Ударные: электро (808/909)', group: 'Ударные', kind: 'drums' },
  { id: 'drums.lofi', name: 'Ударные: лоу-фай', group: 'Ударные', kind: 'drums' },
  { id: 'drums.chip', name: 'Ударные: 8-бит', group: 'Ударные', kind: 'drums' },
  { id: 'drums.epic', name: 'Ударные: эпик (тайко)', group: 'Ударные', kind: 'drums' },

  // Бас
  { id: 'bass.synth', name: 'Синт-бас', group: 'Бас', kind: 'melodic', range: [28, 55], gm: 38 },
  { id: 'bass.sub', name: 'Саб-бас', group: 'Бас', kind: 'melodic', range: [24, 50], gm: 38 },
  { id: 'bass.808', name: '808-бас', group: 'Бас', kind: 'melodic', range: [24, 50], gm: 38 },
  { id: 'bass.acid', name: 'Кислотный бас (303)', group: 'Бас', kind: 'melodic', range: [28, 55], gm: 39 },
  { id: 'bass.guitar', name: 'Бас-гитара', group: 'Бас', kind: 'melodic', range: [28, 55], gm: 33 },
  { id: 'bass.upright', name: 'Контрабас', group: 'Бас', kind: 'melodic', range: [28, 55], gm: 32 },
  { id: 'bass.chip', name: '8-бит бас', group: 'Бас', kind: 'melodic', range: [28, 60], gm: 38 },

  // Клавишные
  { id: 'keys.piano', name: 'Пианино', group: 'Клавишные', kind: 'melodic', range: [36, 96], gm: 0 },
  { id: 'keys.epiano', name: 'Электропиано', group: 'Клавишные', kind: 'melodic', range: [40, 84], gm: 4 },
  { id: 'keys.organ', name: 'Орган', group: 'Клавишные', kind: 'melodic', range: [40, 84], gm: 16 },

  // Пэды
  { id: 'pad.warm', name: 'Тёплый пэд', group: 'Пэды', kind: 'melodic', range: [45, 79], gm: 89 },
  { id: 'pad.dark', name: 'Тёмный пэд', group: 'Пэды', kind: 'melodic', range: [40, 72], gm: 90 },
  { id: 'pad.choir', name: 'Хор', group: 'Пэды', kind: 'melodic', range: [48, 79], gm: 52 },
  { id: 'pad.drone', name: 'Дрон (гул)', group: 'Пэды', kind: 'melodic', range: [24, 55], gm: 95 },

  // Оркестр
  { id: 'strings.ensemble', name: 'Струнные', group: 'Оркестр', kind: 'melodic', range: [36, 91], gm: 48 },
  { id: 'strings.staccato', name: 'Струнные стаккато', group: 'Оркестр', kind: 'melodic', range: [36, 84], gm: 48 },
  { id: 'strings.pizz', name: 'Пиццикато', group: 'Оркестр', kind: 'melodic', range: [36, 84], gm: 45 },
  { id: 'brass.section', name: 'Медные духовые', group: 'Оркестр', kind: 'melodic', range: [40, 79], gm: 61 },
  { id: 'wind.flute', name: 'Флейта', group: 'Оркестр', kind: 'melodic', range: [60, 96], gm: 73 },
  { id: 'pluck.harp', name: 'Арфа', group: 'Оркестр', kind: 'melodic', range: [36, 96], gm: 46 },

  // Гитары
  { id: 'guitar.acoustic', name: 'Акустическая гитара', group: 'Гитары', kind: 'melodic', range: [40, 84], gm: 25, strum: 0.014 },
  { id: 'guitar.clean', name: 'Электрогитара (чистая)', group: 'Гитары', kind: 'melodic', range: [40, 88], gm: 27, strum: 0.01 },
  { id: 'guitar.distorted', name: 'Электрогитара (перегруз)', group: 'Гитары', kind: 'melodic', range: [40, 88], gm: 30, strum: 0.006 },

  // Синтезаторы
  { id: 'lead.saw', name: 'Синт-лид (пила)', group: 'Синтезаторы', kind: 'melodic', range: [55, 91], gm: 81 },
  { id: 'lead.square', name: 'Синт-лид (квадрат)', group: 'Синтезаторы', kind: 'melodic', range: [55, 91], gm: 80 },
  { id: 'pluck.synth', name: 'Синт-плак', group: 'Синтезаторы', kind: 'melodic', range: [48, 91], gm: 84 },
  { id: 'lead.chip', name: '8-бит лид', group: 'Синтезаторы', kind: 'melodic', range: [55, 96], gm: 80 },
  { id: 'pulse.chip', name: '8-бит пульс (тонкий)', group: 'Синтезаторы', kind: 'melodic', range: [48, 96], gm: 80 },

  // Перкуссия с высотой
  { id: 'mallet.marimba', name: 'Маримба', group: 'Мелодическая перкуссия', kind: 'melodic', range: [48, 91], gm: 12 },
  { id: 'mallet.vibes', name: 'Вибрафон', group: 'Мелодическая перкуссия', kind: 'melodic', range: [53, 89], gm: 11 },
  { id: 'mallet.bell', name: 'Колокольчики', group: 'Мелодическая перкуссия', kind: 'melodic', range: [60, 100], gm: 14 },
  { id: 'mallet.musicbox', name: 'Музыкальная шкатулка', group: 'Мелодическая перкуссия', kind: 'melodic', range: [64, 100], gm: 10 },

  // Эффекты
  { id: 'fx.riser', name: 'FX: нарастание', group: 'Эффекты', kind: 'fx', range: [48, 72], gm: 97 },
  { id: 'fx.impact', name: 'FX: удар', group: 'Эффекты', kind: 'fx', range: [24, 48], gm: 118 },
  { id: 'fx.vinyl', name: 'FX: шум винила', group: 'Эффекты', kind: 'fx', range: [60, 60], gm: 122 },
];

export const INSTRUMENT_MAP = Object.fromEntries(INSTRUMENTS.map((i) => [i.id, i]));

export function instrumentMeta(id) {
  return INSTRUMENT_MAP[id] || null;
}

export function isDrumInstrument(id) {
  return INSTRUMENT_MAP[id]?.kind === 'drums';
}

export const DRUM_VOICES = ['kick', 'snare', 'clap', 'rim', 'hat', 'openhat', 'shaker', 'ride', 'crash', 'tom1', 'tom2', 'tom3'];

export const DRUM_VOICE_NAMES = {
  kick: 'Бочка',
  snare: 'Малый барабан',
  clap: 'Хлопок',
  rim: 'Римшот',
  hat: 'Хай-хэт',
  openhat: 'Открытый хэт',
  shaker: 'Шейкер',
  ride: 'Райд',
  crash: 'Крэш',
  tom1: 'Том высокий',
  tom2: 'Том средний',
  tom3: 'Том низкий',
};

/** Номера нот General MIDI для ударных (канал 10). */
export const GM_DRUM_NOTES = {
  kick: 36, snare: 38, clap: 39, rim: 37, hat: 42, openhat: 46,
  shaker: 70, ride: 51, crash: 49, tom1: 50, tom2: 47, tom3: 43,
};
