// Детерминированный генератор случайных чисел (mulberry32).
// Одинаковый seed всегда даёт одинаковую песню.

export function hashString(str) {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function createRng(seed) {
  const base = (typeof seed === 'string' ? hashString(seed) : seed >>> 0) || 1;
  let s = base;

  const next = () => {
    s = (s + 0x6d2b79f5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };

  const rng = {
    seed: base,
    next,
    float(a = 0, b = 1) {
      return a + (b - a) * next();
    },
    /** Целое в диапазоне [a, b] включительно. */
    int(a, b) {
      if (Array.isArray(a)) [a, b] = a;
      return a + Math.floor(next() * (b - a + 1));
    },
    chance(p) {
      return next() < p;
    },
    pick(arr) {
      return arr[Math.floor(next() * arr.length)];
    },
    /** items: [[value, weight], ...] */
    weighted(items) {
      let total = 0;
      for (const [, w] of items) total += Math.max(0, w);
      if (total <= 0) return items[0][0];
      let r = next() * total;
      for (const [v, w] of items) {
        r -= Math.max(0, w);
        if (r <= 0) return v;
      }
      return items[items.length - 1][0];
    },
    shuffle(arr) {
      const a = arr.slice();
      for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(next() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
      }
      return a;
    },
    /** Независимый поток для подзадачи: изменения в одной партии не сдвигают случайность в других. */
    fork(label) {
      return createRng((base ^ hashString(String(label))) >>> 0);
    },
  };
  return rng;
}

export function randomSeed() {
  return Math.floor(Math.random() * 1e9) + 1;
}
