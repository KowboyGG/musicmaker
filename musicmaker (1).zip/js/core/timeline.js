// Превращает песню в плоский список звуковых событий со временем в секундах.
import { sectionOrder, sectionSteps, stepsPerBar, parseDrumPattern } from './song.js';
import { noteToMidi } from './theory.js';
import { INSTRUMENT_MAP, isDrumInstrument } from './instruments-meta.js';

/**
 * @returns {{
 *   events: Array<{time:number, dur:number, track:number, trackId:string, midi:number, vel:number, voice?:string}>,
 *   sections: Array<{id:string, name:string, index:number, start:number, end:number, bars:number, steps:number}>,
 *   duration:number, stepDur:number, beatDur:number, barDur:number
 * }}
 */
export function compileSong(song, { onlyTrackId = null } = {}) {
  const spb = stepsPerBar(song);
  const stepDur = 60 / song.bpm / 4;
  // Свинг: вторая половина каждой пары (16-х или 8-х) сдвигается к триольной позиции.
  const unit = song.swingGrid === 8 ? 4 : 2;
  const half = unit / 2;
  const shift = (song.swing || 0) * unit / 6;
  const stepTime = (step) => {
    const k = Math.floor(step / unit + 1e-9);
    const r = step - k * unit;
    const w = r < half ? (r * (half + shift)) / half : half + shift + ((r - half) * (unit - half - shift)) / (unit - half);
    return (k * unit + w) * stepDur;
  };

  const events = [];
  const sections = [];
  let t = 0;
  sectionOrder(song).forEach((sec, index) => {
    const steps = sectionSteps(song, sec);
    const start = t;
    song.tracks.forEach((track, ti) => {
      if (onlyTrackId && track.id !== onlyTrackId) return;
      const part = sec.parts?.[track.id];
      if (!part) return;
      if (isDrumInstrument(track.instrument)) {
        if (Array.isArray(part)) return;
        for (const [voice, pattern] of Object.entries(part)) {
          const cells = parseDrumPattern(pattern, steps);
          cells.forEach((cell, i) => {
            if (!cell) return;
            for (let h = 0; h < cell.n; h++) {
              const time = start + stepTime(i) + (h * stepDur) / cell.n;
              events.push({ time, dur: stepDur, track: ti, trackId: track.id, midi: 0, vel: cell.vel * (h === 0 ? 1 : 0.85), voice });
            }
          });
        }
      } else {
        if (!Array.isArray(part)) return;
        const strum = INSTRUMENT_MAP[track.instrument]?.strum || 0;
        const byStep = strum ? new Map() : null;
        for (const n of part) {
          const midi = noteToMidi(n.note);
          if (midi == null) continue;
          const on = stepTime(n.step);
          const off = stepTime(n.step + n.len);
          const ev = {
            time: start + on,
            dur: Math.max(0.02, off - on),
            track: ti,
            trackId: track.id,
            midi,
            vel: n.vel ?? 0.8,
          };
          events.push(ev);
          if (byStep) {
            const k = n.step;
            if (!byStep.has(k)) byStep.set(k, []);
            byStep.get(k).push(ev);
          }
        }
        // Гитарный «бой»: одновременные ноты разносим на миллисекунды (снизу вверх).
        if (byStep) {
          for (const group of byStep.values()) {
            if (group.length < 2) continue;
            group.sort((a, b) => a.midi - b.midi);
            group.forEach((ev, k) => {
              ev.time += k * strum;
              ev.dur = Math.max(0.02, ev.dur - k * strum);
            });
          }
        }
      }
    });
    t += steps * stepDur;
    sections.push({ id: sec.id, name: sec.name, index, start, end: t, bars: sec.bars, steps });
  });
  events.sort((a, b) => a.time - b.time || a.track - b.track);
  return { events, sections, duration: t, stepDur, beatDur: stepDur * 4, barDur: stepDur * spb };
}

/** Индекс первого события с time >= t (бинарный поиск). */
export function eventIndexAt(events, t) {
  let lo = 0;
  let hi = events.length;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (events[mid].time < t) lo = mid + 1;
    else hi = mid;
  }
  return lo;
}
