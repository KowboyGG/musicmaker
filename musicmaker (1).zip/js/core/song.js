// Формат песни (JSON): создание, проверка, нормализация и красивая сериализация.
import { INSTRUMENT_MAP, DRUM_VOICES, isDrumInstrument } from './instruments-meta.js';
import {
  noteToMidi, midiToNote, parsePitchClass, resolveScaleName, parseChord, prefersFlats, pcName,
} from './theory.js';

export const FORMAT_ID = 'musicmaker-song';
export const FORMAT_VERSION = 1;

export const TRACK_DEFAULTS = {
  volume: 0.8, pan: 0, reverb: 0.15, delay: 0, sidechain: 0, mute: false, solo: false, locked: false,
};

export const ROLE_NAMES = {
  drums: 'Ударные',
  bass: 'Бас',
  chords: 'Аккорды',
  pad: 'Пэд',
  arp: 'Арпеджио',
  lead: 'Мелодия',
  counter: 'Подголосок',
  fx: 'Эффекты',
};

export function stepsPerBar(song) {
  return (song.beatsPerBar || 4) * 4;
}

export function sectionSteps(song, section) {
  return section.bars * stepsPerBar(song);
}

export function songUsesFlats(song) {
  const pc = parsePitchClass(song.key) ?? 0;
  return prefersFlats(pc, song.scale);
}

// ---------------------------------------------------------------------------
// Паттерны ударных: "x...x...|x..x...." — X акцент, x удар, o тихий (призрачный),
// 2/3/4 — дробь из стольких ударов внутри шага, "." или "-" — пауза, "|" и пробелы игнорируются.

const HIT_CHARS = { X: 1.0, x: 0.78, o: 0.42 };

export function parseDrumPattern(pattern, total) {
  const cells = [];
  if (Array.isArray(pattern)) {
    const arr = new Array(total).fill(null);
    for (const s of pattern) {
      const i = Math.round(Number(s));
      if (i >= 0 && i < total) arr[i] = { vel: 0.78, n: 1 };
    }
    return arr;
  }
  for (const ch of String(pattern ?? '')) {
    if ('| \n\t\r'.includes(ch)) continue;
    if (HIT_CHARS[ch] != null) cells.push({ vel: HIT_CHARS[ch], n: 1 });
    else if (ch >= '2' && ch <= '4') cells.push({ vel: 0.66, n: Number(ch) });
    else cells.push(null);
  }
  const out = new Array(total).fill(null);
  if (!cells.length) return out;
  for (let i = 0; i < total; i++) out[i] = cells[i % cells.length];
  return out;
}

export function hitToChar(hit) {
  if (!hit) return '.';
  if (hit.n > 1) return String(Math.min(4, hit.n));
  if (hit.vel >= 0.95) return 'X';
  if (hit.vel >= 0.6) return 'x';
  return 'o';
}

export function drumPatternToString(cells, spb) {
  let s = '';
  cells.forEach((c, i) => {
    if (i > 0 && i % spb === 0) s += '|';
    s += hitToChar(c);
  });
  return s;
}

// ---------------------------------------------------------------------------
// Аккорды секции → временная шкала в шагах

/**
 * Возвращает [{ start, end, symbol, chord }] в шагах (1 шаг = 1/16).
 * Элемент массива chords — один такт; "Am G" делит такт пополам.
 * Если аккордов меньше, чем тактов, последовательность повторяется.
 */
export function chordTimeline(song, section) {
  const spb = stepsPerBar(song);
  const list = Array.isArray(section.chords) ? section.chords : [];
  const out = [];
  if (!list.length) return out;
  for (let bar = 0; bar < section.bars; bar++) {
    const entry = String(list[bar % list.length] ?? '').trim();
    const parts = entry ? entry.split(/\s+/) : ['-'];
    const len = spb / parts.length;
    parts.forEach((sym, k) => {
      const start = bar * spb + Math.round(k * len);
      const end = bar * spb + Math.round((k + 1) * len);
      const chord = parseChord(sym);
      const prev = out[out.length - 1];
      if (prev && prev.symbol === sym) prev.end = end;
      else out.push({ start, end, symbol: sym, chord });
    });
  }
  return out;
}

export function chordAt(timeline, step) {
  for (const c of timeline) if (step >= c.start && step < c.end) return c;
  return timeline[timeline.length - 1] || null;
}

// ---------------------------------------------------------------------------
// Создание

export function slugify(text, fallback = 'item') {
  const map = {
    а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', е: 'e', ё: 'e', ж: 'zh', з: 'z', и: 'i', й: 'y', к: 'k', л: 'l',
    м: 'm', н: 'n', о: 'o', п: 'p', р: 'r', с: 's', т: 't', у: 'u', ф: 'f', х: 'h', ц: 'c', ч: 'ch', ш: 'sh',
    щ: 'sch', ъ: '', ы: 'y', ь: '', э: 'e', ю: 'yu', я: 'ya',
  };
  const s = String(text ?? '')
    .toLowerCase()
    .split('')
    .map((c) => map[c] ?? c)
    .join('')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return s || fallback;
}

export function uniqueId(base, taken) {
  const set = taken instanceof Set ? taken : new Set(taken);
  let id = base;
  let i = 2;
  while (set.has(id)) id = `${base}-${i++}`;
  return id;
}

export function createTrack(opts) {
  return {
    id: opts.id,
    name: opts.name || opts.id,
    instrument: opts.instrument,
    role: opts.role || null,
    ...TRACK_DEFAULTS,
    ...Object.fromEntries(Object.entries(opts).filter(([k]) => k in TRACK_DEFAULTS)),
  };
}

export function createEmptySong() {
  return {
    format: FORMAT_ID,
    version: FORMAT_VERSION,
    title: 'Моя идея',
    style: null,
    seed: null,
    bpm: 110,
    key: 'A',
    scale: 'minor',
    beatsPerBar: 4,
    swing: 0,
    swingGrid: 16,
    loop: true,
    tracks: [
      createTrack({ id: 'drums', name: 'Ударные', instrument: 'drums.electro', role: 'drums', reverb: 0.1 }),
      createTrack({ id: 'bass', name: 'Бас', instrument: 'bass.synth', role: 'bass', reverb: 0.05 }),
      createTrack({ id: 'chords', name: 'Аккорды', instrument: 'pad.warm', role: 'chords', volume: 0.6, reverb: 0.3 }),
      createTrack({ id: 'lead', name: 'Мелодия', instrument: 'lead.square', role: 'lead', reverb: 0.25, delay: 0.2 }),
    ],
    sections: [
      { id: 'idea', name: 'Идея', kind: 'chorus', bars: 4, chords: ['Am', 'F', 'C', 'G'], parts: {} },
    ],
    arrangement: ['idea'],
  };
}

export function cloneSong(song) {
  return JSON.parse(JSON.stringify(song));
}

export function sectionOrder(song) {
  const byId = new Map(song.sections.map((s) => [s.id, s]));
  const ids = song.arrangement?.length ? song.arrangement : song.sections.map((s) => s.id);
  return ids.map((id) => byId.get(id)).filter(Boolean);
}

export function songDurationSeconds(song) {
  const stepDur = 60 / song.bpm / 4;
  return sectionOrder(song).reduce((t, s) => t + sectionSteps(song, s) * stepDur, 0);
}

export function isDrumTrack(track) {
  return isDrumInstrument(track.instrument);
}

// ---------------------------------------------------------------------------
// Нормализация: принимает что угодно (в том числе ответ ИИ с ```json), возвращает чистую песню.

export class SongFormatError extends Error {}

export function extractJson(text) {
  let s = String(text ?? '').trim();
  const fence = /```(?:json)?\s*([\s\S]*?)```/i.exec(s);
  if (fence) s = fence[1].trim();
  const a = s.indexOf('{');
  const b = s.lastIndexOf('}');
  if (a < 0 || b < a) throw new SongFormatError('Не нашёл JSON: нужен текст, начинающийся с { и заканчивающийся }.');
  s = s.slice(a, b + 1);
  try {
    return JSON.parse(s);
  } catch (e) {
    // Частая ошибка ИИ — лишние запятые перед } или ].
    try {
      return JSON.parse(s.replace(/,\s*([}\]])/g, '$1'));
    } catch {
      throw new SongFormatError('JSON не читается: ' + e.message);
    }
  }
}

const num = (v, def, lo, hi) => {
  const n = Number(v);
  if (!Number.isFinite(n)) return def;
  return Math.min(hi, Math.max(lo, n));
};

function pickField(obj, names) {
  for (const n of names) if (obj[n] !== undefined) return obj[n];
  return undefined;
}

export function normalizeSong(input) {
  const warnings = [];
  const raw = typeof input === 'string' ? extractJson(input) : input;
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new SongFormatError('Ожидался JSON-объект песни.');

  const song = {
    format: FORMAT_ID,
    version: FORMAT_VERSION,
    title: String(raw.title ?? 'Без названия').slice(0, 120),
    style: raw.style ?? null,
    seed: raw.seed ?? null,
    bpm: Math.round(num(raw.bpm ?? raw.tempo, 110, 30, 300)),
    key: 'C',
    scale: 'major',
    beatsPerBar: Math.round(num(raw.beatsPerBar, 4, 2, 7)),
    swing: num(raw.swing, 0, 0, 1),
    swingGrid: Number(raw.swingGrid) === 8 ? 8 : 16,
    loop: raw.loop === undefined ? false : !!raw.loop,
    tracks: [],
    sections: [],
    arrangement: [],
  };

  // Тональность: "A", "Am", "A minor", "F# dorian"
  let keyText = String(raw.key ?? 'C').trim();
  let scaleText = raw.scale;
  const km = /^([A-Ga-g](?:#|b|♯|♭)?)\s*(m(?!aj)|min|minor|major|maj)?\s*(.*)$/.exec(keyText);
  if (km) {
    const pc = parsePitchClass(km[1]);
    if (pc == null) warnings.push(`Неизвестная тональность "${keyText}", взял C.`);
    else song.key = km[1][0].toUpperCase() + km[1].slice(1);
    if (!scaleText) {
      if (km[2] && /^m(in(or)?)?$/.test(km[2])) scaleText = 'minor';
      else if (km[3]) scaleText = km[3];
      else if (km[2]) scaleText = 'major';
    }
  } else warnings.push(`Неизвестная тональность "${keyText}", взял C.`);
  const scale = resolveScaleName(scaleText ?? 'major');
  if (!scale) warnings.push(`Неизвестный лад "${scaleText}", взял мажор.`);
  song.scale = scale || 'major';

  const spb = song.beatsPerBar * 4;

  // Дорожки
  const trackIds = new Set();
  const rawTracks = Array.isArray(raw.tracks) ? raw.tracks : [];
  rawTracks.forEach((t, i) => {
    if (!t || typeof t !== 'object') return;
    let instrument = String(t.instrument ?? '');
    if (!INSTRUMENT_MAP[instrument]) {
      const guess = Object.keys(INSTRUMENT_MAP).find((k) => k.split('.')[1] === instrument || k === instrument.toLowerCase());
      if (guess) instrument = guess;
      else {
        warnings.push(`Дорожка "${t.name ?? t.id}": неизвестный инструмент "${t.instrument}", заменил на пианино.`);
        instrument = 'keys.piano';
      }
    }
    const id = uniqueId(slugify(t.id ?? t.name, `track${i + 1}`), trackIds);
    trackIds.add(id);
    song.tracks.push({
      id,
      name: String(t.name ?? id).slice(0, 60),
      instrument,
      role: t.role ?? null,
      part: typeof t.part === 'string' ? t.part : null,
      volume: num(t.volume, TRACK_DEFAULTS.volume, 0, 1.5),
      pan: num(t.pan, 0, -1, 1),
      reverb: num(t.reverb, TRACK_DEFAULTS.reverb, 0, 1),
      delay: num(t.delay, 0, 0, 1),
      sidechain: num(t.sidechain, 0, 0, 1),
      mute: !!t.mute,
      solo: !!t.solo,
      locked: !!t.locked,
    });
    if (t.id != null && t.id !== id) warnings.push(`id дорожки "${t.id}" заменён на "${id}".`);
  });
  const trackById = new Map(song.tracks.map((t) => [t.id, t]));
  const trackKeyMap = new Map();
  rawTracks.forEach((t, i) => {
    if (song.tracks[i]) {
      trackKeyMap.set(String(t.id ?? ''), song.tracks[i].id);
      trackKeyMap.set(String(t.name ?? ''), song.tracks[i].id);
      trackKeyMap.set(song.tracks[i].id, song.tracks[i].id);
    }
  });

  // Секции
  const sectionIds = new Set();
  const sectionKeyMap = new Map();
  const rawSections = Array.isArray(raw.sections) ? raw.sections : [];
  rawSections.forEach((s, i) => {
    if (!s || typeof s !== 'object') return;
    const id = uniqueId(slugify(s.id ?? s.name, `section${i + 1}`), sectionIds);
    sectionIds.add(id);
    sectionKeyMap.set(String(s.id ?? ''), id);
    sectionKeyMap.set(String(s.name ?? ''), id);
    sectionKeyMap.set(id, id);
    const bars = Math.round(num(s.bars, 4, 1, 64));
    const total = bars * spb;
    const section = {
      id,
      name: String(s.name ?? id).slice(0, 60),
      kind: s.kind ?? null,
      bars,
      energy: s.energy == null ? null : num(s.energy, 0.5, 0, 1),
      chords: [],
      parts: {},
    };
    if (Array.isArray(s.chords)) {
      section.chords = s.chords.map((c) => String(c ?? '').trim());
      for (const entry of section.chords) {
        for (const sym of entry.split(/\s+/).filter(Boolean)) {
          if (sym !== '-' && !parseChord(sym)) warnings.push(`Секция "${section.name}": не понял аккорд "${sym}".`);
        }
      }
    } else if (typeof s.chords === 'string') {
      section.chords = s.chords.split(/[,;]+|\s{2,}/).map((c) => c.trim()).filter(Boolean);
    }

    const parts = s.parts && typeof s.parts === 'object' ? s.parts : {};
    for (const [key, part] of Object.entries(parts)) {
      const tid = trackKeyMap.get(key) ?? (trackById.has(slugify(key)) ? slugify(key) : null);
      if (!tid) {
        warnings.push(`Секция "${section.name}": партия для неизвестной дорожки "${key}" пропущена.`);
        continue;
      }
      const track = trackById.get(tid);
      if (isDrumInstrument(track.instrument)) {
        section.parts[tid] = normalizeDrumPart(part, total, spb, section.name, warnings);
      } else {
        section.parts[tid] = normalizeNotes(part, total, section.name, track.name, warnings);
      }
    }
    song.sections.push(section);
  });

  if (!song.sections.length) {
    warnings.push('В песне не было секций — добавил пустую.');
    song.sections.push({ id: 'a', name: 'A', kind: null, bars: 4, energy: null, chords: [], parts: {} });
    sectionIds.add('a');
  }

  // Порядок секций
  const arr = Array.isArray(raw.arrangement) ? raw.arrangement : [];
  for (const ref of arr) {
    const id = sectionKeyMap.get(String(ref)) ?? (sectionIds.has(slugify(ref)) ? slugify(ref) : null);
    if (id) song.arrangement.push(id);
    else warnings.push(`В порядке секций неизвестная секция "${ref}" — пропущена.`);
  }
  if (!song.arrangement.length) song.arrangement = song.sections.map((s) => s.id);

  return { song, warnings };
}

function normalizeDrumPart(part, total, spb, secName, warnings) {
  const out = {};
  if (!part || typeof part !== 'object' || Array.isArray(part)) {
    warnings.push(`Секция "${secName}": партия ударных должна быть объектом вида {"kick": "x...x..."}.`);
    return out;
  }
  for (const [voiceRaw, pattern] of Object.entries(part)) {
    const voice = normalizeVoiceName(voiceRaw);
    if (!voice) {
      warnings.push(`Секция "${secName}": неизвестный барабан "${voiceRaw}" (есть: ${DRUM_VOICES.join(', ')}).`);
      continue;
    }
    const cells = parseDrumPattern(pattern, total);
    if (cells.some(Boolean)) out[voice] = drumPatternToString(cells, spb);
  }
  return out;
}

const VOICE_ALIASES = {
  bd: 'kick', bassdrum: 'kick', бочка: 'kick',
  sd: 'snare', snaredrum: 'snare',
  hh: 'hat', hihat: 'hat', closedhat: 'hat', ch: 'hat', 'hi-hat': 'hat',
  oh: 'openhat', 'open-hat': 'openhat', openhihat: 'openhat',
  cymbal: 'crash', cy: 'crash',
  rimshot: 'rim', perc: 'rim', stick: 'rim',
  tomhigh: 'tom1', tomhi: 'tom1', hightom: 'tom1',
  tommid: 'tom2', midtom: 'tom2', tom: 'tom2',
  tomlow: 'tom3', lowtom: 'tom3', floortom: 'tom3',
  shake: 'shaker', maracas: 'shaker', tambourine: 'shaker',
};
function normalizeVoiceName(v) {
  const low = String(v).trim().toLowerCase().replace(/[\s_]/g, '');
  if (DRUM_VOICES.includes(low)) return low;
  return VOICE_ALIASES[low] || null;
}

function normalizeNotes(part, total, secName, trackName, warnings) {
  if (!Array.isArray(part)) {
    warnings.push(`Секция "${secName}", "${trackName}": партия должна быть массивом нот.`);
    return [];
  }
  const notes = [];
  let bad = 0;
  let outside = 0;
  for (const n of part) {
    let step, note, len, vel;
    if (Array.isArray(n)) [step, note, len, vel] = n;
    else if (n && typeof n === 'object') {
      step = pickField(n, ['step', 's', 't', 'start', 'time']);
      if (step === undefined && n.beat !== undefined) step = Number(n.beat) * 4;
      note = pickField(n, ['note', 'n', 'pitch', 'midi']);
      len = pickField(n, ['len', 'l', 'd', 'dur', 'duration', 'length']);
      if (len === undefined && n.beats !== undefined) len = Number(n.beats) * 4;
      vel = pickField(n, ['vel', 'v', 'velocity']);
    } else {
      bad++;
      continue;
    }
    const midi = noteToMidi(note);
    const st = Number(step);
    if (midi == null || !Number.isFinite(st)) {
      bad++;
      continue;
    }
    if (st < 0 || st >= total) {
      outside++;
      continue;
    }
    let v = Number(vel);
    if (!Number.isFinite(v)) v = 0.8;
    if (v > 1.5) v = v / 127; // скорость в стиле MIDI (0–127)
    notes.push({
      step: Math.round(st * 1000) / 1000,
      note: typeof note === 'string' && /^[A-Ga-g]/.test(note) ? canonicalNote(note, midi) : midiToNote(midi),
      len: Math.round(num(len, 1, 0.1, 256) * 1000) / 1000,
      vel: Math.round(num(v, 0.8, 0.05, 1) * 100) / 100,
    });
  }
  if (bad) warnings.push(`Секция "${secName}", "${trackName}": ${bad} нот не распознано (нужно "note": "A3", "step": число).`);
  if (outside) warnings.push(`Секция "${secName}", "${trackName}": ${outside} нот за пределами секции — удалены.`);
  notes.sort((a, b) => a.step - b.step || noteToMidi(a.note) - noteToMidi(b.note));
  return notes;
}

function canonicalNote(text, midi) {
  const t = String(text).trim();
  const flats = /^[A-Ga-g](b|♭)/.test(t);
  return midiToNote(midi, flats);
}

// ---------------------------------------------------------------------------
// Сериализация: компактно и читаемо (одна нота — одна строка, дефолтные поля опускаются).

export function serializableSong(song) {
  return {
    format: FORMAT_ID,
    version: FORMAT_VERSION,
    title: song.title,
    style: song.style ?? undefined,
    seed: song.seed ?? undefined,
    bpm: song.bpm,
    key: song.key,
    scale: song.scale,
    beatsPerBar: song.beatsPerBar,
    swing: song.swing || undefined,
    swingGrid: song.swing && song.swingGrid === 8 ? 8 : undefined,
    loop: song.loop,
    tracks: song.tracks.map((t) => {
      const o = { id: t.id, name: t.name, instrument: t.instrument };
      if (t.role) o.role = t.role;
      if (t.part) o.part = t.part;
      o.volume = round2(t.volume);
      if (t.pan) o.pan = round2(t.pan);
      o.reverb = round2(t.reverb);
      if (t.delay) o.delay = round2(t.delay);
      if (t.sidechain) o.sidechain = round2(t.sidechain);
      if (t.mute) o.mute = true;
      if (t.solo) o.solo = true;
      if (t.locked) o.locked = true;
      return o;
    }),
    sections: song.sections.map((s) => {
      const o = { id: s.id, name: s.name };
      if (s.kind) o.kind = s.kind;
      o.bars = s.bars;
      if (s.energy != null) o.energy = round2(s.energy);
      o.chords = s.chords;
      o.parts = {};
      for (const t of song.tracks) {
        const p = s.parts[t.id];
        if (!p) continue;
        if (Array.isArray(p)) {
          if (p.length) o.parts[t.id] = p.map((n) => ({ step: n.step, note: n.note, len: n.len, vel: n.vel }));
        } else if (Object.keys(p).length) o.parts[t.id] = p;
      }
      return o;
    }),
    arrangement: song.arrangement,
  };
}

const round2 = (v) => Math.round(v * 100) / 100;

export function stringifySong(song) {
  return pretty(JSON.parse(JSON.stringify(serializableSong(song))), 0);
}

function inline(v) {
  if (Array.isArray(v)) return '[' + v.map(inline).join(', ') + ']';
  if (v && typeof v === 'object') {
    return '{ ' + Object.entries(v).map(([k, x]) => JSON.stringify(k) + ': ' + inline(x)).join(', ') + ' }';
  }
  return JSON.stringify(v);
}

function isFlat(v) {
  const vals = Array.isArray(v) ? v : Object.values(v);
  return vals.every((x) => x === null || typeof x !== 'object');
}

function pretty(v, depth) {
  if (v === null || typeof v !== 'object') return JSON.stringify(v);
  const pad = '  '.repeat(depth + 1);
  const end = '  '.repeat(depth);
  if (isFlat(v)) {
    const s = inline(v);
    if (s.length + depth * 2 <= 150) return s;
  }
  if (Array.isArray(v)) {
    if (!v.length) return '[]';
    return '[\n' + v.map((x) => pad + pretty(x, depth + 1)).join(',\n') + '\n' + end + ']';
  }
  const entries = Object.entries(v);
  if (!entries.length) return '{}';
  return '{\n' + entries.map(([k, x]) => pad + JSON.stringify(k) + ': ' + pretty(x, depth + 1)).join(',\n') + '\n' + end + '}';
}

export function keyLabel(song) {
  const pc = parsePitchClass(song.key) ?? 0;
  return pcName(pc, prefersFlats(pc, song.scale));
}
