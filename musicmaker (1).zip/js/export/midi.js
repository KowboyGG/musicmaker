// Экспорт в стандартный MIDI-файл (формат 1): можно открыть в FL Studio, Reaper, Ableton и т.д.
import { compileSong } from '../core/timeline.js';
import { INSTRUMENT_MAP, GM_DRUM_NOTES, isDrumInstrument } from '../core/instruments-meta.js';

const PPQ = 480;

function varLen(n) {
  const bytes = [n & 0x7f];
  n >>= 7;
  while (n > 0) {
    bytes.unshift((n & 0x7f) | 0x80);
    n >>= 7;
  }
  return bytes;
}

function textBytes(s) {
  return [...new TextEncoder().encode(s)];
}

function trackChunk(events) {
  // events: [{ tick, data: [...] }]
  events.sort((a, b) => a.tick - b.tick || a.order - b.order);
  const body = [];
  let last = 0;
  for (const e of events) {
    body.push(...varLen(Math.max(0, e.tick - last)), ...e.data);
    last = e.tick;
  }
  body.push(0, 0xff, 0x2f, 0);
  const len = body.length;
  return [0x4d, 0x54, 0x72, 0x6b, (len >>> 24) & 255, (len >>> 16) & 255, (len >>> 8) & 255, len & 255, ...body];
}

export function songToMidi(song) {
  const compiled = compileSong(song);
  const secToTick = (s) => Math.round((s / (60 / song.bpm)) * PPQ);
  const chunks = [];

  const tempo = Math.round(60000000 / song.bpm);
  const meta = [
    { tick: 0, order: 0, data: [0xff, 0x51, 3, (tempo >> 16) & 255, (tempo >> 8) & 255, tempo & 255] },
    { tick: 0, order: 0, data: [0xff, 0x58, 4, song.beatsPerBar, 2, 24, 8] },
    { tick: 0, order: 0, data: [0xff, 0x03, ...varLen(textBytes(song.title).length), ...textBytes(song.title)] },
  ];
  for (const s of compiled.sections) {
    const t = textBytes(s.name);
    meta.push({ tick: secToTick(s.start), order: 1, data: [0xff, 0x06, ...varLen(t.length), ...t] });
  }
  chunks.push(trackChunk(meta));

  let nextCh = 0;
  song.tracks.forEach((track, ti) => {
    const drums = isDrumInstrument(track.instrument);
    let ch;
    if (drums) ch = 9;
    else {
      if (nextCh === 9) nextCh++;
      ch = nextCh % 16;
      nextCh++;
    }
    const name = textBytes(track.name);
    const evs = [{ tick: 0, order: 0, data: [0xff, 0x03, ...varLen(name.length), ...name] }];
    if (!drums) evs.push({ tick: 0, order: 0, data: [0xc0 | ch, INSTRUMENT_MAP[track.instrument]?.gm ?? 0] });
    evs.push({ tick: 0, order: 0, data: [0xb0 | ch, 7, Math.round(Math.min(1, track.volume) * 110)] });
    evs.push({ tick: 0, order: 0, data: [0xb0 | ch, 10, Math.round(64 + (track.pan || 0) * 63)] });
    for (const e of compiled.events) {
      if (e.track !== ti) continue;
      const note = drums ? GM_DRUM_NOTES[e.voice] : e.midi;
      if (note == null) continue;
      const vel = Math.max(1, Math.min(127, Math.round(e.vel * 127)));
      const on = secToTick(e.time);
      const off = Math.max(on + 1, secToTick(e.time + (drums ? 0.05 : e.dur)));
      evs.push({ tick: on, order: 2, data: [0x90 | ch, note, vel] });
      evs.push({ tick: off, order: 1, data: [0x80 | ch, note, 0] });
    }
    chunks.push(trackChunk(evs));
  });

  const header = [0x4d, 0x54, 0x68, 0x64, 0, 0, 0, 6, 0, 1, (chunks.length >> 8) & 255, chunks.length & 255, (PPQ >> 8) & 255, PPQ & 255];
  const all = header.concat(...chunks);
  return new Uint8Array(all);
}
