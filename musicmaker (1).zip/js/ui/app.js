// Главный контроллер интерфейса.
import { h, $, option, fmtTime, toast, saveFile, copyText, ICONS, cssVar } from './dom.js';
import { PianoRoll, DrumGrid, drawMiniPart } from './pianoroll.js';
import { Player } from '../audio/player.js';
import { renderSong } from '../audio/render.js';
import { encodeWav } from '../export/wav.js';
import { songToMidi } from '../export/midi.js';
import { makeZip } from '../export/zip.js';
import {
  normalizeSong, stringifySong, createEmptySong, createTrack, sectionOrder, stepsPerBar, songDurationSeconds,
  parseDrumPattern, drumPatternToString, uniqueId, slugify, ROLE_NAMES, SongFormatError, isDrumTrack,
} from '../core/song.js';
import { compileSong } from '../core/timeline.js';
import { KEY_NAMES, SCALES, noteToMidi, midiToNote, parsePitchClass } from '../core/theory.js';
import { INSTRUMENTS, instrumentMeta, isDrumInstrument } from '../core/instruments-meta.js';
import { aiPrompt } from '../core/ai-prompt.js';
import { STYLES, STYLE_ORDER, GENERIC_ROLES, PART_CHOICES } from '../gen/styles.js';
import {
  generateSong, developSong, regeneratePart, regenerateChords, regenerateSection, LENGTHS, SECTION_KINDS, roleFromInstrument,
} from '../gen/generator.js';
import { randomSeed } from '../core/rng.js';

const LS_SONG = 'musicmaker.song.v1';
const LS_GEN = 'musicmaker.gen.v1';
const BAR_PX = 24;

const ROLE_ORDER = ['drums', 'bass', 'chords', 'pad', 'arp', 'lead', 'counter', 'fx'];

function lsGet(k) {
  try {
    return localStorage.getItem(k);
  } catch {
    return null;
  }
}
function lsSet(k, v) {
  try {
    localStorage.setItem(k, v);
  } catch {
    /* хранилище недоступно — просто не сохраняем */
  }
}

function roleOf(track) {
  return track.role || roleFromInstrument(track.instrument);
}
function roleColor(role) {
  return cssVar(`--r-${role}`) || cssVar('--r-fx');
}
function sectionColorVar(kind) {
  const k = { loop: 'chorus', loopA: 'verse', loopB: 'chorus' }[kind] || kind;
  return SECTION_KINDS[kind] ? `var(--s-${k})` : 'var(--s-other)';
}

function defaultRoles(styleId) {
  return STYLES[styleId].roles.map((r) => ({ id: r.id, role: r.role, name: r.name, instrument: r.instrument, enabled: true }));
}

function instrumentSelect(current, { drums }) {
  const sel = h('select', { 'aria-label': 'Инструмент' });
  const groups = new Map();
  for (const i of INSTRUMENTS) {
    if (drums !== undefined && (i.kind === 'drums') !== drums) continue;
    if (!groups.has(i.group)) groups.set(i.group, []);
    groups.get(i.group).push(i);
  }
  for (const [g, list] of groups) {
    const og = h('optgroup', { label: g });
    for (const i of list) og.append(option(i.id, i.name, i.id === current));
    sel.append(og);
  }
  return sel;
}

export function startApp() {
  const player = new Player();
  const state = {
    song: null,
    sel: { slot: 0, trackId: null },
    gen: null,
    undo: [],
    redo: [],
    mode: 'song',
    loopSong: false,
  };

  // ---------------------------------------------------------------- Настройки генератора
  try {
    const g = JSON.parse(lsGet(LS_GEN) || 'null');
    if (g && STYLES[g.style]) state.gen = g;
  } catch {
    /* повреждённые настройки — берём по умолчанию */
  }
  if (!state.gen) state.gen = { style: 'synthwave', mood: 'auto', length: 'medium', bpm: '', key: 'auto', energy: 0.5, seed: '', roles: defaultRoles('synthwave') };
  const saveGen = () => lsSet(LS_GEN, JSON.stringify(state.gen));

  // ---------------------------------------------------------------- Песня и история
  let saveTimer = null;
  const scheduleSave = () => {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => lsSet(LS_SONG, stringifySong(state.song)), 500);
  };

  function fixSelection() {
    const order = state.song.arrangement;
    if (state.sel.slot >= order.length) state.sel.slot = Math.max(0, order.length - 1);
    if (!state.song.tracks.some((t) => t.id === state.sel.trackId)) state.sel.trackId = state.song.tracks[0]?.id ?? null;
  }
  const selSection = () => state.song.sections.find((s) => s.id === state.song.arrangement[state.sel.slot]) || null;
  const selTrack = () => state.song.tracks.find((t) => t.id === state.sel.trackId) || null;

  function changed({ render = true } = {}) {
    fixSelection();
    player.setSong(state.song);
    scheduleSave();
    if (render) renderAll();
  }

  function commit(fn, opts) {
    state.undo.push(JSON.stringify(state.song));
    if (state.undo.length > 150) state.undo.shift();
    state.redo = [];
    fn(state.song);
    changed(opts);
  }

  function setSong(song, { history = true, keepSel = false } = {}) {
    if (history && state.song) {
      state.undo.push(JSON.stringify(state.song));
      state.redo = [];
    }
    state.song = song;
    if (!keepSel) {
      const core = song.arrangement.findIndex((id) => {
        const s = song.sections.find((x) => x.id === id);
        return s && ['chorus', 'loop', 'loopB'].includes(s.kind);
      });
      state.sel.slot = core >= 0 ? core : 0;
      const lead = song.tracks.find((t) => roleOf(t) === 'lead') || song.tracks[0];
      state.sel.trackId = lead?.id ?? null;
    }
    state.loopSong = !!song.loop;
    $('#loop-song').checked = state.loopSong;
    changed();
  }

  function undo() {
    if (!state.undo.length) return;
    state.redo.push(JSON.stringify(state.song));
    state.song = JSON.parse(state.undo.pop());
    changed();
  }
  function redo() {
    if (!state.redo.length) return;
    state.undo.push(JSON.stringify(state.song));
    state.song = JSON.parse(state.redo.pop());
    changed();
  }

  // live-правки ползунками: одна запись в истории на жест
  let liveSnap = null;
  function live(fn) {
    if (!liveSnap) liveSnap = JSON.stringify(state.song);
    fn(state.song);
    player.setSong(state.song);
  }
  function liveDone() {
    if (!liveSnap) return;
    state.undo.push(liveSnap);
    state.redo = [];
    liveSnap = null;
    scheduleSave();
  }

  // ---------------------------------------------------------------- Статические элементы
  const keySel = $('#song-key');
  const genKey = $('#gen-key');
  genKey.append(option('auto', 'Авто'));
  for (const k of KEY_NAMES) {
    keySel.append(option(k, k));
    genKey.append(option(k, k));
  }
  const scaleSel = $('#song-scale');
  for (const [id, sc] of Object.entries(SCALES)) scaleSel.append(option(id, sc.name));
  const styleSel = $('#gen-style');
  for (const id of STYLE_ORDER) styleSel.append(option(id, STYLES[id].name));
  const lenSel = $('#gen-length');
  for (const [id, l] of Object.entries(LENGTHS)) lenSel.append(option(id, l.name));
  const addRole = $('#gen-add-role');
  for (const r of ROLE_ORDER) addRole.append(option(r, ROLE_NAMES[r]));

  // ---------------------------------------------------------------- Генератор (левая панель)
  function renderGen() {
    const g = state.gen;
    styleSel.value = g.style;
    $('#gen-style-desc').textContent = STYLES[g.style].description;
    $('#gen-mood').value = g.mood;
    lenSel.value = g.length;
    $('#gen-bpm').value = g.bpm;
    $('#gen-bpm').placeholder = `авто (${STYLES[g.style].bpm.join('–')})`;
    genKey.value = g.key;
    $('#gen-energy').value = g.energy;
    $('#gen-energy-label').textContent = g.energy < 0.34 ? 'спокойнее' : g.energy > 0.66 ? 'мощнее' : 'средняя';
    $('#gen-seed').value = g.seed;
    const box = $('#gen-roles');
    box.replaceChildren();
    g.roles.forEach((r, i) => {
      const cb = h('input', { type: 'checkbox', checked: r.enabled !== false, 'aria-label': `Включить блок ${r.name}` });
      cb.addEventListener('change', () => {
        r.enabled = cb.checked;
        saveGen();
        renderGen();
      });
      const sel = instrumentSelect(r.instrument, { drums: r.role === 'drums' });
      sel.addEventListener('change', () => {
        r.instrument = sel.value;
        saveGen();
      });
      const row = h('div', { class: 'role-row' + (r.enabled === false ? ' off' : '') },
        cb,
        h('span', { class: 'role-dot', style: { background: roleColor(r.role) } }),
        h('div', { class: 'role-main' },
          h('span', { class: 'role-name', title: ROLE_NAMES[r.role] }, r.name || ROLE_NAMES[r.role]),
          sel,
        ),
      );
      if (!STYLES[g.style].roles.some((x) => x.id === r.id)) {
        const rm = h('button', { class: 'tbtn', type: 'button', title: 'Убрать блок', 'aria-label': 'Убрать блок' }, '✕');
        rm.addEventListener('click', () => {
          g.roles.splice(i, 1);
          saveGen();
          renderGen();
        });
        row.style.gridTemplateColumns = '18px 10px minmax(0,1fr) 24px';
        row.append(rm);
      }
      box.append(row);
    });
  }

  styleSel.addEventListener('change', () => {
    state.gen.style = styleSel.value;
    state.gen.roles = defaultRoles(styleSel.value);
    saveGen();
    renderGen();
  });
  $('#gen-mood').addEventListener('change', (e) => ((state.gen.mood = e.target.value), saveGen()));
  lenSel.addEventListener('change', (e) => ((state.gen.length = e.target.value), saveGen()));
  $('#gen-bpm').addEventListener('change', (e) => ((state.gen.bpm = e.target.value), saveGen()));
  genKey.addEventListener('change', (e) => ((state.gen.key = e.target.value), saveGen()));
  $('#gen-energy').addEventListener('input', (e) => {
    state.gen.energy = Number(e.target.value);
    $('#gen-energy-label').textContent = state.gen.energy < 0.34 ? 'спокойнее' : state.gen.energy > 0.66 ? 'мощнее' : 'средняя';
    saveGen();
  });
  $('#gen-seed').addEventListener('change', (e) => ((state.gen.seed = e.target.value), saveGen()));
  addRole.addEventListener('change', () => {
    const type = addRole.value;
    addRole.value = '';
    if (!type) return;
    const base = GENERIC_ROLES[type];
    const id = uniqueId(type, state.gen.roles.map((r) => r.id));
    state.gen.roles.push({ id, role: type, name: base.name, instrument: base.instrument, enabled: true });
    saveGen();
    renderGen();
  });
  $('#gen-toggle').addEventListener('click', () => {
    const gen = $('#gen');
    gen.classList.toggle('collapsed');
    const open = !gen.classList.contains('collapsed');
    $('#gen-toggle').textContent = open ? 'Свернуть' : 'Развернуть';
    $('#gen-toggle').setAttribute('aria-expanded', String(open));
  });

  function genOptions() {
    const g = state.gen;
    const seed = g.seed ? Number(g.seed) : randomSeed();
    return {
      style: g.style,
      mood: g.mood,
      length: g.length,
      bpm: g.bpm ? Number(g.bpm) : undefined,
      key: g.key,
      energy: g.energy,
      roles: g.roles,
      seed,
    };
  }

  $('#btn-generate').addEventListener('click', () => {
    player.stop();
    const opts = genOptions();
    const song = generateSong(opts);
    setSong(song);
    toast(`Готово: «${song.title}». Вариант № ${song.seed}`);
  });
  $('#btn-develop').addEventListener('click', () => {
    const sec = selSection();
    try {
      player.stop();
      const song = developSong(state.song, { ...genOptions(), sourceSectionId: sec?.id });
      setSong(song);
      toast(`Идея развита: «${sec?.name}» стала припевом, остальное достроено.`);
    } catch (e) {
      toast(e.message, { error: true });
    }
  });
  $('#btn-empty').addEventListener('click', () => {
    player.stop();
    setSong(createEmptySong());
    toast('Пустой проект: рисуйте ноты в секции «Идея», затем нажмите «Развить мою идею».');
  });

  // ---------------------------------------------------------------- Верхняя панель
  $('#song-bpm').addEventListener('change', (e) => {
    const v = Math.max(30, Math.min(300, Math.round(Number(e.target.value) || 110)));
    commit((s) => (s.bpm = v));
  });
  keySel.addEventListener('change', () => transposeTo(keySel.value));
  scaleSel.addEventListener('change', () => commit((s) => (s.scale = scaleSel.value)));
  $('#song-title').addEventListener('change', (e) => commit((s) => (s.title = e.target.value.trim() || 'Без названия'), { render: false }));

  function transposeTo(newKey) {
    const from = parsePitchClass(state.song.key) ?? 0;
    const to = parsePitchClass(newKey) ?? 0;
    let d = to - from;
    if (d > 6) d -= 12;
    if (d < -6) d += 12;
    commit((s) => {
      s.key = newKey;
      if (!d) return;
      for (const sec of s.sections) {
        for (const t of s.tracks) {
          const p = sec.parts[t.id];
          if (!Array.isArray(p)) continue;
          for (const n of p) n.note = midiToNote(Math.max(0, Math.min(127, noteToMidi(n.note) + d)), /b/.test(newKey));
        }
        sec.chords = sec.chords.map((entry) => entry.split(/\s+/).map((c) => transposeChord(c, d, /b/.test(newKey))).join(' '));
      }
    });
    toast(d ? `Песня транспонирована в ${newKey} (${d > 0 ? '+' : ''}${d} полутонов).` : `Тоника: ${newKey}`);
  }

  function transposeChord(sym, d, flats) {
    const m = /^([A-G][#b]?)(.*?)(?:\/([A-G][#b]?))?$/.exec(sym);
    if (!m) return sym;
    const names = flats ? ['C', 'Db', 'D', 'Eb', 'E', 'F', 'Gb', 'G', 'Ab', 'A', 'Bb', 'B'] : ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
    const tr = (n) => names[(((parsePitchClass(n) ?? 0) + d) % 12 + 12) % 12];
    return tr(m[1]) + m[2] + (m[3] ? '/' + tr(m[3]) : '');
  }

  // Режим проигрывания
  const setMode = (mode) => {
    state.mode = mode;
    $('#mode-song').setAttribute('aria-checked', String(mode === 'song'));
    $('#mode-section').setAttribute('aria-checked', String(mode === 'section'));
    if (player.playing) play();
  };
  $('#mode-song').addEventListener('click', () => setMode('song'));
  $('#mode-section').addEventListener('click', () => setMode('section'));
  $('#loop-song').addEventListener('change', (e) => {
    state.loopSong = e.target.checked;
    if (player.playing && state.mode === 'song') player.loop = state.loopSong;
  });

  async function play(from = null) {
    try {
      if (state.mode === 'section') await player.play({ sectionIndex: state.sel.slot, loop: true });
      else await player.play({ from, loop: state.loopSong });
      $('#btn-play').classList.add('playing');
      $('.btn-play-label').textContent = 'Стоп';
      tickUi();
    } catch (e) {
      toast('Не удалось запустить звук: ' + e.message, { error: true });
    }
  }
  function stop() {
    player.stop();
    $('#btn-play').classList.remove('playing');
    $('.btn-play-label').textContent = 'Играть';
    updatePlayheads(null);
  }
  player.onEnded = () => stop();
  $('#btn-play').addEventListener('click', () => (player.playing ? stop() : play()));
  $('#btn-undo').addEventListener('click', undo);
  $('#btn-redo').addEventListener('click', redo);

  document.addEventListener('keydown', (e) => {
    const tag = e.target.tagName;
    const typing = ['INPUT', 'TEXTAREA', 'SELECT'].includes(tag) || e.target.isContentEditable;
    if (e.code === 'Space' && !typing) {
      e.preventDefault();
      player.playing ? stop() : play();
    } else if ((e.ctrlKey || e.metaKey) && e.code === 'KeyZ' && !typing) {
      e.preventDefault();
      e.shiftKey ? redo() : undo();
    } else if ((e.ctrlKey || e.metaKey) && e.code === 'KeyY' && !typing) {
      e.preventDefault();
      redo();
    } else if (e.key === 'Escape') {
      closeDrawers();
      closePopover();
      $('#menu-export').hidden = true;
    }
  });

  // ---------------------------------------------------------------- Индикаторы воспроизведения
  let raf = null;
  function tickUi() {
    cancelAnimationFrame(raf);
    const loop = () => {
      if (!player.playing) return;
      updatePlayheads(player.position());
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
  }

  function updatePlayheads(t) {
    const c = player.compiled || compileSong(state.song);
    const total = c.duration;
    const lcdT = $('#lcd-time');
    const lcdP = $('#lcd-pos');
    const ph = $('#grid-playhead');
    if (t == null) {
      lcdT.textContent = `0:00 / ${fmtTime(total)}`;
      lcdP.textContent = 'стоп';
      if (ph) ph.hidden = true;
      editorView?.setPlayStep(null);
      return;
    }
    lcdT.textContent = `${fmtTime(t)} / ${fmtTime(total)}`;
    const si = c.sections.findIndex((s) => t >= s.start && t < s.end);
    const s = c.sections[si];
    if (!s) return;
    const rel = t - s.start;
    const bar = Math.floor(rel / c.barDur);
    const beat = Math.floor((rel - bar * c.barDur) / c.beatDur);
    lcdP.textContent = `${s.name} · такт ${bar + 1}.${beat + 1}`;
    const head = document.querySelector(`.sec-head[data-slot="${si}"]`);
    if (ph && head) {
      ph.hidden = false;
      ph.style.left = head.offsetLeft + ((rel / (s.end - s.start)) * head.offsetWidth) + 'px';
    }
    const step = rel / c.stepDur;
    editorView?.setPlayStep(s.id === selSection()?.id ? step : null);
  }

  // ---------------------------------------------------------------- Сетка аранжировки
  const popover = { el: null };
  function closePopover() {
    popover.el?.remove();
    popover.el = null;
  }
  document.addEventListener('pointerdown', (e) => {
    if (popover.el && !popover.el.contains(e.target) && !e.target.closest('[data-pop]')) closePopover();
    if (!e.target.closest('.menu-wrap')) $('#menu-export').hidden = true;
  });
  function openPopover(anchor, content) {
    closePopover();
    const r = anchor.getBoundingClientRect();
    const el = h('div', { class: 'menu', style: { position: 'fixed', top: `${Math.min(r.bottom + 6, innerHeight - 320)}px`, left: `${Math.max(8, Math.min(r.left, innerWidth - 280))}px`, right: 'auto', width: '270px', padding: '12px', gap: '10px' } }, content);
    document.body.append(el);
    popover.el = el;
    return el;
  }

  function slider(label, value, min, max, step, onInput) {
    const id = 'pop-' + slugify(label);
    const inp = h('input', { type: 'range', id, min, max, step, value });
    inp.addEventListener('input', () => onInput(Number(inp.value)));
    inp.addEventListener('change', liveDone);
    return h('label', { class: 'field', for: id }, label, inp);
  }

  function trackMenu(anchor, track) {
    const role = roleOf(track);
    const content = [
      slider('Панорама (лево — право)', track.pan, -1, 1, 0.05, (v) => live((s) => (s.tracks.find((t) => t.id === track.id).pan = v))),
      slider('Реверберация', track.reverb, 0, 1, 0.02, (v) => live((s) => (s.tracks.find((t) => t.id === track.id).reverb = v))),
      slider('Эхо (задержка)', track.delay, 0, 1, 0.02, (v) => live((s) => (s.tracks.find((t) => t.id === track.id).delay = v))),
      slider('Пампинг (сайдчейн)', track.sidechain, 0, 1, 0.05, (v) => live((s) => (s.tracks.find((t) => t.id === track.id).sidechain = v))),
    ];
    const roleSel = h('select', { id: 'pop-role' });
    for (const r of ROLE_ORDER) roleSel.append(option(r, ROLE_NAMES[r], r === role));
    roleSel.addEventListener('change', () => {
      commit((s) => {
        const t = s.tracks.find((x) => x.id === track.id);
        t.role = roleSel.value;
        t.part = null;
      });
      closePopover();
    });
    content.push(h('label', { class: 'field', for: 'pop-role' }, 'Роль (для кнопки «Новая партия»)', roleSel));
    const choices = PART_CHOICES[role];
    if (choices) {
      const partSel = h('select', { id: 'pop-part' });
      partSel.append(option('', 'Как в жанре'));
      for (const [k, v] of Object.entries(choices)) partSel.append(option(k, v, k === track.part));
      partSel.addEventListener('change', () => commit((s) => (s.tracks.find((t) => t.id === track.id).part = partSel.value || null)));
      content.push(h('label', { class: 'field', for: 'pop-part' }, 'Как играть', partSel));
    }
    const del = h('button', { class: 'btn btn-danger btn-sm', type: 'button' }, 'Удалить дорожку');
    del.addEventListener('click', () => {
      closePopover();
      commit((s) => {
        s.tracks = s.tracks.filter((t) => t.id !== track.id);
        for (const sec of s.sections) delete sec.parts[track.id];
      });
      toast(`Дорожка «${track.name}» удалена. Ctrl+Z — вернуть.`);
    });
    content.push(del);
    openPopover(anchor, content);
  }

  function renderGrid() {
    const song = state.song;
    const grid = $('#grid');
    grid.replaceChildren();
    const order = sectionOrder(song);
    const widths = order.map((s) => Math.max(92, s.bars * BAR_PX));
    grid.style.gridTemplateColumns = `var(--head-w) ${widths.map((w) => w + 'px').join(' ')}`;
    const selId = selSection()?.id;
    const spb = stepsPerBar(song);

    grid.append(h('div', { class: 'gcell corner' }, 'Дорожки / секции'));
    order.forEach((sec, i) => {
      const e = sec.energy ?? SECTION_KINDS[sec.kind]?.energy ?? 0.5;
      const chords = (sec.chords || []).slice(0, 4).join(' ');
      const head = h('div', {
        class: 'gcell sec-head' + (i === state.sel.slot ? ' sel' : sec.id === selId ? ' same' : ''),
        'data-slot': i,
        style: { '--sec-color': sectionColorVar(sec.kind) },
        title: `${sec.name}: ${sec.bars} такт., аккорды ${sec.chords.join(' ')}. Двойной клик — играть отсюда.`,
      },
        h('span', { class: 'sec-name' }, sec.name),
        h('span', { class: 'sec-sub' }, `${sec.bars} т · ${chords}`),
        h('div', { class: 'energy', 'aria-hidden': 'true' }, h('i', { style: { width: `${Math.round(e * 100)}%` } })),
      );
      head.addEventListener('click', () => {
        state.sel.slot = i;
        renderGrid();
        renderEditor();
        if (player.playing && state.mode === 'section') play();
      });
      head.addEventListener('dblclick', () => {
        const c = compileSong(state.song);
        state.mode === 'section' ? play() : play(c.sections[i]?.start ?? 0);
      });
      grid.append(head);
    });

    const previews = [];
    for (const t of song.tracks) {
      const role = roleOf(t);
      const color = roleColor(role);
      const drums = isDrumInstrument(t.instrument);
      const nameInp = h('input', { class: 'track-name', value: t.name, 'aria-label': 'Название дорожки', maxlength: 60 });
      nameInp.addEventListener('change', () => commit((s) => (s.tracks.find((x) => x.id === t.id).name = nameInp.value.trim() || t.id)));
      nameInp.addEventListener('click', (e) => e.stopPropagation());
      const btn = (label, cls, title, on, fn) => {
        const b = h('button', { class: 'tbtn' + (on ? ' ' + cls : ''), type: 'button', title, 'aria-label': title, 'aria-pressed': String(!!on) });
        if (label.startsWith('<')) b.innerHTML = label;
        else b.textContent = label;
        b.addEventListener('click', (e) => {
          e.stopPropagation();
          fn(b);
        });
        return b;
      };
      const mute = btn('M', 'on-m', 'Заглушить', t.mute, () => commit((s) => (s.tracks.find((x) => x.id === t.id).mute = !t.mute)));
      const solo = btn('S', 'on-s', 'Соло', t.solo, () => commit((s) => (s.tracks.find((x) => x.id === t.id).solo = !t.solo)));
      const lock = btn(ICONS.lock, 'on-l', 'Закрепить: генератор не будет менять эту дорожку', t.locked, () => commit((s) => (s.tracks.find((x) => x.id === t.id).locked = !t.locked)));
      const gear = btn(ICONS.gear, '', 'Настройки дорожки', false, (b) => trackMenu(b, t));
      gear.setAttribute('data-pop', '1');
      const inst = instrumentSelect(t.instrument, { drums });
      inst.addEventListener('click', (e) => e.stopPropagation());
      inst.addEventListener('change', () => commit((s) => (s.tracks.find((x) => x.id === t.id).instrument = inst.value)));
      const vol = h('input', { type: 'range', min: 0, max: 1.2, step: 0.01, value: t.volume, 'aria-label': 'Громкость', title: 'Громкость' });
      vol.addEventListener('click', (e) => e.stopPropagation());
      vol.addEventListener('input', () => live((s) => (s.tracks.find((x) => x.id === t.id).volume = Number(vol.value))));
      vol.addEventListener('change', liveDone);
      const head = h('div', { class: 'gcell track-head' + (t.id === state.sel.trackId ? ' sel' : ''), style: { '--role-color': color } },
        h('div', { class: 'track-stripe' }),
        h('div', {},
          h('div', { class: 'track-top' }, nameInp, mute, solo, lock, gear),
          h('div', { class: 'track-bottom' }, inst, vol),
        ),
      );
      head.addEventListener('click', () => {
        state.sel.trackId = t.id;
        renderGrid();
        renderEditor();
      });
      grid.append(head);

      order.forEach((sec, i) => {
        const part = sec.parts[t.id];
        const has = part && (Array.isArray(part) ? part.length : Object.keys(part).length);
        const cvs = h('canvas');
        const cell = h('div', {
          class: 'gcell cell' + (i === state.sel.slot && t.id === state.sel.trackId ? ' sel' : '') + (sec.id === selId && i !== state.sel.slot ? ' same' : '') + (has ? '' : ' empty'),
          title: `${t.name} — ${sec.name}`,
        }, has ? cvs : null);
        cell.addEventListener('click', () => {
          state.sel.slot = i;
          state.sel.trackId = t.id;
          renderGrid();
          renderEditor();
        });
        if (has) previews.push(() => drawMiniPart(cvs, { part, steps: sec.bars * spb, drums, color }));
        grid.append(cell);
      });
    }
    const ph = h('div', { class: 'playhead-col', id: 'grid-playhead', hidden: true });
    grid.style.position = 'relative';
    grid.append(ph);
    requestAnimationFrame(() => previews.forEach((f) => f()));
  }

  $('#btn-add-track').addEventListener('click', (e) => {
    const sel = instrumentSelect('keys.piano', {});
    sel.id = 'pop-new-inst';
    const add = h('button', { class: 'btn btn-accent btn-sm', type: 'button' }, 'Добавить дорожку');
    add.addEventListener('click', () => {
      const instrument = sel.value;
      const role = roleFromInstrument(instrument);
      const meta = instrumentMeta(instrument);
      closePopover();
      commit((s) => {
        const id = uniqueId(slugify(role), s.tracks.map((t) => t.id));
        s.tracks.push(createTrack({ id, name: meta?.name || ROLE_NAMES[role], instrument, role, volume: 0.7, reverb: 0.2 }));
        state.sel.trackId = id;
      });
      toast('Дорожка добавлена. Нарисуйте партию в редакторе или нажмите «Новая партия».');
    });
    const b = e.currentTarget;
    b.setAttribute('data-pop', '1');
    openPopover(b, [h('label', { class: 'field', for: 'pop-new-inst' }, 'Инструмент новой дорожки', sel), add]);
  });

  $('#btn-add-section').addEventListener('click', () => {
    const cur = selSection();
    commit((s) => {
      const id = uniqueId('section', s.sections.map((x) => x.id));
      s.sections.push({ id, name: 'Новая секция', kind: null, bars: 4, energy: null, chords: cur ? cur.chords.slice(0, 4) : [], parts: {} });
      s.arrangement.splice(state.sel.slot + 1, 0, id);
      state.sel.slot += 1;
    });
  });

  // ---------------------------------------------------------------- Редактор
  let editorView = null;
  const roll = new PianoRoll({
    onChange: (notes) => commit((s) => (s.sections.find((x) => x.id === selSection().id).parts[state.sel.trackId] = notes)),
    onPreview: (midi) => player.preview(state.sel.trackId, midi),
  });
  const drumGrid = new DrumGrid({
    onChange: (part) => commit((s) => (s.sections.find((x) => x.id === selSection().id).parts[state.sel.trackId] = part)),
    onPreview: (voice) => player.preview(state.sel.trackId, voice),
  });

  function chordsToText(chords) {
    return (chords || []).join(' | ');
  }
  function textToChords(text) {
    const t = text.trim();
    if (!t) return [];
    if (t.includes('|')) return t.split('|').map((x) => x.trim().replace(/\s+/g, ' ')).filter(Boolean);
    return t.split(/[\s,;]+/).filter(Boolean);
  }

  function resizeSection(sec, bars) {
    const spb = stepsPerBar(state.song);
    const total = bars * spb;
    for (const t of state.song.tracks) {
      const p = sec.parts[t.id];
      if (!p) continue;
      if (Array.isArray(p)) sec.parts[t.id] = p.filter((n) => n.step < total);
      else {
        const out = {};
        for (const [v, pat] of Object.entries(p)) out[v] = drumPatternToString(parseDrumPattern(pat, total), spb);
        sec.parts[t.id] = out;
      }
    }
    sec.bars = bars;
  }

  function renderEditor() {
    const box = $('#editor');
    box.replaceChildren();
    const song = state.song;
    const sec = selSection();
    if (!sec) {
      box.append(h('div', { class: 'ed-empty' }, 'Добавьте секцию, чтобы начать.'));
      return;
    }
    const slot = state.sel.slot;
    const repeats = song.arrangement.filter((id) => id === sec.id).length;

    // Панель секции
    const nameInp = h('input', { type: 'text', id: 'sec-name', value: sec.name, maxlength: 60 });
    nameInp.addEventListener('change', () => commit((s) => (s.sections.find((x) => x.id === sec.id).name = nameInp.value.trim() || sec.id)));
    const barsInp = h('input', { type: 'number', id: 'sec-bars', min: 1, max: 64, value: sec.bars });
    barsInp.addEventListener('change', () => {
      const b = Math.max(1, Math.min(64, Math.round(Number(barsInp.value) || sec.bars)));
      commit((s) => resizeSection(s.sections.find((x) => x.id === sec.id), b));
    });
    const chordsInp = h('input', { type: 'text', id: 'sec-chords', class: 'chords-input', value: chordsToText(sec.chords), placeholder: 'Am | F | C | G', spellcheck: false });
    chordsInp.addEventListener('change', () => commit((s) => (s.sections.find((x) => x.id === sec.id).chords = textToChords(chordsInp.value))));
    const b = (label, title, fn, cls = '') => {
      const x = h('button', { class: 'btn btn-sm ' + cls, type: 'button', title }, label);
      x.addEventListener('click', fn);
      return x;
    };
    const secBar = h('div', { class: 'ed-bar' },
      h('h3', {}, 'Секция'),
      h('span', { class: 'tag', style: { '--c': sectionColorVar(sec.kind) } }, h('i'), repeats > 1 ? `звучит ${repeats} раза` : ''),
      h('label', { class: 'field-inline name-field', for: 'sec-name' }, 'Имя', nameInp),
      h('label', { class: 'field-inline bars-field', for: 'sec-bars' }, 'Тактов', barsInp),
      h('label', { class: 'chords-field', for: 'sec-chords' }, 'Аккорды по тактам (через |)', chordsInp),
    );
    const secTools = h('div', { class: 'ed-bar' },
      b('Новые аккорды', 'Подобрать другую последовательность аккордов из жанра', () => {
        commit((s) => (s.sections.find((x) => x.id === sec.id).chords = regenerateChords(s, sec.id)));
        toast('Аккорды заменены. «Вся секция заново» перепишет партии под них.');
      }),
      b('Вся секция заново', 'Переписать все незакреплённые дорожки этой секции', () => {
        commit((s) => (s.sections.find((x) => x.id === sec.id).parts = regenerateSection(s, sec.id)));
      }),
      h('span', { class: 'grow' }),
      b('◀', 'Сдвинуть влево', () => moveSlot(-1)),
      b('▶', 'Сдвинуть вправо', () => moveSlot(1)),
      b('Повторить', 'Сыграть эту же секцию ещё раз следом (правки общие)', () => commit((s) => {
        s.arrangement.splice(slot + 1, 0, sec.id);
        state.sel.slot = slot + 1;
      })),
      b('Копия', 'Независимая копия секции — её можно менять отдельно', () => commit((s) => {
        const copy = JSON.parse(JSON.stringify(sec));
        copy.id = uniqueId(sec.id, s.sections.map((x) => x.id));
        copy.name = sec.name + ' 2';
        s.sections.push(copy);
        s.arrangement.splice(slot + 1, 0, copy.id);
        state.sel.slot = slot + 1;
      })),
      b('Убрать', 'Убрать секцию из этого места', () => {
        if (song.arrangement.length <= 1) {
          toast('В песне должна остаться хотя бы одна секция.', { error: true });
          return;
        }
        commit((s) => {
          s.arrangement.splice(slot, 1);
          if (!s.arrangement.includes(sec.id)) s.sections = s.sections.filter((x) => x.id !== sec.id);
        });
      }, 'btn-danger'),
    );
    box.append(secBar, secTools);

    // Панель дорожки
    const track = selTrack();
    if (!track) {
      box.append(h('div', { class: 'ed-empty' }, 'Выберите дорожку в сетке выше.'));
      return;
    }
    const role = roleOf(track);
    const color = roleColor(role);
    const drums = isDrumTrack(track);
    const trackBar = h('div', { class: 'ed-bar' },
      h('h3', {}, 'Партия'),
      h('span', { class: 'tag', style: { '--c': color } }, h('i'), `${track.name} · ${instrumentMeta(track.instrument)?.name || track.instrument}`),
      h('span', { class: 'grow' }),
    );
    trackBar.append(b('Новая партия', 'Сгенерировать партию этой дорожки заново под аккорды секции', () => {
      const part = regeneratePart(state.song, sec.id, track.id);
      commit((s) => (s.sections.find((x) => x.id === sec.id).parts[track.id] = part));
    }, 'btn-accent'));
    if (!drums) {
      const shift = (d) => commit((s) => {
        const p = s.sections.find((x) => x.id === sec.id).parts[track.id] || [];
        for (const n of p) n.note = midiToNote(Math.max(0, Math.min(127, noteToMidi(n.note) + d)), /b/.test(n.note));
      });
      trackBar.append(b('Октава −', 'Опустить партию на октаву', () => shift(-12)), b('Октава +', 'Поднять партию на октаву', () => shift(12)));
      const lens = [[1, '1/16'], [2, '1/8'], [4, '1/4'], [8, '1/2'], [16, '1']];
      const pick = h('div', { class: 'len-pick', role: 'group', 'aria-label': 'Длина новой ноты' });
      for (const [v, l] of lens) {
        const x = h('button', { class: 'btn btn-sm' + (roll.defaultLen === v ? ' on' : ''), type: 'button', title: `Новые ноты длиной ${l}` }, l);
        x.addEventListener('click', () => {
          roll.defaultLen = v;
          pick.querySelectorAll('button').forEach((bb) => bb.classList.remove('on'));
          x.classList.add('on');
        });
        pick.append(x);
      }
      trackBar.append(pick);
    }
    trackBar.append(b('Очистить', 'Удалить все ноты дорожки в этой секции', () => commit((s) => delete s.sections.find((x) => x.id === sec.id).parts[track.id]), 'btn-danger'));
    box.append(trackBar);

    const body = h('div', { class: 'ed-body' });
    box.append(body);
    editorView = drums ? drumGrid : roll;
    body.append(editorView.wrap);
    editorView.setData({ song, section: sec, track, color });
    const hint = drums
      ? 'Клик — поставить или убрать удар, протяжка — рисовать. Shift — акцент, Alt — тихий удар. Клик по названию — послушать.'
      : 'Нажмите и протяните — нарисовать ноту. Клик по ноте — удалить, перетащить — сдвинуть, за правый край — длина. Подсвечены звуки текущего аккорда.';
    box.append(h('p', { class: 'hint', style: { padding: '8px 12px 10px' } }, hint));
  }

  function moveSlot(d) {
    const i = state.sel.slot;
    const j = i + d;
    if (j < 0 || j >= state.song.arrangement.length) return;
    commit((s) => {
      const a = s.arrangement;
      [a[i], a[j]] = [a[j], a[i]];
      state.sel.slot = j;
    });
  }

  // ---------------------------------------------------------------- Шапка песни
  function renderHead() {
    const s = state.song;
    $('#song-title').value = s.title;
    $('#song-bpm').value = s.bpm;
    if (![...keySel.options].some((o) => o.value === s.key)) keySel.append(option(s.key, s.key));
    keySel.value = s.key;
    scaleSel.value = s.scale;
    const bars = sectionOrder(s).reduce((a, x) => a + x.bars, 0);
    const style = STYLES[s.style]?.name;
    const parts = [style, `${s.key} ${SCALES[s.scale]?.name.toLowerCase() || s.scale}`, `${s.bpm} уд/мин`, `${bars} тактов`, fmtTime(songDurationSeconds(s))];
    if (s.loop) parts.push('луп');
    if (s.seed) parts.push(`вариант № ${s.seed}`);
    $('#song-meta').textContent = parts.filter(Boolean).join(' · ');
    $('#btn-undo').disabled = !state.undo.length;
    $('#btn-redo').disabled = !state.redo.length;
  }

  function renderAll() {
    renderHead();
    renderGrid();
    renderEditor();
    if (!player.playing) updatePlayheads(null);
  }

  let resizeTimer = null;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => renderAll(), 150);
  });
  matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change', () => renderAll());

  // ---------------------------------------------------------------- JSON и ИИ
  function closeDrawers() {
    $('#drawer').hidden = true;
    $('#help').hidden = true;
  }
  $('#btn-json').addEventListener('click', () => {
    $('#json-text').value = stringifySong(state.song);
    $('#json-warn').replaceChildren();
    $('#drawer').hidden = false;
  });
  $('#drawer-close').addEventListener('click', closeDrawers);
  $('#drawer').addEventListener('click', (e) => e.target.id === 'drawer' && closeDrawers());
  $('#btn-help').addEventListener('click', () => ($('#help').hidden = false));
  $('#help-close').addEventListener('click', closeDrawers);
  $('#help').addEventListener('click', (e) => e.target.id === 'help' && closeDrawers());

  $('#json-copy-ai').addEventListener('click', async () => {
    const ok = await copyText(aiPrompt(state.song));
    toast(ok ? 'Скопировано: инструкция + песня. Вставьте в чат с ИИ и допишите просьбу.' : 'Не удалось скопировать — выделите текст в поле вручную.', { error: !ok });
  });
  $('#json-copy').addEventListener('click', async () => {
    const ok = await copyText(stringifySong(state.song));
    toast(ok ? 'JSON скопирован.' : 'Не удалось скопировать.', { error: !ok });
  });
  $('#json-open').addEventListener('click', () => $('#json-file').click());
  $('#json-file').addEventListener('change', (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = () => {
      $('#json-text').value = String(r.result);
      applyJson();
    };
    r.readAsText(f);
    e.target.value = '';
  });
  $('#json-apply').addEventListener('click', applyJson);

  function applyJson() {
    const warn = $('#json-warn');
    warn.replaceChildren();
    try {
      const { song, warnings } = normalizeSong($('#json-text').value);
      player.stop();
      stop();
      setSong(song, { keepSel: true });
      $('#json-text').value = stringifySong(state.song);
      if (warnings.length) {
        warn.append(h('div', {}, `Применено, с замечаниями (${warnings.length}):`), h('ul', {}, warnings.slice(0, 30).map((w) => h('li', {}, w))));
      } else warn.append(h('div', {}, 'Применено без замечаний.'));
      toast('Песня обновлена из JSON. Ctrl+Z — вернуть как было.');
    } catch (e) {
      warn.append(h('div', { class: 'err' }, e instanceof SongFormatError ? e.message : 'Ошибка: ' + e.message));
    }
  }

  // ---------------------------------------------------------------- Экспорт
  $('#btn-export').addEventListener('click', () => {
    const m = $('#menu-export');
    m.hidden = !m.hidden;
    $('#btn-export').setAttribute('aria-expanded', String(!m.hidden));
  });
  const busy = (title, frac) => {
    $('#busy').hidden = frac == null;
    $('#busy-title').textContent = title;
    $('#busy-fill').style.width = `${Math.round((frac || 0) * 100)}%`;
  };
  const fileBase = () => slugify(state.song.title, 'song');

  document.querySelectorAll('[data-export]').forEach((btn) => btn.addEventListener('click', async () => {
    $('#menu-export').hidden = true;
    const kind = btn.dataset.export;
    const song = JSON.parse(JSON.stringify(state.song));
    try {
      if (kind === 'json') {
        saveFile(`${fileBase()}.json`, stringifySong(song), 'application/json');
      } else if (kind === 'midi') {
        saveFile(`${fileBase()}.mid`, songToMidi(song), 'audio/midi');
      } else if (kind === 'wav' || kind === 'loop') {
        busy(kind === 'loop' ? 'Рендер бесшовного лупа…' : 'Рендер WAV…', 0);
        const audio = await renderSong(song, { seamlessLoop: kind === 'loop', onProgress: (f) => busy($('#busy-title').textContent, f) });
        saveFile(`${fileBase()}${kind === 'loop' ? '-loop' : ''}.wav`, encodeWav(audio), 'audio/wav');
        toast(`Готово: ${fmtTime(audio.duration)}, WAV 44.1 кГц.`);
      } else if (kind === 'stems') {
        const tracks = song.tracks.filter((t) => !t.mute && song.sections.some((s) => s.parts[t.id]));
        const files = [];
        for (let i = 0; i < tracks.length; i++) {
          const t = tracks[i];
          const title = `Стем ${i + 1} из ${tracks.length}: ${t.name}`;
          busy(title, i / tracks.length);
          const audio = await renderSong(song, {
            onlyTrackId: t.id, seamlessLoop: song.loop, normalize: false,
            onProgress: (f) => busy(title, (i + f) / tracks.length),
          });
          files.push({ name: `${String(i + 1).padStart(2, '0')}-${slugify(t.name, t.id)}.wav`, data: encodeWav(audio) });
        }
        saveFile(`${fileBase()}-stems.zip`, makeZip(files), 'application/zip');
        toast(`Готово: ${files.length} стемов в ZIP.`);
      }
    } catch (e) {
      toast('Экспорт не удался: ' + e.message, { error: true });
    } finally {
      busy('', null);
    }
  }));

  // ---------------------------------------------------------------- Старт
  renderGen();
  let initial = null;
  const saved = lsGet(LS_SONG);
  if (saved) {
    try {
      initial = normalizeSong(saved).song;
    } catch {
      initial = null;
    }
  }
  if (!initial) initial = generateSong({ style: 'synthwave', length: 'medium', seed: 2026 });
  setSong(initial, { history: false });

  // Для отладки и автотестов
  window.musicmaker = { state, player, setSong, generateSong, renderSong };
}
