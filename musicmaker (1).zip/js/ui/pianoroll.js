// Редактор нот (пианоролл) и сетка ударных на canvas.
import { noteToMidi, midiToNote, mod, parsePitchClass, scalePcs, chordPcs } from '../core/theory.js';
import { chordTimeline, stepsPerBar, parseDrumPattern, drumPatternToString, songUsesFlats } from '../core/song.js';
import { DRUM_VOICES, DRUM_VOICE_NAMES, instrumentMeta } from '../core/instruments-meta.js';
import { cssVar } from './dom.js';

const BLACK = new Set([1, 3, 6, 8, 10]);

function setupCanvas(canvas, w, h) {
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  canvas.width = Math.round(w * dpr);
  canvas.height = Math.round(h * dpr);
  canvas.style.width = w + 'px';
  canvas.style.height = h + 'px';
  const g = canvas.getContext('2d');
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  return g;
}

function withAlpha(color, a) {
  if (color.startsWith('#') && color.length === 7) {
    const n = parseInt(color.slice(1), 16);
    return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${a})`;
  }
  return color;
}

function roundRect(g, x, y, w, h, r) {
  g.beginPath();
  g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h);
}

function drawGrid(g, { x0, y0, steps, cellW, height, spb }) {
  const cBar = cssVar('--grid-bar');
  const cBeat = cssVar('--grid-beat');
  const cStep = cssVar('--grid-step');
  for (let s = 0; s <= steps; s++) {
    g.fillStyle = s % spb === 0 ? cBar : s % 4 === 0 ? cBeat : cStep;
    g.fillRect(x0 + s * cellW - (s % spb === 0 ? 0.5 : 0), y0, s % spb === 0 ? 1.5 : 1, height);
  }
}

// ---------------------------------------------------------------------------

export class PianoRoll {
  constructor({ onChange, onPreview }) {
    this.onChange = onChange;
    this.onPreview = onPreview;
    this.wrap = document.createElement('div');
    this.wrap.className = 'roll-wrap';
    this.canvas = document.createElement('canvas');
    this.wrap.append(this.canvas);
    this.KEY_W = 46;
    this.ROW_H = 13;
    this.HEAD_H = 24;
    this.defaultLen = 4;
    this.playStep = null;
    this.drag = null;
    this.wrap.addEventListener('scroll', () => this.draw());
    this.canvas.addEventListener('pointerdown', (e) => this.down(e));
    this.canvas.addEventListener('pointermove', (e) => this.move(e));
    this.canvas.addEventListener('pointerup', (e) => this.up(e));
    this.canvas.addEventListener('pointercancel', () => (this.drag = null));
    this.canvas.addEventListener('contextmenu', (e) => this.context(e));
  }

  setData({ song, section, track, color }) {
    const first = !this.track || this.track.id !== track.id || this.section?.id !== section.id;
    this.song = song;
    this.section = section;
    this.track = track;
    this.color = color;
    this.notes = (section.parts[track.id] || []).map((n) => ({ ...n, midi: noteToMidi(n.note) }));
    this.spb = stepsPerBar(song);
    this.steps = section.bars * this.spb;
    this.timeline = chordTimeline(song, section);
    const tonic = parsePitchClass(song.key) ?? 0;
    this.scale = scalePcs(tonic, song.scale);
    this.tonic = tonic;
    this.flats = songUsesFlats(song);
    const meta = instrumentMeta(track.instrument);
    let [lo, hi] = meta?.range || [36, 84];
    for (const n of this.notes) {
      lo = Math.min(lo, n.midi - 2);
      hi = Math.max(hi, n.midi + 2);
    }
    if (hi - lo < 24) {
      const mid = Math.round((hi + lo) / 2);
      lo = mid - 12;
      hi = mid + 12;
    }
    this.lo = Math.max(0, lo);
    this.hi = Math.min(127, hi);
    this.layout();
    if (first) this.scrollToNotes();
    this.draw();
  }

  layout() {
    const avail = Math.max(300, this.wrap.clientWidth || this.wrap.parentElement?.clientWidth || 800);
    this.cellW = Math.max(10, Math.min(30, Math.floor((avail - this.KEY_W - 2) / this.steps)));
    this.rows = this.hi - this.lo + 1;
    this.W = this.KEY_W + this.steps * this.cellW;
    this.H = this.HEAD_H + this.rows * this.ROW_H;
    this.g = setupCanvas(this.canvas, this.W, this.H);
  }

  scrollToNotes() {
    const midis = this.notes.map((n) => n.midi);
    const center = midis.length ? (Math.min(...midis) + Math.max(...midis)) / 2 : (this.lo + this.hi) / 2;
    const y = this.HEAD_H + (this.hi - center) * this.ROW_H;
    requestAnimationFrame(() => {
      this.wrap.scrollTop = Math.max(0, y - this.wrap.clientHeight / 2);
    });
  }

  yOf(midi) {
    return this.HEAD_H + (this.hi - midi) * this.ROW_H;
  }

  draw() {
    const g = this.g;
    if (!g) return;
    const { KEY_W, ROW_H, HEAD_H, cellW, steps, W, H } = this;
    const sl = this.wrap.scrollLeft;
    const st = this.wrap.scrollTop;
    g.clearRect(0, 0, W, H);
    const cWhite = cssVar('--key-white');
    const cBlack = cssVar('--key-black');
    const cScale = cssVar('--row-scale');
    const text = cssVar('--text');
    const muted = cssVar('--muted');
    const faint = cssVar('--faint');

    // Строки клавиш
    for (let m = this.hi; m >= this.lo; m--) {
      const y = this.yOf(m);
      const pc = mod(m, 12);
      g.fillStyle = BLACK.has(pc) ? cBlack : cWhite;
      g.fillRect(KEY_W, y, W - KEY_W, ROW_H);
      if (this.scale.includes(pc)) {
        g.fillStyle = cScale;
        g.fillRect(KEY_W, y, W - KEY_W, ROW_H);
      }
      if (pc === this.tonic) {
        g.fillStyle = cScale;
        g.fillRect(KEY_W, y, W - KEY_W, ROW_H);
      }
    }
    // Звуки текущего аккорда подсвечены
    for (const seg of this.timeline) {
      if (!seg.chord) continue;
      const pcs = chordPcs(seg.chord);
      g.fillStyle = withAlpha(this.color, 0.09);
      for (let m = this.hi; m >= this.lo; m--) {
        if (pcs.includes(mod(m, 12))) g.fillRect(KEY_W + seg.start * cellW, this.yOf(m), (seg.end - seg.start) * cellW, ROW_H);
      }
    }
    drawGrid(g, { x0: KEY_W, y0: HEAD_H, steps, cellW, height: H - HEAD_H, spb: this.spb });
    // Горизонтальные линии октав
    g.fillStyle = cssVar('--grid-beat');
    for (let m = this.hi; m >= this.lo; m--) if (mod(m, 12) === 0) g.fillRect(KEY_W, this.yOf(m) + ROW_H - 1, W - KEY_W, 1);

    // Ноты
    const notes = this.drag?.preview || this.notes;
    g.font = `600 9px ${cssVar('--font-mono') || 'monospace'}`;
    for (const n of notes) {
      if (n.midi < this.lo || n.midi > this.hi) continue;
      const x = KEY_W + n.step * cellW;
      const y = this.yOf(n.midi);
      const w = Math.max(3, n.len * cellW - 1);
      g.fillStyle = withAlpha(this.color, 0.45 + 0.55 * (n.vel ?? 0.8));
      roundRect(g, x + 0.5, y + 0.5, w, ROW_H - 1, 3);
      g.fill();
      g.strokeStyle = withAlpha('#000000', 0.35);
      g.lineWidth = 1;
      g.stroke();
      if (w > 28) {
        g.fillStyle = '#10131a';
        g.fillText(midiToNote(n.midi, this.flats), x + 4, y + ROW_H - 3.5);
      }
    }

    // Плейхед
    if (this.playStep != null && this.playStep >= 0 && this.playStep <= steps) {
      g.fillStyle = cssVar('--play');
      g.fillRect(KEY_W + this.playStep * cellW - 1, HEAD_H, 2, H - HEAD_H);
    }

    // Шапка: такты и аккорды (прилипает сверху)
    const hy = st;
    g.fillStyle = cssVar('--panel');
    g.fillRect(KEY_W, hy, W - KEY_W, HEAD_H);
    g.fillStyle = cssVar('--line');
    g.fillRect(KEY_W, hy + HEAD_H - 1, W - KEY_W, 1);
    g.font = `500 10px ${cssVar('--font-mono') || 'monospace'}`;
    for (let b = 0; b < this.section.bars; b++) {
      g.fillStyle = faint;
      g.fillText(String(b + 1), KEY_W + b * this.spb * cellW + 3, hy + 10);
    }
    g.font = `600 11px ${cssVar('--font-ui') || 'sans-serif'}`;
    for (const seg of this.timeline) {
      g.fillStyle = text;
      g.fillText(seg.symbol, KEY_W + seg.start * cellW + 3, hy + 21);
    }

    // Клавиатура слева (прилипает при горизонтальной прокрутке)
    const kx = sl;
    for (let m = this.hi; m >= this.lo; m--) {
      const y = this.yOf(m);
      const pc = mod(m, 12);
      g.fillStyle = BLACK.has(pc) ? cBlack : cWhite;
      g.fillRect(kx, y, KEY_W, ROW_H);
      g.fillStyle = cssVar('--line-soft');
      g.fillRect(kx, y + ROW_H - 1, KEY_W, 1);
      if (pc === 0 || pc === this.tonic) {
        g.fillStyle = pc === this.tonic ? cssVar('--accent') : muted;
        g.font = `600 9px ${cssVar('--font-mono') || 'monospace'}`;
        g.fillText(midiToNote(m, this.flats), kx + 4, y + ROW_H - 3.5);
      }
    }
    g.fillStyle = cssVar('--line');
    g.fillRect(kx + KEY_W - 1, 0, 1, H);
    g.fillStyle = cssVar('--panel');
    g.fillRect(kx, hy, KEY_W, HEAD_H);
  }

  pos(e) {
    const r = this.canvas.getBoundingClientRect();
    const x = e.clientX - r.left;
    const y = e.clientY - r.top;
    const stepF = (x - this.KEY_W) / this.cellW;
    const midi = this.hi - Math.floor((y - this.HEAD_H) / this.ROW_H);
    return { x, y, stepF, step: Math.floor(stepF), midi, inKeys: x < this.KEY_W + this.wrap.scrollLeft, inHead: y < this.HEAD_H + this.wrap.scrollTop };
  }

  hit(p) {
    for (let i = this.notes.length - 1; i >= 0; i--) {
      const n = this.notes[i];
      if (n.midi === p.midi && p.stepF >= n.step && p.stepF < n.step + n.len) return i;
    }
    return -1;
  }

  down(e) {
    if (e.button === 2) return;
    const p = this.pos(e);
    if (p.inHead) return;
    if (p.inKeys) {
      this.onPreview?.(p.midi);
      return;
    }
    if (p.midi < this.lo || p.midi > this.hi || p.step < 0 || p.step >= this.steps) return;
    this.canvas.setPointerCapture(e.pointerId);
    const i = this.hit(p);
    if (i >= 0) {
      const n = this.notes[i];
      const rightEdge = this.KEY_W + (n.step + n.len) * this.cellW;
      const mode = p.x > rightEdge - Math.min(8, n.len * this.cellW / 3) ? 'resize' : 'move';
      this.drag = { mode, index: i, start: p, orig: { ...n }, moved: false, lastMidi: n.midi, preview: this.notes.map((x) => ({ ...x })) };
    } else {
      const note = { step: p.step, midi: p.midi, len: Math.min(this.defaultLen, this.steps - p.step), vel: 0.8 };
      const preview = [...this.notes.map((x) => ({ ...x })), note];
      this.drag = { mode: 'draw', index: preview.length - 1, start: p, orig: { ...note }, moved: true, preview };
      this.onPreview?.(p.midi);
    }
    this.draw();
  }

  move(e) {
    if (!this.drag) {
      const p = this.pos(e);
      const i = p.inKeys || p.inHead ? -1 : this.hit(p);
      let cursor = 'crosshair';
      if (i >= 0) {
        const n = this.notes[i];
        const rightEdge = this.KEY_W + (n.step + n.len) * this.cellW;
        cursor = p.x > rightEdge - Math.min(8, n.len * this.cellW / 3) ? 'ew-resize' : 'grab';
      } else if (p.inKeys) cursor = 'pointer';
      this.canvas.style.cursor = cursor;
      return;
    }
    const d = this.drag;
    const p = this.pos(e);
    const n = d.preview[d.index];
    if (d.mode === 'draw' || d.mode === 'resize') {
      const end = Math.max(p.step + 1, d.orig.step + 1);
      const len = d.mode === 'draw' ? Math.max(d.orig.len, end - d.orig.step) : Math.max(1, Math.round(p.stepF - d.orig.step));
      n.len = Math.min(len, this.steps - d.orig.step);
      if (d.mode === 'resize' && n.len !== d.orig.len) d.moved = true;
    } else {
      const dStep = Math.round(p.stepF - d.start.stepF);
      const dMidi = p.midi - d.start.midi;
      if (dStep || dMidi) d.moved = true;
      n.step = Math.max(0, Math.min(this.steps - 1, d.orig.step + dStep));
      n.midi = Math.max(this.lo, Math.min(this.hi, d.orig.midi + dMidi));
      if (n.midi !== d.lastMidi) {
        d.lastMidi = n.midi;
        this.onPreview?.(n.midi);
      }
    }
    this.draw();
  }

  up() {
    const d = this.drag;
    if (!d) return;
    this.drag = null;
    let notes = d.preview;
    if (d.mode === 'move' && !d.moved) notes = this.notes.filter((_, i) => i !== d.index);
    this.commit(notes);
  }

  context(e) {
    e.preventDefault();
    const p = this.pos(e);
    const i = this.hit(p);
    if (i >= 0) this.commit(this.notes.filter((_, k) => k !== i));
  }

  commit(notes) {
    const out = notes
      .filter((n) => n.len > 0)
      .map((n) => ({ step: n.step, note: midiToNote(n.midi, this.flats), len: n.len, vel: n.vel ?? 0.8 }))
      .sort((a, b) => a.step - b.step || noteToMidi(a.note) - noteToMidi(b.note));
    this.onChange?.(out);
  }

  setPlayStep(step) {
    if (step === this.playStep) return;
    this.playStep = step;
    if (!this.drag) this.draw();
  }
}

// ---------------------------------------------------------------------------

export class DrumGrid {
  constructor({ onChange, onPreview }) {
    this.onChange = onChange;
    this.onPreview = onPreview;
    this.wrap = document.createElement('div');
    this.wrap.className = 'roll-wrap';
    this.canvas = document.createElement('canvas');
    this.wrap.append(this.canvas);
    this.LABEL_W = 118;
    this.ROW_H = 22;
    this.HEAD_H = 20;
    this.playStep = null;
    this.paint = null;
    this.wrap.addEventListener('scroll', () => this.draw());
    this.canvas.addEventListener('pointerdown', (e) => this.down(e));
    this.canvas.addEventListener('pointermove', (e) => this.move(e));
    this.canvas.addEventListener('pointerup', () => this.up());
    this.canvas.addEventListener('pointercancel', () => this.up());
    this.canvas.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  setData({ song, section, track, color }) {
    this.song = song;
    this.section = section;
    this.track = track;
    this.color = color;
    this.spb = stepsPerBar(song);
    this.steps = section.bars * this.spb;
    const part = section.parts[track.id] || {};
    this.cells = {};
    for (const v of DRUM_VOICES) this.cells[v] = parseDrumPattern(part[v] || '', this.steps);
    const avail = Math.max(300, this.wrap.clientWidth || this.wrap.parentElement?.clientWidth || 800);
    this.cellW = Math.max(12, Math.min(34, Math.floor((avail - this.LABEL_W - 2) / this.steps)));
    this.W = this.LABEL_W + this.steps * this.cellW;
    this.H = this.HEAD_H + DRUM_VOICES.length * this.ROW_H;
    this.g = setupCanvas(this.canvas, this.W, this.H);
    this.draw();
  }

  draw() {
    const g = this.g;
    if (!g) return;
    const { LABEL_W, ROW_H, HEAD_H, cellW, steps, W, H } = this;
    const sl = this.wrap.scrollLeft;
    g.clearRect(0, 0, W, H);
    const bg = cssVar('--bg');
    const alt = cssVar('--panel-2');
    for (let s = 0; s < steps; s++) {
      g.fillStyle = Math.floor(s / 4) % 2 ? alt : bg;
      g.fillRect(LABEL_W + s * cellW, HEAD_H, cellW, H - HEAD_H);
    }
    drawGrid(g, { x0: LABEL_W, y0: HEAD_H, steps, cellW, height: H - HEAD_H, spb: this.spb });
    g.fillStyle = cssVar('--line-soft');
    DRUM_VOICES.forEach((v, r) => g.fillRect(LABEL_W, HEAD_H + (r + 1) * ROW_H - 1, W - LABEL_W, 1));

    DRUM_VOICES.forEach((v, r) => {
      const y = HEAD_H + r * ROW_H;
      this.cells[v].forEach((c, s) => {
        if (!c) return;
        const x = LABEL_W + s * cellW;
        g.fillStyle = withAlpha(this.color, 0.35 + 0.65 * c.vel);
        if (c.n > 1) {
          const w = (cellW - 4) / c.n;
          for (let k = 0; k < c.n; k++) {
            roundRect(g, x + 2 + k * w, y + 4, Math.max(2, w - 1.5), ROW_H - 9, 2);
            g.fill();
          }
        } else {
          roundRect(g, x + 2, y + 3, cellW - 4, ROW_H - 7, 3);
          g.fill();
          if (c.vel >= 0.95) {
            g.fillStyle = '#ffffff';
            g.fillRect(x + cellW / 2 - 1.5, y + 7, 3, 3);
          }
        }
      });
    });

    if (this.playStep != null && this.playStep >= 0 && this.playStep <= steps) {
      g.fillStyle = cssVar('--play');
      g.fillRect(LABEL_W + this.playStep * cellW - 1, HEAD_H, 2, H - HEAD_H);
    }

    // Номера тактов
    g.fillStyle = cssVar('--panel');
    g.fillRect(LABEL_W, 0, W - LABEL_W, HEAD_H);
    g.font = `500 10px ${cssVar('--font-mono') || 'monospace'}`;
    g.fillStyle = cssVar('--faint');
    for (let b = 0; b < this.section.bars; b++) g.fillText(String(b + 1), LABEL_W + b * this.spb * cellW + 3, 13);

    // Подписи барабанов
    g.fillStyle = cssVar('--panel');
    g.fillRect(sl, 0, LABEL_W, H);
    g.font = `500 12px ${cssVar('--font-ui') || 'sans-serif'}`;
    DRUM_VOICES.forEach((v, r) => {
      const used = this.cells[v].some(Boolean);
      g.fillStyle = used ? cssVar('--text') : cssVar('--faint');
      g.fillText(DRUM_VOICE_NAMES[v], sl + 8, HEAD_H + r * ROW_H + 15);
    });
    g.fillStyle = cssVar('--line');
    g.fillRect(sl + LABEL_W - 1, 0, 1, H);
  }

  pos(e) {
    const r = this.canvas.getBoundingClientRect();
    const x = e.clientX - r.left;
    const y = e.clientY - r.top;
    return {
      x,
      step: Math.floor((x - this.LABEL_W) / this.cellW),
      row: Math.floor((y - this.HEAD_H) / this.ROW_H),
      inLabel: x < this.LABEL_W + this.wrap.scrollLeft,
    };
  }

  down(e) {
    const p = this.pos(e);
    if (p.row < 0 || p.row >= DRUM_VOICES.length) return;
    const voice = DRUM_VOICES[p.row];
    if (p.inLabel) {
      this.onPreview?.(voice);
      return;
    }
    if (p.step < 0 || p.step >= this.steps) return;
    this.canvas.setPointerCapture(e.pointerId);
    const cur = this.cells[voice][p.step];
    let value;
    if (e.shiftKey) value = { vel: 1, n: 1 };
    else if (e.altKey) value = { vel: 0.42, n: 1 };
    else value = cur ? null : { vel: 0.78, n: 1 };
    if (e.button === 2) value = null;
    this.paint = { voice, value, changed: new Set() };
    this.apply(p);
    if (value) this.onPreview?.(voice);
  }

  apply(p) {
    const d = this.paint;
    if (!d || p.step < 0 || p.step >= this.steps) return;
    const key = p.step;
    if (d.changed.has(key)) return;
    d.changed.add(key);
    this.cells[d.voice][p.step] = d.value ? { ...d.value } : null;
    this.draw();
  }

  move(e) {
    if (this.paint) this.apply(this.pos(e));
  }

  up() {
    if (!this.paint) return;
    this.paint = null;
    const part = {};
    for (const v of DRUM_VOICES) if (this.cells[v].some(Boolean)) part[v] = drumPatternToString(this.cells[v], this.spb);
    this.onChange?.(part);
  }

  setPlayStep(step) {
    if (step === this.playStep) return;
    this.playStep = step;
    if (!this.paint) this.draw();
  }
}

// ---------------------------------------------------------------------------
// Миниатюра партии для клетки сетки аранжировки.

export function drawMiniPart(canvas, { part, steps, drums, color }) {
  const w = canvas.clientWidth || 100;
  const h = canvas.clientHeight || 40;
  const g = setupCanvas(canvas, w, h);
  g.clearRect(0, 0, w, h);
  if (!part) return;
  const sx = w / steps;
  if (drums) {
    const voices = DRUM_VOICES.filter((v) => part[v]);
    const rh = Math.min(6, h / Math.max(1, voices.length));
    voices.forEach((v, r) => {
      const cells = parseDrumPattern(part[v], steps);
      cells.forEach((c, s) => {
        if (!c) return;
        g.fillStyle = withAlpha(color, 0.35 + 0.65 * c.vel);
        g.fillRect(s * sx, r * (h / voices.length) + (h / voices.length - rh) / 2, Math.max(1.5, sx - 1), rh);
      });
    });
    return;
  }
  const midis = part.map((n) => noteToMidi(n.note));
  if (!midis.length) return;
  let lo = Math.min(...midis);
  let hi = Math.max(...midis);
  if (hi - lo < 12) {
    const m = (hi + lo) / 2;
    lo = m - 6;
    hi = m + 6;
  }
  const rh = Math.max(2, Math.min(4, h / (hi - lo + 1)));
  part.forEach((n, i) => {
    const y = h - rh - ((midis[i] - lo) / (hi - lo || 1)) * (h - rh);
    g.fillStyle = withAlpha(color, 0.5 + 0.5 * (n.vel ?? 0.8));
    g.fillRect(n.step * sx, y, Math.max(1.5, n.len * sx - 0.5), rh);
  });
}
