// Сквозная проверка в настоящем браузере (headless Chromium):
// генерация → воспроизведение → правка нот → JSON → экспорт WAV/MIDI/стемов.
// Запуск: node tests/browser/e2e.mjs
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { startServer, launch } from './harness.mjs';

const shotsDir = process.env.SHOTS_DIR || null;
const { server, url } = await startServer();
const browser = await launch();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 1000 }, acceptDownloads: true });
const page = await ctx.newPage();
const errors = [];
page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
page.on('console', (m) => {
  if (m.type() === 'error' && !/fonts\.g|ERR_CERT|net::ERR/.test(m.text())) errors.push('console: ' + m.text());
});

let failed = 0;
async function step(name, fn) {
  try {
    await fn();
    console.log('ok  ', name);
  } catch (e) {
    failed++;
    console.log('FAIL', name, '\n     ', e.message);
  }
}
const assert = (cond, msg) => {
  if (!cond) throw new Error(msg);
};

await page.goto(url + '/index.html');
await page.evaluate(() => localStorage.clear());
await page.reload();
await page.waitForFunction(() => window.musicmaker?.state?.song);

await step('открывается с готовой демо-песней', async () => {
  const n = await page.locator('.sec-head').count();
  assert(n >= 4, `секций в сетке: ${n}`);
  const cells = await page.locator('.cell canvas').count();
  assert(cells > 10, `клеток с партиями: ${cells}`);
});

await step('генерация в каждом жанре через интерфейс', async () => {
  const styles = await page.$$eval('#gen-style option', (o) => o.map((x) => x.value));
  assert(styles.length >= 18, 'жанров меньше 18');
  for (const s of styles) {
    await page.selectOption('#gen-style', s);
    await page.click('#btn-generate');
    const title = await page.inputValue('#song-title');
    assert(title.length > 0, `${s}: нет названия`);
  }
  await page.selectOption('#gen-style', 'synthwave');
  await page.fill('#gen-seed', '777');
  await page.dispatchEvent('#gen-seed', 'change');
  await page.click('#btn-generate');
  const seed = await page.evaluate(() => window.musicmaker.state.song.seed);
  assert(seed === 777, 'seed не применился');
});

await step('воспроизведение идёт и позиция растёт', async () => {
  await page.click('#btn-play');
  await page.waitForTimeout(1500);
  const pos = await page.evaluate(() => window.musicmaker.player.position());
  assert(pos > 0.5, `позиция ${pos}`);
  const lcd = await page.textContent('#lcd-pos');
  assert(/такт/.test(lcd), `индикатор: ${lcd}`);
  await page.click('#btn-play');
  const playing = await page.evaluate(() => window.musicmaker.player.playing);
  assert(!playing, 'не остановилось');
});

await step('рисование и удаление ноты в пианоролле', async () => {
  // выбрать дорожку мелодии в секции припева
  await page.evaluate(() => {
    const { state } = window.musicmaker;
    const lead = state.song.tracks.find((t) => t.role === 'lead');
    state.sel.trackId = lead.id;
  });
  await page.locator('.sec-head').nth(2).click();
  const wrap = page.locator('.roll-wrap');
  await wrap.waitFor();
  await wrap.scrollIntoViewIfNeeded();
  const before = await page.evaluate(() => {
    const { state } = window.musicmaker;
    const sec = state.song.sections.find((s) => s.id === state.song.arrangement[state.sel.slot]);
    return (sec.parts[state.sel.trackId] || []).length;
  });
  const box = await wrap.boundingBox();
  // клик в видимой области редактора, ниже шапки с аккордами
  const x = box.x + box.width - 30;
  const y = box.y + 44;
  await page.mouse.move(x, y);
  await page.mouse.down();
  await page.mouse.up();
  const after = await page.evaluate(() => {
    const { state } = window.musicmaker;
    const sec = state.song.sections.find((s) => s.id === state.song.arrangement[state.sel.slot]);
    return (sec.parts[state.sel.trackId] || []).length;
  });
  assert(after === before + 1 || after === before - 1, `нот было ${before}, стало ${after}`);
  await page.keyboard.press('Control+z');
  const undone = await page.evaluate(() => {
    const { state } = window.musicmaker;
    const sec = state.song.sections.find((s) => s.id === state.song.arrangement[state.sel.slot]);
    return (sec.parts[state.sel.trackId] || []).length;
  });
  assert(undone === before, 'отмена не сработала');
});

await step('сетка ударных: клик ставит удар', async () => {
  await page.evaluate(() => {
    const { state } = window.musicmaker;
    state.sel.trackId = state.song.tracks.find((t) => t.instrument.startsWith('drums.')).id;
  });
  await page.locator('.sec-head').nth(1).click();
  const canvas = page.locator('.roll-wrap canvas');
  await canvas.scrollIntoViewIfNeeded();
  const box = await canvas.boundingBox();
  const read = () => page.evaluate(() => {
    const { state } = window.musicmaker;
    const sec = state.song.sections.find((s) => s.id === state.song.arrangement[state.sel.slot]);
    return JSON.stringify(sec.parts[state.sel.trackId] || {});
  });
  const before = await read();
  await page.mouse.click(box.x + 118 + 5, box.y + 20 + 22 * 11 + 10); // том низкий, шаг 0
  const after = await read();
  assert(before !== after, 'партия не изменилась');
});

await step('JSON: применить ответ «ИИ» с лишним текстом', async () => {
  await page.click('#btn-json');
  const json = await page.inputValue('#json-text');
  const song = JSON.parse(json);
  song.bpm = 133;
  song.title = 'Правка от ИИ';
  const reply = 'Конечно! Вот изменённая песня:\n```json\n' + JSON.stringify(song, null, 2) + '\n```\nНадеюсь, понравится.';
  await page.$eval('#json-text', (el, v) => (el.value = v), reply);
  await page.click('#json-apply');
  const s = await page.evaluate(() => window.musicmaker.state.song);
  assert(s.bpm === 133 && s.title === 'Правка от ИИ', 'правка не применилась');
  await page.$eval('#json-text', (el) => (el.value = '{ сломанный json'));
  await page.click('#json-apply');
  const warn = await page.textContent('#json-warn');
  assert(/JSON/.test(warn), 'нет сообщения об ошибке');
  await page.click('#drawer-close');
});

await step('копирование для ИИ содержит инструкцию и песню', async () => {
  const text = await page.evaluate(async () => (await import('/js/core/ai-prompt.js')).aiPrompt(window.musicmaker.state.song));
  assert(text.includes('ФОРМАТ ПЕСНИ') && text.includes('"tracks"') && text.includes('МОЯ ПРОСЬБА'), 'неполный текст');
});

async function download(kind) {
  await page.click('#btn-export');
  const [dl] = await Promise.all([page.waitForEvent('download', { timeout: 180000 }), page.click(`[data-export="${kind}"]`)]);
  const file = path.join(os.tmpdir(), 'mm-' + dl.suggestedFilename());
  await dl.saveAs(file);
  return fs.readFileSync(file);
}

await step('экспорт MIDI', async () => {
  const buf = await download('midi');
  assert(buf.slice(0, 4).toString() === 'MThd', 'не MIDI');
});

await step('экспорт WAV-лупа (короткий луп)', async () => {
  await page.selectOption('#gen-length', 'loop8');
  await page.selectOption('#gen-style', 'chiptune');
  await page.fill('#gen-seed', '');
  await page.dispatchEvent('#gen-seed', 'change');
  await page.click('#btn-generate');
  const buf = await download('loop');
  assert(buf.slice(0, 4).toString() === 'RIFF' && buf.slice(8, 12).toString() === 'WAVE', 'не WAV');
  // Длительность = ровно длина лупа
  const dur = await page.evaluate(async () => {
    const { songDurationSeconds } = await import('/js/core/song.js');
    return songDurationSeconds(window.musicmaker.state.song);
  });
  const samples = (buf.length - 44) / 4;
  assert(Math.abs(samples / 44100 - dur) < 0.01, `длина ${samples / 44100} vs ${dur}`);
  // Не тишина
  let peak = 0;
  for (let i = 44; i < buf.length; i += 2) peak = Math.max(peak, Math.abs(buf.readInt16LE(i)));
  assert(peak > 8000, `слишком тихо: ${peak}`);
});

await step('экспорт стемов (ZIP)', async () => {
  const buf = await download('stems');
  assert(buf.readUInt32LE(0) === 0x04034b50, 'не ZIP');
});

await step('пустой проект и «развить идею»', async () => {
  await page.click('#btn-empty');
  await page.evaluate(() => {
    const { state, setSong } = window.musicmaker;
    const s = JSON.parse(JSON.stringify(state.song));
    s.sections[0].parts.drums = { kick: 'x...x...x...x...', snare: '....x.......x...' };
    s.sections[0].parts.lead = [
      { step: 0, note: 'A4', len: 4, vel: 0.8 }, { step: 4, note: 'C5', len: 4, vel: 0.8 },
      { step: 8, note: 'E5', len: 8, vel: 0.8 }, { step: 16, note: 'D5', len: 8, vel: 0.8 },
    ];
    setSong(s, { keepSel: true });
  });
  await page.selectOption('#gen-length', 'medium');
  await page.click('#btn-develop');
  const n = await page.evaluate(() => window.musicmaker.state.song.sections.length);
  assert(n >= 4, `секций: ${n}`);
});

await step('узкий экран: нет горизонтальной прокрутки страницы', async () => {
  await page.setViewportSize({ width: 400, height: 900 });
  await page.waitForTimeout(300);
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  assert(overflow <= 1, `страница шире экрана на ${overflow}px`);
  if (shotsDir) await page.screenshot({ path: path.join(shotsDir, 'mobile.png'), fullPage: false });
  await page.setViewportSize({ width: 1440, height: 1000 });
});

if (shotsDir) {
  await page.waitForTimeout(300);
  await page.screenshot({ path: path.join(shotsDir, 'e2e-desktop.png') });
}

await step('нет ошибок в консоли', async () => {
  assert(!errors.length, errors.join('\n'));
});

await browser.close();
server.close();
console.log(failed ? `\n${failed} проверок не прошли` : '\nВсе проверки прошли');
process.exit(failed ? 1 : 0);
