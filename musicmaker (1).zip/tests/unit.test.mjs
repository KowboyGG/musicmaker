// Юнит-тесты логики (без звука): node --test tests/
import test from 'node:test';
import assert from 'node:assert/strict';
import {
  noteToMidi, midiToNote, parseChord, romanToChordSymbol, progressionToSymbols, voiceChord,
  detectKey, harmonizeBars, scalePcs, mod, chordPcs,
} from '../js/core/theory.js';
import {
  normalizeSong, stringifySong, createEmptySong, chordTimeline, parseDrumPattern, extractJson,
} from '../js/core/song.js';
import { compileSong } from '../js/core/timeline.js';
import { generateSong, developSong, regeneratePart, regenerateSection, regenerateChords, LENGTHS } from '../js/gen/generator.js';
import { STYLES, STYLE_ORDER } from '../js/gen/styles.js';
import { INSTRUMENT_MAP } from '../js/core/instruments-meta.js';
import { songToMidi } from '../js/export/midi.js';

test('ноты ↔ midi', () => {
  assert.equal(noteToMidi('C4'), 60);
  assert.equal(noteToMidi('A2'), 45);
  assert.equal(noteToMidi('Bb3'), 58);
  assert.equal(noteToMidi('c#5'), 73);
  assert.equal(noteToMidi('H2'), null);
  assert.equal(midiToNote(61), 'C#4');
  assert.equal(midiToNote(61, true), 'Db4');
});

test('разбор аккордов', () => {
  assert.deepEqual(parseChord('Am').intervals, [0, 3, 7]);
  assert.equal(parseChord('F#m7b5').quality, 'm7b5');
  assert.equal(parseChord('C/E').bass, 4);
  assert.equal(parseChord('Bbmaj7').root, 10);
  assert.equal(parseChord('Xyz'), null);
});

test('римские ступени', () => {
  assert.equal(romanToChordSymbol('i', 9), 'Am');
  assert.equal(romanToChordSymbol('bVI', 9), 'F');
  assert.equal(romanToChordSymbol('bVII', 9), 'G');
  assert.equal(romanToChordSymbol('V7', 0), 'G7');
  assert.equal(romanToChordSymbol('ii7', 0), 'Dm7');
  assert.equal(romanToChordSymbol('im7', 0), 'Cm7');
  assert.equal(romanToChordSymbol('imMaj7', 0), 'CmMaj7');
  assert.equal(romanToChordSymbol('iiø7', 0), 'Dm7b5');
  assert.equal(romanToChordSymbol('bVImaj7', 0, true), 'Abmaj7');
  // Все прогрессии всех стилей должны разбираться.
  for (const id of STYLE_ORDER) {
    for (const pool of Object.values(STYLES[id].progressions)) {
      for (const prog of pool) {
        for (const tok of prog.split(/\s+/)) assert.ok(romanToChordSymbol(tok, 0), `${id}: ${tok}`);
      }
    }
  }
});

test('голосоведение: соседние аккорды меняются плавно', () => {
  const a = voiceChord(parseChord('C'), { low: 52, high: 72 });
  const b = voiceChord(parseChord('F'), { low: 52, high: 72, prev: a });
  const move = b.reduce((s, n, i) => s + Math.abs(n - a[i]), 0);
  assert.ok(move <= 6, `движение ${move}`);
  for (const n of b) assert.ok(chordPcs(parseChord('F')).includes(mod(n, 12)));
});

test('определение тональности', () => {
  const notes = ['A3', 'C4', 'E4', 'A4', 'G4', 'E4', 'D4', 'C4', 'B3', 'A3'].map((n) => ({ midi: noteToMidi(n), len: 2 }));
  const k = detectKey(notes);
  assert.ok((k.tonic === 9 && k.scale === 'minor') || (k.tonic === 0 && k.scale === 'major'));
});

test('гармонизация мелодии', () => {
  const bars = [
    [{ midi: 60, len: 4, strong: true }, { midi: 64, len: 4 }, { midi: 67, len: 8, strong: true }],
    [{ midi: 65, len: 8, strong: true }, { midi: 69, len: 8, strong: true }],
  ];
  const ch = harmonizeBars(bars, 0, 'major');
  assert.equal(ch[0], 'C');
  assert.equal(ch[1], 'F');
});

test('паттерны ударных', () => {
  const c = parseDrumPattern('x..X|o.3.', 8);
  assert.equal(c[0].vel, 0.78);
  assert.equal(c[3].vel, 1);
  assert.equal(c[4].vel, 0.42);
  assert.equal(c[6].n, 3);
  assert.equal(c[1], null);
});

test('нормализация понимает ответ ИИ с ```json и лишними запятыми', () => {
  const text = 'Вот исправленная песня:\n```json\n{"bpm": 120, "key": "Am", "tracks": [{"id":"b","instrument":"bass.synth"}], "sections": [{"id":"a","bars":2,"chords":["Am","F"],"parts":{"b":[{"step":0,"note":"A2","len":4},]}}],}\n```';
  const { song, warnings } = normalizeSong(text);
  assert.equal(song.key, 'A');
  assert.equal(song.scale, 'minor');
  assert.equal(song.sections[0].parts.b.length, 1);
  assert.equal(warnings.length, 0);
  assert.throws(() => extractJson('нет тут json'));
});

test('нормализация исправляет ошибки и предупреждает', () => {
  const { song, warnings } = normalizeSong({
    bpm: 999,
    tracks: [{ id: 'x', instrument: 'banjo' }, { id: 'd', instrument: 'drums.electro' }],
    sections: [{ id: 's', bars: 1, parts: { x: [{ step: 0, note: 'Q9' }, { step: 99, note: 'C4' }], d: { kick: 'x...', cowbell: 'x' }, nope: [] } }],
    arrangement: ['s', 'missing'],
  });
  assert.equal(song.bpm, 300);
  assert.equal(song.tracks[0].instrument, 'keys.piano');
  assert.ok(warnings.length >= 4);
  assert.deepEqual(song.arrangement, ['s']);
});

for (const styleId of STYLE_ORDER) {
  test(`генерация: стиль ${styleId}`, () => {
    for (const length of Object.keys(LENGTHS)) {
      const song = generateSong({ style: styleId, length, seed: 1234 });
      assert.ok(song.tracks.length >= 2, `${styleId}/${length}: мало дорожек`);
      for (const t of song.tracks) assert.ok(INSTRUMENT_MAP[t.instrument], t.instrument);
      // Сериализация и обратно — без предупреждений и потерь
      const json = stringifySong(song);
      const { song: back, warnings } = normalizeSong(json);
      assert.deepEqual(warnings, [], `${styleId}/${length}: ${warnings.join('; ')}`);
      assert.equal(back.sections.length, song.sections.length);
      const c = compileSong(back);
      assert.ok(c.events.length > 20, `${styleId}/${length}: мало событий`);
      assert.ok(c.duration > 5);
      for (const ev of c.events) {
        assert.ok(Number.isFinite(ev.time) && Number.isFinite(ev.dur), 'время события');
        if (!ev.voice) assert.ok(ev.midi >= 12 && ev.midi <= 108, `нота вне диапазона ${ev.midi}`);
      }
      // Аккорды разбираются
      for (const s of back.sections) for (const seg of chordTimeline(back, s)) assert.ok(seg.chord, `${styleId}: аккорд ${seg.symbol}`);
    }
  });
}

test('детерминизм: одинаковый seed — одинаковая песня', () => {
  const a = stringifySong(generateSong({ style: 'synthwave', seed: 42 }));
  const b = stringifySong(generateSong({ style: 'synthwave', seed: 42 }));
  assert.equal(a, b);
});

test('мелодия: сильные доли на звуках аккорда', () => {
  let strong = 0;
  let inChord = 0;
  for (let seed = 1; seed <= 20; seed++) {
    const song = generateSong({ style: 'pop', length: 'medium', seed });
    const lead = song.tracks.find((t) => t.role === 'lead');
    for (const sec of song.sections) {
      const notes = sec.parts[lead?.id] || [];
      const tl = chordTimeline(song, sec);
      for (const n of notes) {
        if (n.step % 16 !== 0) continue;
        const seg = tl.find((c) => n.step >= c.start && n.step < c.end);
        strong++;
        if (chordPcs(seg.chord).includes(mod(noteToMidi(n.note), 12))) inChord++;
      }
    }
  }
  assert.ok(strong > 50);
  assert.ok(inChord / strong > 0.85, `на сильных долях звуки аккорда: ${inChord}/${strong}`);
});

test('мелодия: в основном плавное движение', () => {
  let steps = 0;
  let leaps = 0;
  for (let seed = 1; seed <= 10; seed++) {
    const song = generateSong({ style: 'fantasy', seed });
    const lead = song.tracks.find((t) => t.role === 'lead');
    for (const sec of song.sections) {
      const notes = (sec.parts[lead?.id] || []).map((n) => noteToMidi(n.note));
      for (let i = 1; i < notes.length; i++) {
        const d = Math.abs(notes[i] - notes[i - 1]);
        if (d <= 4) steps++;
        if (d > 7) leaps++;
      }
    }
  }
  assert.ok(leaps / (steps + leaps) < 0.15, `скачков: ${leaps} из ${steps + leaps}`);
});

test('ноты мелодии в ладу (кроме заимствованных аккордов)', () => {
  let total = 0;
  let inScale = 0;
  for (let seed = 1; seed <= 10; seed++) {
    const song = generateSong({ style: 'cozy', seed, mood: 'bright' });
    const pcs = scalePcs(noteToMidi(song.key + '4') % 12, song.scale);
    const lead = song.tracks.find((t) => t.role === 'lead');
    for (const sec of song.sections) {
      for (const n of sec.parts[lead?.id] || []) {
        total++;
        if (pcs.includes(mod(noteToMidi(n.note), 12))) inScale++;
      }
    }
  }
  assert.ok(inScale / total > 0.9, `${inScale}/${total}`);
});

test('развить идею: набросок остаётся, остальное достраивается', () => {
  const song = createEmptySong();
  song.sections[0].chords = [];
  song.sections[0].parts.lead = [
    { step: 0, note: 'A4', len: 4, vel: 0.8 }, { step: 4, note: 'C5', len: 4, vel: 0.8 },
    { step: 8, note: 'E5', len: 8, vel: 0.8 }, { step: 16, note: 'D5', len: 4, vel: 0.8 },
    { step: 20, note: 'C5', len: 4, vel: 0.8 }, { step: 24, note: 'B4', len: 8, vel: 0.8 },
  ];
  song.sections[0].parts.drums = { kick: 'x...x...x...x...', snare: '....x.......x...' };
  const out = developSong(song, { style: 'synthwave', length: 'medium', seed: 7 });
  const chorus = out.sections.find((s) => s.kind === 'chorus');
  assert.ok(chorus);
  assert.deepEqual(chorus.parts.lead.slice(0, 6).map((n) => n.note), ['A4', 'C5', 'E5', 'D5', 'C5', 'B4']);
  assert.ok(out.sections.length >= 4);
  assert.ok(out.tracks.some((t) => t.role === 'bass'), 'добавлен бас');
  assert.ok(chorus.chords.length > 0);
  const { warnings } = normalizeSong(stringifySong(out));
  assert.deepEqual(warnings, []);
});

test('развить идею: только ритм', () => {
  const song = createEmptySong();
  song.sections[0].parts.drums = { kick: 'x..x..x.x.......', snare: '....x.......x...', hat: 'xxxxxxxxxxxxxxxx' };
  const out = developSong(song, { style: 'house', length: 'short', seed: 3 });
  const verseLike = out.sections.find((s) => s.kind === 'outro' || s.kind === 'intro');
  assert.ok(out.sections.find((s) => s.kind === 'chorus').parts.drums.kick.startsWith('x..x..x.x.......'));
  assert.ok(verseLike);
});

test('перегенерация партии и секции', () => {
  const song = generateSong({ style: 'lofi', seed: 5 });
  const sec = song.sections.find((s) => s.kind === 'chorus');
  for (const t of song.tracks) {
    const p = regeneratePart(song, sec.id, t.id, 99);
    assert.ok(p, t.id);
  }
  const parts = regenerateSection(song, sec.id, 11);
  assert.ok(Object.keys(parts).length > 0);
  const chords = regenerateChords(song, sec.id, 3);
  assert.equal(chords.length, sec.bars);
});

test('экспорт MIDI', () => {
  const song = generateSong({ style: 'rock', seed: 9 });
  const bytes = songToMidi(song);
  assert.equal(String.fromCharCode(...bytes.slice(0, 4)), 'MThd');
  assert.ok(bytes.length > 500);
});

test('свинг восьмыми сдвигает офбит', () => {
  const song = normalizeSong({
    bpm: 60, swing: 1, swingGrid: 8,
    tracks: [{ id: 'p', instrument: 'keys.piano' }],
    sections: [{ id: 's', bars: 1, parts: { p: [{ step: 0, note: 'C4', len: 2 }, { step: 2, note: 'D4', len: 2 }, { step: 4, note: 'E4', len: 2 }] } }],
  }).song;
  const ev = compileSong(song).events;
  // Шаг = 0.25 c; офбит (шаг 2) при полном свинге → 2/3 доли = 0.667 c
  assert.ok(Math.abs(ev[1].time - 0.6667) < 0.01, String(ev[1].time));
  assert.ok(Math.abs(ev[2].time - 1.0) < 0.001);
});
